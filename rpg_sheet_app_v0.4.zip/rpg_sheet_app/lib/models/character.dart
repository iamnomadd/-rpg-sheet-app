class Character {
  final String id;
  String name;
  String player;
  String systemId;
  String className;
  String race;
  String background;
  String history;
  String portraitPath;
  int level;
  int hp;
  int maxHp;
  int energy;
  int maxEnergy;
  Map<String, int> attributes;
  Map<String, int> resourceValues;
  Map<String, int> resourceMaxValues;
  Map<String, String> sectionNotes;
  List<String> skills;
  List<String> abilities;
  List<String> inventory;
  List<String> equipment;

  Character({
    required this.id,
    required this.name,
    this.player = '',
    this.systemId = 'generic',
    this.className = '',
    this.race = '',
    this.background = '',
    this.history = '',
    this.portraitPath = '',
    this.level = 1,
    this.hp = 10,
    this.maxHp = 10,
    this.energy = 0,
    this.maxEnergy = 0,
    Map<String, int>? attributes,
    Map<String, int>? resourceValues,
    Map<String, int>? resourceMaxValues,
    Map<String, String>? sectionNotes,
    List<String>? skills,
    List<String>? abilities,
    List<String>? inventory,
    List<String>? equipment,
  })  : attributes = attributes ?? {'FOR': 10, 'DES': 10, 'CON': 10, 'INT': 10, 'SAB': 10, 'CAR': 10},
        resourceValues = resourceValues ?? {'Vida': 10, 'Energia': 0},
        resourceMaxValues = resourceMaxValues ?? {'Vida': 10, 'Energia': 0},
        sectionNotes = sectionNotes ?? {},
        skills = skills ?? [],
        abilities = abilities ?? [],
        inventory = inventory ?? [],
        equipment = equipment ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'player': player,
        'systemId': systemId,
        'className': className,
        'race': race,
        'background': background,
        'history': history,
        'portraitPath': portraitPath,
        'level': level,
        'hp': hp,
        'maxHp': maxHp,
        'energy': energy,
        'maxEnergy': maxEnergy,
        'attributes': attributes,
        'resourceValues': resourceValues,
        'resourceMaxValues': resourceMaxValues,
        'sectionNotes': sectionNotes,
        'skills': skills,
        'abilities': abilities,
        'inventory': inventory,
        'equipment': equipment,
      };

  factory Character.fromJson(Map<String, dynamic> json) {
    final oldHp = (json['hp'] ?? 10) as int;
    final oldMaxHp = (json['maxHp'] ?? 10) as int;
    final oldEnergy = (json['energy'] ?? 0) as int;
    final oldMaxEnergy = (json['maxEnergy'] ?? 0) as int;

    final parsedAttributes = Map<String, int>.from(json['attributes'] ?? {});
    final parsedResources = Map<String, int>.from(json['resourceValues'] ?? {});
    final parsedMaxResources = Map<String, int>.from(json['resourceMaxValues'] ?? {});
    final parsedSections = Map<String, String>.from(json['sectionNotes'] ?? {});

    if (!parsedResources.containsKey('Vida')) parsedResources['Vida'] = oldHp;
    if (!parsedMaxResources.containsKey('Vida')) parsedMaxResources['Vida'] = oldMaxHp;
    if (!parsedResources.containsKey('Energia')) parsedResources['Energia'] = oldEnergy;
    if (!parsedMaxResources.containsKey('Energia')) parsedMaxResources['Energia'] = oldMaxEnergy;

    return Character(
      id: json['id'] ?? '',
      name: json['name'] ?? 'Sem nome',
      player: json['player'] ?? '',
      systemId: json['systemId'] ?? 'generic',
      className: json['className'] ?? '',
      race: json['race'] ?? '',
      background: json['background'] ?? '',
      history: json['history'] ?? '',
      portraitPath: json['portraitPath'] ?? '',
      level: json['level'] ?? 1,
      hp: oldHp,
      maxHp: oldMaxHp,
      energy: oldEnergy,
      maxEnergy: oldMaxEnergy,
      attributes: parsedAttributes,
      resourceValues: parsedResources,
      resourceMaxValues: parsedMaxResources,
      sectionNotes: parsedSections,
      skills: List<String>.from(json['skills'] ?? []),
      abilities: List<String>.from(json['abilities'] ?? []),
      inventory: List<String>.from(json['inventory'] ?? []),
      equipment: List<String>.from(json['equipment'] ?? []),
    );
  }
}
