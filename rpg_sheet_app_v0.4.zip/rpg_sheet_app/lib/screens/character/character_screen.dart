import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../models/character.dart';
import '../../models/rpg_system.dart';
import '../../services/app_state.dart';

class CharacterScreen extends StatefulWidget {
  final String characterId;

  const CharacterScreen({super.key, required this.characterId});

  @override
  State<CharacterScreen> createState() => _CharacterScreenState();
}

class _CharacterScreenState extends State<CharacterScreen> {
  int tab = 0;

  Character? _findCharacter(AppState state) {
    for (final c in state.characters) {
      if (c.id == widget.characterId) return c;
    }
    return null;
  }

  RpgSystem? _findSystem(AppState state, Character character) {
    for (final system in state.systems) {
      if (system.id == character.systemId) return system;
    }
    return state.systems.isNotEmpty ? state.systems.first : null;
  }

  Future<void> _editBasic() async {
    final state = context.read<AppState>();
    final c = _findCharacter(state);
    if (c == null) return;

    final name = TextEditingController(text: c.name);
    final player = TextEditingController(text: c.player);
    final className = TextEditingController(text: c.className);
    final race = TextEditingController(text: c.race);
    final background = TextEditingController(text: c.background);
    final level = TextEditingController(text: c.level.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Dados do personagem'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
              const SizedBox(height: 10),
              TextField(controller: player, decoration: const InputDecoration(labelText: 'Jogador')),
              const SizedBox(height: 10),
              TextField(controller: className, decoration: const InputDecoration(labelText: 'Classe')),
              const SizedBox(height: 10),
              TextField(controller: race, decoration: const InputDecoration(labelText: 'Raça')),
              const SizedBox(height: 10),
              TextField(controller: background, decoration: const InputDecoration(labelText: 'Antecedente')),
              const SizedBox(height: 10),
              TextField(controller: level, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Nível')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      c.name = name.text.trim().isEmpty ? c.name : name.text.trim();
      c.player = player.text.trim();
      c.className = className.text.trim();
      c.race = race.text.trim();
      c.background = background.text.trim();
      c.level = (int.tryParse(level.text) ?? c.level).clamp(1, 999);
      await state.updateCharacter(c);
      if (mounted) setState(() {});
    }

    name.dispose(); player.dispose(); className.dispose(); race.dispose(); background.dispose(); level.dispose();
  }

  Future<void> _pickPortrait() async {
    final state = context.read<AppState>();
    final c = _findCharacter(state);
    if (c == null) return;
    final image = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 1000);
    if (image == null) return;
    c.portraitPath = image.path;
    await state.updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editResource(Character c, String name) async {
    final state = context.read<AppState>();
    final current = c.resourceValues[name] ?? 0;
    final maximum = c.resourceMaxValues[name] ?? 0;
    final value = TextEditingController(text: current.toString());
    final max = TextEditingController(text: maximum.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Configurar $name'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: value, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor atual')),
          const SizedBox(height: 10),
          TextField(controller: max, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor máximo')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      final newMax = (int.tryParse(max.text) ?? maximum).clamp(0, 999999);
      c.resourceMaxValues[name] = newMax;
      c.resourceValues[name] = (int.tryParse(value.text) ?? current).clamp(0, newMax);
      if (name.toLowerCase() == 'vida') { c.maxHp = newMax; c.hp = c.resourceValues[name]!; }
      if (name.toLowerCase() == 'energia') { c.maxEnergy = newMax; c.energy = c.resourceValues[name]!; }
      await state.updateCharacter(c);
      if (mounted) setState(() {});
    }
    value.dispose(); max.dispose();
  }

  Future<void> _changeResource(Character c, String name, int delta) async {
    final state = context.read<AppState>();
    final max = c.resourceMaxValues[name] ?? 0;
    final current = c.resourceValues[name] ?? 0;
    c.resourceValues[name] = (current + delta).clamp(0, max);
    if (name.toLowerCase() == 'vida') c.hp = c.resourceValues[name]!;
    if (name.toLowerCase() == 'energia') c.energy = c.resourceValues[name]!;
    await state.updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editAttribute(Character c, String name) async {
    final controller = TextEditingController(text: (c.attributes[name] ?? 0).toString());
    final result = await showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Editar $name'),
        content: TextField(controller: controller, autofocus: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, int.tryParse(controller.text)), child: const Text('Salvar')),
        ],
      ),
    );
    controller.dispose();
    if (result == null) return;
    c.attributes[name] = result;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editSection(Character c, String name) async {
    final controller = TextEditingController(text: c.sectionNotes[name] ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(name),
        content: TextField(controller: controller, autofocus: true, minLines: 5, maxLines: 12, decoration: const InputDecoration(hintText: 'Escreva aqui...')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Salvar')),
        ],
      ),
    );
    controller.dispose();
    if (result == null) return;
    c.sectionNotes[name] = result;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _toggleSkill(Character c, String skill) async {
    if (c.skills.contains(skill)) { c.skills.remove(skill); } else { c.skills.add(skill); }
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final c = _findCharacter(state);
    if (c == null) return const Scaffold(body: Center(child: Text('Ficha não encontrada.')));
    final system = _findSystem(state, c);
    if (system == null) return const Scaffold(body: Center(child: Text('Sistema não encontrado.')));

    // Garante que fichas antigas recebam os campos do sistema atual.
    for (final attribute in system.attributes) { c.attributes.putIfAbsent(attribute, () => 10); }
    for (final resource in system.resources) {
      c.resourceValues.putIfAbsent(resource, () => 0);
      c.resourceMaxValues.putIfAbsent(resource, () => 0);
    }
    for (final section in system.sections) { c.sectionNotes.putIfAbsent(section, () => ''); }

    return Scaffold(
      appBar: AppBar(
        title: Text(c.name),
        actions: [IconButton(onPressed: _editBasic, icon: const Icon(Icons.edit), tooltip: 'Editar dados')],
      ),
      body: Column(
        children: [
          _Header(character: c, system: system, onPickPortrait: _pickPortrait),
          NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (value) => setState(() => tab = value),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Atributos'),
              NavigationDestination(icon: Icon(Icons.psychology), label: 'Perícias'),
              NavigationDestination(icon: Icon(Icons.favorite), label: 'Recursos'),
              NavigationDestination(icon: Icon(Icons.menu_book), label: 'Seções'),
              NavigationDestination(icon: Icon(Icons.backpack), label: 'Extras'),
            ],
          ),
          Expanded(
            child: IndexedStack(
              index: tab,
              children: [
                _AttributesTab(character: c, system: system, onEdit: _editAttribute),
                _SkillsTab(character: c, system: system, onToggle: _toggleSkill),
                _ResourcesTab(character: c, system: system, onChange: _changeResource, onEdit: _editResource),
                _SectionsTab(character: c, system: system, onEdit: _editSection),
                _ExtrasTab(character: c),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final VoidCallback onPickPortrait;
  const _Header({required this.character, required this.system, required this.onPickPortrait});

  @override
  Widget build(BuildContext context) {
    final hasPortrait = character.portraitPath.isNotEmpty && File(character.portraitPath).existsSync();
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        GestureDetector(
          onTap: onPickPortrait,
          child: Stack(children: [
            CircleAvatar(radius: 34, backgroundImage: hasPortrait ? FileImage(File(character.portraitPath)) : null, child: hasPortrait ? null : Text(character.name.isEmpty ? '?' : character.name[0].toUpperCase(), style: const TextStyle(fontSize: 28))),
            const Positioned(right: 0, bottom: 0, child: CircleAvatar(radius: 13, child: Icon(Icons.camera_alt, size: 14))),
          ]),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(character.name, style: Theme.of(context).textTheme.titleLarge),
          Text('${character.race.isEmpty ? 'Sem raça' : character.race} • ${character.className.isEmpty ? 'Sem classe' : character.className} • Nível ${character.level}'),
          const SizedBox(height: 4),
          Chip(avatar: const Icon(Icons.auto_awesome, size: 16), label: Text(system.name)),
        ])),
      ]),
    );
  }
}

class _AttributesTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onEdit;
  const _AttributesTab({required this.character, required this.system, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Atributos de ${system.name}', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 10),
      if (system.attributes.isEmpty) const Text('Este sistema não possui atributos configurados.')
      else GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: system.attributes.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.65, crossAxisSpacing: 10, mainAxisSpacing: 10),
        itemBuilder: (_, index) {
          final name = system.attributes[index]; final value = character.attributes[name] ?? 0;
          return Card(child: InkWell(borderRadius: BorderRadius.circular(18), onTap: () => onEdit(character, name), child: Padding(padding: const EdgeInsets.all(14), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text('$value', style: Theme.of(context).textTheme.headlineSmall)]))));
        },
      ),
    ]);
  }
}

class _SkillsTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onToggle;
  const _SkillsTab({required this.character, required this.system, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Perícias do sistema', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8),
      if (system.skills.isEmpty) const Text('Este sistema não possui perícias configuradas.')
      else ...system.skills.map((skill) => Card(child: CheckboxListTile(value: character.skills.contains(skill), onChanged: (_) => onToggle(character, skill), title: Text(skill), secondary: const Icon(Icons.psychology)))),
      const SizedBox(height: 16),
      if (character.skills.isNotEmpty) Text('Perícias selecionadas: ${character.skills.join(', ')}', style: Theme.of(context).textTheme.bodySmall),
    ]);
  }
}

class _ResourcesTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String, int) onChange;
  final Future<void> Function(Character, String) onEdit;
  const _ResourcesTab({required this.character, required this.system, required this.onChange, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Recursos de ${system.name}', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 10),
      if (system.resources.isEmpty) const Text('Este sistema não possui recursos configurados.'),
      ...system.resources.map((name) {
        final value = character.resourceValues[name] ?? 0; final max = character.resourceMaxValues[name] ?? 0;
        final progress = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0);
        return Card(margin: const EdgeInsets.only(bottom: 10), child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
          Row(children: [Icon(name.toLowerCase() == 'vida' ? Icons.favorite : Icons.bolt), const SizedBox(width: 8), Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.bold))), IconButton(onPressed: () => onChange(character, name, -1), icon: const Icon(Icons.remove)), Text('$value / $max'), IconButton(onPressed: () => onChange(character, name, 1), icon: const Icon(Icons.add)), IconButton(onPressed: () => onEdit(character, name), icon: const Icon(Icons.tune))]),
          LinearProgressIndicator(value: progress),
        ])));
      }),
    ]);
  }
}

class _SectionsTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onEdit;
  const _SectionsTab({required this.character, required this.system, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Seções da ficha', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 10),
      if (system.sections.isEmpty) const Text('Este sistema não possui seções configuradas.'),
      ...system.sections.map((section) => Card(child: ListTile(title: Text(section), subtitle: Text((character.sectionNotes[section] ?? '').isEmpty ? 'Toque para preencher.' : character.sectionNotes[section]!), trailing: const Icon(Icons.edit), onTap: () => onEdit(character, section)))),
    ]);
  }
}

class _ExtrasTab extends StatefulWidget {
  final Character character;
  const _ExtrasTab({required this.character});
  @override State<_ExtrasTab> createState() => _ExtrasTabState();
}

class _ExtrasTabState extends State<_ExtrasTab> {
  Future<void> _add(List<String> items, String title, String hint) async {
    final controller = TextEditingController();
    final value = await showDialog<String>(context: context, builder: (_) => AlertDialog(title: Text('Adicionar $title'), content: TextField(controller: controller, autofocus: true, decoration: InputDecoration(labelText: hint)), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Adicionar'))]));
    controller.dispose();
    if (value != null && value.isNotEmpty) { items.add(value); await context.read<AppState>().updateCharacter(widget.character); if (mounted) setState(() {}); }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      _ExtraList(title: 'Inventário', icon: Icons.backpack, items: widget.character.inventory, onAdd: () => _add(widget.character.inventory, 'item', 'Nome do item'), onDelete: (i) async { widget.character.inventory.removeAt(i); await context.read<AppState>().updateCharacter(widget.character); setState(() {}); }),
      const SizedBox(height: 14),
      _ExtraList(title: 'Habilidades', icon: Icons.auto_awesome, items: widget.character.abilities, onAdd: () => _add(widget.character.abilities, 'habilidade', 'Nome da habilidade'), onDelete: (i) async { widget.character.abilities.removeAt(i); await context.read<AppState>().updateCharacter(widget.character); setState(() {}); }),
    ]);
  }
}

class _ExtraList extends StatelessWidget {
  final String title; final IconData icon; final List<String> items; final VoidCallback onAdd; final Future<void> Function(int) onDelete;
  const _ExtraList({required this.title, required this.icon, required this.items, required this.onAdd, required this.onDelete});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Row(children: [Icon(icon), const SizedBox(width: 8), Text(title, style: Theme.of(context).textTheme.titleMedium), const Spacer(), IconButton(onPressed: onAdd, icon: const Icon(Icons.add_circle))]), if (items.isEmpty) const Padding(padding: EdgeInsets.all(18), child: Text('Nenhum item adicionado.')) else ...items.asMap().entries.map((e) => ListTile(dense: true, leading: Icon(icon), title: Text(e.value), trailing: IconButton(onPressed: () => onDelete(e.key), icon: const Icon(Icons.delete_outline))))])));
}
