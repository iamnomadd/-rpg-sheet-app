# RPG Sheet App — V0.3

Aplicativo Flutter para criação e gerenciamento de fichas de RPG.

## V0.3 — Construtor de sistemas
- Criar sistemas personalizados.
- Editar nome e descrição.
- Definir atributos.
- Definir perícias.
- Definir recursos (Vida, Mana, Sanidade etc.).
- Definir seções da ficha.
- Persistência local.
- Compatibilidade com sistemas criados nas versões anteriores.

## V0.4.1 — Sistema ao criar ficha
- Ao criar uma nova ficha, o usuário escolhe qual sistema de RPG será utilizado.
- A ficha guarda o ID do sistema escolhido.
- O sistema escolhido aparece no resumo da ficha.

## Próxima etapa
A V0.4 usará a definição do sistema escolhido para gerar a ficha do personagem dinamicamente.

## Tecnologias
- Flutter / Dart
- Provider
- SharedPreferences
- UUID
- Image Picker


## V0.4
- A seleção de sistema da V0.3.1 foi incorporada nesta versão.
- A ficha agora é montada dinamicamente conforme o sistema escolhido.
- Atributos, perícias, recursos e seções vêm da configuração do sistema.
- Recursos possuem valor atual/máximo e controles rápidos.
- Seções configuradas pelo sistema podem armazenar anotações próprias por personagem.
- Fichas antigas recebem os novos campos automaticamente sem perder os dados existentes.


## V0.4.1
- Aba Geral da ficha com resumo somente para visualização.
- Resumo de atributos, vida, inventário e habilidades.
- A aba Geral não permite editar informações.
- É possível alterar apenas a ordem dos blocos pelo ícone de arrastar.
- A ordem personalizada é salva na ficha.
- Para alterar qualquer informação, o usuário deve entrar na aba correspondente.
