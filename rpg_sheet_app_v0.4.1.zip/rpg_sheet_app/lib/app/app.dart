import 'package:flutter/material.dart';

import '../screens/home/home_screen.dart';
import '../screens/systems/systems_screen.dart';
import '../screens/campaigns/campaigns_screen.dart';
import '../screens/dice/dice_screen.dart';
import '../screens/settings/settings_screen.dart';
import 'theme.dart';

class RpgSheetApp extends StatefulWidget {
  const RpgSheetApp({super.key});

  @override
  State<RpgSheetApp> createState() => _RpgSheetAppState();
}

class _RpgSheetAppState extends State<RpgSheetApp> {
  int index = 0;

  final pages = const [
    HomeScreen(),
    SystemsScreen(),
    DiceScreen(),
    CampaignsScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RPG Sheet',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: Scaffold(
        body: IndexedStack(index: index, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) => setState(() => index = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.people), label: 'Fichas'),
            NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Sistemas'),
            NavigationDestination(icon: Icon(Icons.casino), label: 'Dados'),
            NavigationDestination(icon: Icon(Icons.groups), label: 'Campanhas'),
            NavigationDestination(icon: Icon(Icons.settings), label: 'Config.'),
          ],
        ),
      ),
    );
  }
}
