import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../models/campaign.dart';
import '../models/character.dart';
import '../models/rpg_system.dart';

class AppState extends ChangeNotifier {
  final _uuid = const Uuid();
  List<Character> characters = [];
  List<RpgSystem> systems = [];
  List<Campaign> campaigns = [];
  bool loaded = false;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();

    final charactersJson = prefs.getString('characters');
    final systemsJson = prefs.getString('systems');
    final campaignsJson = prefs.getString('campaigns');

    if (charactersJson != null) {
      characters = (jsonDecode(charactersJson) as List)
          .map((e) => Character.fromJson(e))
          .toList();
    }

    if (systemsJson != null) {
      systems = (jsonDecode(systemsJson) as List)
          .map((e) => RpgSystem.fromJson(e))
          .toList();
    } else {
      systems = [
        RpgSystem(
          id: 'generic',
          name: 'Sistema Genérico',
          description: 'Sistema livre para criar sua própria ficha.',
          attributes: ['FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR'],
          resources: ['Vida', 'Energia'],
          sections: ['Resumo', 'História'],
        ),
      ];
    }

    if (campaignsJson != null) {
      campaigns = (jsonDecode(campaignsJson) as List)
          .map((e) => Campaign.fromJson(e))
          .toList();
    }

    loaded = true;
    notifyListeners();
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'characters',
      jsonEncode(characters.map((e) => e.toJson()).toList()),
    );
    await prefs.setString(
      'systems',
      jsonEncode(systems.map((e) => e.toJson()).toList()),
    );
    await prefs.setString(
      'campaigns',
      jsonEncode(campaigns.map((e) => e.toJson()).toList()),
    );
  }

  Future<Character> addCharacter({
    required String name,
    String systemId = 'generic',
  }) async {
    final system = systems.firstWhere(
      (s) => s.id == systemId,
      orElse: () => systems.firstWhere((s) => s.id == 'generic'),
    );

    final attributes = <String, int>{};
    for (final attribute in system.attributes) {
      attributes[attribute] = 10;
    }

    final resourceValues = <String, int>{};
    final resourceMaxValues = <String, int>{};
    for (final resource in system.resources) {
      final isLife = resource.toLowerCase() == 'vida';
      final isEnergy = resource.toLowerCase() == 'energia';
      resourceValues[resource] = isLife ? 10 : 0;
      resourceMaxValues[resource] = isLife ? 10 : 0;
      if (isEnergy) {
        resourceValues[resource] = 0;
        resourceMaxValues[resource] = 0;
      }
    }

    final sectionNotes = <String, String>{};
    for (final section in system.sections) {
      sectionNotes[section] = '';
    }

    final character = Character(
      id: _uuid.v4(),
      name: name,
      systemId: system.id,
      attributes: attributes,
      resourceValues: resourceValues,
      resourceMaxValues: resourceMaxValues,
      sectionNotes: sectionNotes,
    );
    characters.add(character);
    await save();
    notifyListeners();
    return character;
  }

  Future<void> deleteCharacter(String id) async {
    characters.removeWhere((c) => c.id == id);
    await save();
    notifyListeners();
  }

  Future<void> updateCharacter(Character character) async {
    final index = characters.indexWhere((c) => c.id == character.id);
    if (index >= 0) characters[index] = character;
    await save();
    notifyListeners();
  }

  Future<void> addSystem(RpgSystem system) async {
    systems.add(system);
    await save();
    notifyListeners();
  }

  Future<void> updateSystem(RpgSystem system) async {
    final index = systems.indexWhere((s) => s.id == system.id);
    if (index >= 0) {
      systems[index] = system;
      await save();
      notifyListeners();
    }
  }

  Future<void> deleteSystem(String id) async {
    if (id == 'generic') return;
    systems.removeWhere((s) => s.id == id);
    await save();
    notifyListeners();
  }

  Future<void> addCampaign(Campaign campaign) async {
    campaigns.add(campaign);
    await save();
    notifyListeners();
  }

  Future<void> deleteCampaign(String id) async {
    campaigns.removeWhere((c) => c.id == id);
    await save();
    notifyListeners();
  }

  int roll(int sides, {int count = 1, int modifier = 0}) {
    final random = Random();
    var total = modifier;
    for (var i = 0; i < count; i++) {
      total += random.nextInt(sides) + 1;
    }
    return total;
  }

  Future<void> clearAll() async {
    characters.clear();
    systems = [
      RpgSystem(
        id: 'generic',
        name: 'Sistema Genérico',
        description: 'Sistema livre para criar sua própria ficha.',
        attributes: ['FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR'],
        resources: ['Vida', 'Energia'],
        sections: ['Resumo', 'História'],
      ),
    ];
    campaigns.clear();
    await save();
    notifyListeners();
  }
}
