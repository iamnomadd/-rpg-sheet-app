class Campaign {
  final String id;
  String name;
  String description;
  List<String> characterIds;

  Campaign({
    required this.id,
    required this.name,
    this.description = '',
    List<String>? characterIds,
  }) : characterIds = characterIds ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'characterIds': characterIds,
      };

  factory Campaign.fromJson(Map<String, dynamic> json) => Campaign(
        id: json['id'],
        name: json['name'],
        description: json['description'] ?? '',
        characterIds: List<String>.from(json['characterIds'] ?? []),
      );
}
