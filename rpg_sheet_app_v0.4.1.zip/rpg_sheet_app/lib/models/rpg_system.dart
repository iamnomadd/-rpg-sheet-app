class RpgSystem {
  final String id;
  String name;
  String description;
  List<String> attributes;
  List<String> skills;
  List<String> resources;
  List<String> sections;

  RpgSystem({
    required this.id,
    required this.name,
    this.description = '',
    List<String>? attributes,
    List<String>? skills,
    List<String>? resources,
    List<String>? sections,
  })  : attributes = attributes ?? [],
        skills = skills ?? [],
        resources = resources ?? [],
        sections = sections ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'attributes': attributes,
        'skills': skills,
        'resources': resources,
        'sections': sections,
      };

  factory RpgSystem.fromJson(Map<String, dynamic> json) => RpgSystem(
        id: json['id'] ?? '',
        name: json['name'] ?? 'Sistema sem nome',
        description: json['description'] ?? '',
        attributes: List<String>.from(json['attributes'] ?? []),
        skills: List<String>.from(json['skills'] ?? []),
        resources: List<String>.from(json['resources'] ?? []),
        sections: List<String>.from(json['sections'] ?? []),
      );
}
