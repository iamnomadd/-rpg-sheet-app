import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/app_state.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Configurações')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Card(
              child: ListTile(
                leading: Icon(Icons.cloud_off),
                title: Text('Sincronização'),
                subtitle: Text('Preparada para a futura integração com Supabase.'),
              ),
            ),
            const Card(
              child: ListTile(
                leading: Icon(Icons.picture_as_pdf),
                title: Text('Exportação PDF'),
                subtitle: Text('Será adicionada na próxima etapa.'),
              ),
            ),
            const Card(
              child: ListTile(
                leading: Icon(Icons.account_circle),
                title: Text('Conta'),
                subtitle: Text('Login e backup na nuvem serão adicionados depois.'),
              ),
            ),
            const SizedBox(height: 20),
            OutlinedButton.icon(
              onPressed: () => _clear(context),
              icon: const Icon(Icons.delete_forever),
              label: const Text('Apagar dados locais'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _clear(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Apagar todos os dados?'),
        content: const Text('Todas as fichas, sistemas personalizados e campanhas deste dispositivo serão removidos.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Apagar'),
          ),
        ],
      ),
    );

    if (result == true && context.mounted) {
      await context.read<AppState>().clearAll();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Dados locais apagados.')),
      );
    }
  }
}
