import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../models/campaign.dart';
import '../../services/app_state.dart';

class CampaignsScreen extends StatelessWidget {
  const CampaignsScreen({super.key});

  Future<void> _addCampaign(BuildContext context) async {
    final name = TextEditingController();
    final description = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Nova campanha'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome da campanha')),
            const SizedBox(height: 10),
            TextField(controller: description, decoration: const InputDecoration(labelText: 'Descrição')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Criar')),
        ],
      ),
    );

    if (result != true || name.text.trim().isEmpty || !context.mounted) return;

    await context.read<AppState>().addCampaign(
      Campaign(
        id: const Uuid().v4(),
        name: name.text.trim(),
        description: description.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Campanhas')),
        body: state.campaigns.isEmpty
            ? Center(
                child: FilledButton.icon(
                  onPressed: () => _addCampaign(context),
                  icon: const Icon(Icons.add),
                  label: const Text('Criar campanha'),
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: state.campaigns.length,
                itemBuilder: (_, index) {
                  final campaign = state.campaigns[index];
                  return Card(
                    child: ListTile(
                      leading: const Icon(Icons.groups),
                      title: Text(campaign.name),
                      subtitle: Text(
                        campaign.description.isEmpty
                            ? 'Nenhuma descrição'
                            : campaign.description,
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => state.deleteCampaign(campaign.id),
                      ),
                    ),
                  );
                },
              ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _addCampaign(context),
          child: const Icon(Icons.add),
        ),
      ),
    );
  }
}
