import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../models/rpg_system.dart';
import '../../services/app_state.dart';
import 'system_editor_screen.dart';

class SystemsScreen extends StatelessWidget {
  const SystemsScreen({super.key});

  Future<void> _addSystem(BuildContext context) async {
    final system = RpgSystem(
      id: const Uuid().v4(),
      name: 'Novo Sistema',
      description: 'Sistema personalizado.',
      attributes: ['FOR', 'DES', 'CON'],
      skills: [],
      resources: ['Vida'],
      sections: ['Resumo', 'História'],
    );

    await context.read<AppState>().addSystem(system);

    if (!context.mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SystemEditorScreen(system: system)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Sistemas de RPG'),
          actions: [
            IconButton(
              onPressed: () => _addSystem(context),
              icon: const Icon(Icons.add),
              tooltip: 'Criar sistema',
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.tune, size: 32),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Construtor de sistemas',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            'Crie a estrutura do seu próprio RPG. Nesta versão você pode configurar atributos, perícias, recursos e seções da ficha.',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Meus sistemas',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            ...state.systems.map(
              (system) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: CircleAvatar(
                    child: Icon(
                      system.id == 'generic' ? Icons.public : Icons.auto_awesome,
                    ),
                  ),
                  title: Text(system.name),
                  subtitle: Text(
                    '${system.attributes.length} atributos • '
                    '${system.skills.length} perícias • '
                    '${system.resources.length} recursos',
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => SystemEditorScreen(system: system),
                      ),
                    );
                  },
                  onLongPress: system.id == 'generic'
                      ? null
                      : () => _confirmDelete(context, system),
                ),
              ),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _addSystem(context),
          icon: const Icon(Icons.add),
          label: const Text('Criar sistema'),
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, RpgSystem system) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Excluir sistema?'),
        content: Text(
          'O sistema "${system.name}" será removido. Personagens existentes não serão apagados.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      await context.read<AppState>().deleteSystem(system.id);
    }
  }
}
