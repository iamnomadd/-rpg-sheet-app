import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/app_state.dart';

class DiceScreen extends StatefulWidget {
  const DiceScreen({super.key});

  @override
  State<DiceScreen> createState() => _DiceScreenState();
}

class _DiceScreenState extends State<DiceScreen> {
  int lastResult = 0;
  int sides = 20;
  int count = 1;
  int modifier = 0;

  void roll() {
    setState(() {
      lastResult = context.read<AppState>().roll(
        sides,
        count: count,
        modifier: modifier,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final dice = [4, 6, 8, 10, 12, 20, 100];

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Rolagem de Dados')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const Text('Resultado'),
                    const SizedBox(height: 8),
                    Text(
                      '$lastResult',
                      style: Theme.of(context).textTheme.displayLarge,
                    ),
                    const SizedBox(height: 8),
                    Text('$count d$sides ${modifier >= 0 ? '+' : ''}$modifier'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text('Dado', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: dice.map((d) {
                return ChoiceChip(
                  label: Text('d$d'),
                  selected: sides == d,
                  onSelected: (_) => setState(() => sides = d),
                );
              }).toList(),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: count,
                    decoration: const InputDecoration(labelText: 'Quantidade'),
                    items: List.generate(
                      10,
                      (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}')),
                    ),
                    onChanged: (v) => setState(() => count = v ?? 1),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextFormField(
                    initialValue: '0',
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Modificador'),
                    onChanged: (v) => modifier = int.tryParse(v) ?? 0,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: roll,
              icon: const Icon(Icons.casino),
              label: const Text('Rolar dados'),
            ),
          ],
        ),
      ),
    );
  }
}
