import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../models/campaign.dart';
import '../../services/app_state.dart';

class CampaignsScreen extends StatelessWidget {
  const CampaignsScreen({super.key});

  Future<void> _addCampaign(BuildContext context) async {
    final name = TextEditingController();
    final description = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Nova campanha'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome da campanha')),
          const SizedBox(height: 10),
          TextField(controller: description, decoration: const InputDecoration(labelText: 'Descrição'), maxLines: 3),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Criar')),
        ],
      ),
    );
    if (result != true || name.text.trim().isEmpty || !context.mounted) return;
    await context.read<AppState>().addCampaign(Campaign(id: const Uuid().v4(), name: name.text.trim(), description: description.text.trim()));
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return SafeArea(child: Scaffold(
      appBar: AppBar(title: const Text('Campanhas')),
      body: state.campaigns.isEmpty
          ? Center(child: FilledButton.icon(onPressed: () => _addCampaign(context), icon: const Icon(Icons.add), label: const Text('Criar campanha')))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: state.campaigns.length,
              itemBuilder: (_, index) {
                final campaign = state.campaigns[index];
                return Card(child: ListTile(
                  leading: const Icon(Icons.groups),
                  title: Text(campaign.name),
                  subtitle: Text('${campaign.characterIds.length} personagens • ${campaign.npcs.length} NPCs • ${campaign.locations.length} locais'),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CampaignDetailScreen(campaignId: campaign.id))),
                  trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _confirmDelete(context, campaign)),
                ));
              }),
      floatingActionButton: FloatingActionButton(onPressed: () => _addCampaign(context), child: const Icon(Icons.add)),
    ));
  }

  Future<void> _confirmDelete(BuildContext context, Campaign campaign) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Excluir campanha?'),
      content: Text('A campanha “${campaign.name}” será excluída. As fichas não serão apagadas.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir'))],
    ));
    if (ok == true && context.mounted) await context.read<AppState>().deleteCampaign(campaign.id);
  }
}

class CampaignDetailScreen extends StatelessWidget {
  final String campaignId;
  const CampaignDetailScreen({super.key, required this.campaignId});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final matches = state.campaigns.where((c) => c.id == campaignId);
    if (matches.isEmpty) return const Scaffold(body: Center(child: Text('Campanha não encontrada.')));
    final c = matches.first;
    return Scaffold(
      appBar: AppBar(title: Text(c.name), actions: [IconButton(icon: const Icon(Icons.edit), onPressed: () => _editInfo(context, c))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (c.description.isNotEmpty) Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(c.description))),
        _section(context, 'Personagens', Icons.people, c.characterIds.map((id) {
          final found = state.characters.where((x) => x.id == id);
          return found.isEmpty ? 'Ficha indisponível' : found.first.name;
        }).toList(), () => _characters(context, c)),
        _section(context, 'NPCs', Icons.person_search, c.npcs, () => _textList(context, c, 'NPC', c.npcs)),
        _section(context, 'Locais', Icons.map, c.locations, () => _textList(context, c, 'Local', c.locations)),
        Card(child: ListTile(leading: const Icon(Icons.notes), title: const Text('Notas da campanha'), subtitle: Text(c.notes.isEmpty ? 'Nenhuma nota' : c.notes, maxLines: 4, overflow: TextOverflow.ellipsis), onTap: () => _notes(context, c))),
      ]),
    );
  }

  Widget _section(BuildContext context, String title, IconData icon, List<String> values, VoidCallback add) => Card(child: Padding(
    padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Icon(icon), const SizedBox(width: 8), Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium)), IconButton(onPressed: add, icon: const Icon(Icons.add))]),
      if (values.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Nenhum item adicionado.')),
      ...values.map((e) => ListTile(dense: true, title: Text(e))),
    ])));

  Future<void> _editInfo(BuildContext context, Campaign c) async {
    final name = TextEditingController(text: c.name), description = TextEditingController(text: c.description);
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Editar campanha'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')), TextField(controller: description, decoration: const InputDecoration(labelText: 'Descrição'), maxLines: 4)]), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar'))]));
    if (ok == true && name.text.trim().isNotEmpty && context.mounted) { c.name = name.text.trim(); c.description = description.text.trim(); await context.read<AppState>().updateCampaign(c); }
  }

  Future<void> _characters(BuildContext context, Campaign c) async {
    final state = context.read<AppState>();
    final selected = Set<String>.from(c.characterIds);
    final ok = await showDialog<bool>(context: context, builder: (_) => StatefulBuilder(builder: (context, setState) => AlertDialog(title: const Text('Personagens da campanha'), content: SizedBox(width: double.maxFinite, child: state.characters.isEmpty ? const Text('Crie uma ficha primeiro.') : ListView(shrinkWrap: true, children: state.characters.map((ch) => CheckboxListTile(value: selected.contains(ch.id), title: Text(ch.name), onChanged: (v) => setState(() => v == true ? selected.add(ch.id) : selected.remove(ch.id)))).toList())), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar'))])));
    if (ok == true && context.mounted) { c.characterIds = selected.toList(); await context.read<AppState>().updateCampaign(c); }
  }

  Future<void> _textList(BuildContext context, Campaign c, String label, List<String> target) async {
    final controller = TextEditingController();
    final value = await showDialog<String>(context: context, builder: (_) => AlertDialog(title: Text('Adicionar $label'), content: TextField(controller: controller, autofocus: true, decoration: InputDecoration(labelText: 'Nome do $label')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Adicionar'))]));
    if (value != null && value.isNotEmpty && context.mounted) { target.add(value); await context.read<AppState>().updateCampaign(c); }
  }

  Future<void> _notes(BuildContext context, Campaign c) async {
    final controller = TextEditingController(text: c.notes);
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Notas da campanha'), content: TextField(controller: controller, minLines: 6, maxLines: 12, decoration: const InputDecoration(hintText: 'Anotações da sessão, pistas, acontecimentos...')), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar'))]));
    if (ok == true && context.mounted) { c.notes = controller.text; await context.read<AppState>().updateCampaign(c); }
  }
}
