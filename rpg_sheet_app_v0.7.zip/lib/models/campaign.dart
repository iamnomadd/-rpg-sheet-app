class Campaign {
  final String id;
  String name;
  String description;
  List<String> characterIds;
  List<String> npcs;
  List<String> locations;
  String notes;

  Campaign({
    required this.id,
    required this.name,
    this.description = '',
    List<String>? characterIds,
    List<String>? npcs,
    List<String>? locations,
    this.notes = '',
  })  : characterIds = characterIds ?? [],
        npcs = npcs ?? [],
        locations = locations ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'characterIds': characterIds,
        'npcs': npcs,
        'locations': locations,
        'notes': notes,
      };

  factory Campaign.fromJson(Map<String, dynamic> json) => Campaign(
        id: json['id'],
        name: json['name'],
        description: json['description'] ?? '',
        characterIds: List<String>.from(json['characterIds'] ?? []),
        npcs: List<String>.from(json['npcs'] ?? []),
        locations: List<String>.from(json['locations'] ?? []),
        notes: json['notes'] ?? '',
      );
}
