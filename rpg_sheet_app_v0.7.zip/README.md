# RPG Sheet App — V0.5

Aplicativo Flutter para criação e gerenciamento de fichas de RPG.

## V0.5 — Importar e exportar
- Exportar sistemas em arquivos `.rpg`.
- Importar sistemas em arquivos `.rpg`.
- Exportar fichas com o sistema usado pela personagem.
- Importar fichas junto com o sistema correspondente.
- Exportar backup completo das fichas, sistemas e campanhas.
- Restaurar backup completo.
- Formato versionado para permitir evolução futura dos arquivos.
- IDs internos são recriados durante importações para evitar conflitos.
- Sistemas importados com nomes repetidos recebem um sufixo automaticamente.

## V0.4.1 — Geral da ficha
- Aba Geral da ficha com resumo somente para visualização.
- Resumo de atributos, vida, inventário e habilidades.
- A aba Geral não permite editar informações.
- É possível alterar apenas a ordem dos blocos pelo ícone de arrastar.
- A ordem personalizada é salva na ficha.

## V0.4 — Ficha dinâmica
- A seleção de sistema da V0.3.1 foi incorporada.
- A ficha é montada dinamicamente conforme o sistema escolhido.
- Atributos, perícias, recursos e seções vêm da configuração do sistema.
- Recursos possuem valor atual/máximo.
- Seções configuradas pelo sistema armazenam anotações por personagem.

## V0.3 — Construtor de sistemas
- Criar sistemas personalizados.
- Editar nome e descrição.
- Definir atributos, perícias, recursos e seções.
- Persistência local.

## Tecnologias
- Flutter / Dart
- Provider
- SharedPreferences
- UUID
- Image Picker
- File Picker
- Path Provider
- Share Plus


## V0.5.1

Correção de compatibilidade Android para a dependência file_picker, atualizada para a série 10.3.x.


## V0.6.0 — Dados avançados
- Rolagem normal, vantagem e desvantagem.
- Expressões como `2d6+3`.
- Histórico persistente das últimas 50 rolagens.
- Sistemas podem definir os dados disponíveis na tela de rolagem.
- Mantém as funcionalidades das versões anteriores.

## V0.7.0 — Campanhas
- Tela detalhada de campanha.
- Associação de fichas existentes à campanha.
- Cadastro de NPCs e locais.
- Notas da campanha/sessão.
- Edição de nome e descrição.
- Contadores na lista de campanhas.
- Exclusão da campanha sem apagar as fichas.
- Identificação do projeto atualizada para V0.7.0.
