from pathlib import Path
p=Path("android/app/src/main/AndroidManifest.xml")
if not p.exists(): raise SystemExit("AndroidManifest.xml não encontrado")
s=p.read_text(encoding="utf-8")
internet='<uses-permission android:name="android.permission.INTERNET" />'
if internet not in s:
    marker='<manifest xmlns:android="http://schemas.android.com/apk/res/android">'
    s=s.replace(marker,marker+"\n    "+internet,1)
if 'android:scheme="rpgsheet"' not in s:
    end=s.find("</activity>")
    if end<0: raise SystemExit("Activity principal não encontrada")
    intent='''        <intent-filter android:autoVerify="false">
            <action android:name="android.intent.action.VIEW" />
            <category android:name="android.intent.category.DEFAULT" />
            <category android:name="android.intent.category.BROWSABLE" />
            <data android:scheme="rpgsheet" android:host="auth-callback" />
        </intent-filter>
'''
    s=s[:end]+intent+s[end:]
p.write_text(s,encoding="utf-8")
print("AndroidManifest preparado: INTERNET + rpgsheet://auth-callback")
