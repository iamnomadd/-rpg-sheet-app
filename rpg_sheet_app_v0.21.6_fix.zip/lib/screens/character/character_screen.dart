import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/character.dart';
import '../../models/rpg_system.dart';
import '../../services/app_state.dart';
import 'skill_tree_screen.dart';
import '../../services/rpg_file_service.dart';
import '../../app/theme.dart';

class CharacterScreen extends StatefulWidget {
  final String characterId;

  const CharacterScreen({super.key, required this.characterId});

  @override
  State<CharacterScreen> createState() => _CharacterScreenState();
}

class _CharacterScreenState extends State<CharacterScreen> {
  int tab = 0;

  Character? _findCharacter(AppState state) {
    for (final c in state.characters) {
      if (c.id == widget.characterId) return c;
    }
    return null;
  }

  RpgSystem? _findSystem(AppState state, Character character) {
    for (final system in state.systems) {
      if (system.id == character.systemId) return system;
    }
    return state.systems.isNotEmpty ? state.systems.first : null;
  }

  Widget _compactLines(List<String> lines, String emptyText) {
    if (lines.isEmpty) {
      return Text(emptyText);
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: lines
          .map((line) => Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text(line, maxLines: 2, overflow: TextOverflow.ellipsis),
              ))
          .toList(),
    );
  }

  Future<void> _editBasic() async {
    final state = context.read<AppState>();
    final c = _findCharacter(state);
    if (c == null) return;

    final name = TextEditingController(text: c.name);
    final player = TextEditingController(text: c.player);
    final className = TextEditingController(text: c.className);
    final race = TextEditingController(text: c.race);
    final background = TextEditingController(text: c.background);
    final level = TextEditingController(text: c.level.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Dados do personagem'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(controller: name, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Nome')),
              const SizedBox(height: 10),
              TextField(controller: player, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Jogador')),
              const SizedBox(height: 10),
              TextField(controller: className, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Classe')),
              const SizedBox(height: 10),
              TextField(controller: race, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Raça')),
              const SizedBox(height: 10),
              TextField(controller: background, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Antecedente')),
              const SizedBox(height: 10),
              TextField(controller: level, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Nível')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      c.name = name.text.trim().isEmpty ? c.name : name.text.trim();
      c.player = player.text.trim();
      c.className = className.text.trim();
      c.race = race.text.trim();
      c.background = background.text.trim();
      c.level = (int.tryParse(level.text) ?? c.level).clamp(1, 999);
      await state.updateCharacter(c);
      if (mounted) setState(() {});
    }

    name.dispose(); player.dispose(); className.dispose(); race.dispose(); background.dispose(); level.dispose();
  }

  Future<void> _editResource(Character c, String name) async {
    final state = context.read<AppState>();
    final current = c.resourceValues[name] ?? 0;
    final maximum = c.resourceMaxValues[name] ?? 0;
    final value = TextEditingController(text: current.toString());
    final max = TextEditingController(text: maximum.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Configurar $name'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: value, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor atual')),
          const SizedBox(height: 10),
          TextField(controller: max, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor máximo')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      final newMax = (int.tryParse(max.text) ?? maximum).clamp(0, 999999);
      c.resourceMaxValues[name] = newMax;
      c.resourceValues[name] = (int.tryParse(value.text) ?? current).clamp(0, newMax);
      if (name.toLowerCase() == 'vida') { c.maxHp = newMax; c.hp = c.resourceValues[name]!; }
      if (name.toLowerCase() == 'energia') { c.maxEnergy = newMax; c.energy = c.resourceValues[name]!; }
      await state.updateCharacter(c);
      if (mounted) setState(() {});
    }
    value.dispose(); max.dispose();
  }

  Future<void> _changeResource(Character c, String name, int delta) async {
    final state = context.read<AppState>();
    final max = c.resourceMaxValues[name] ?? 0;
    final current = c.resourceValues[name] ?? 0;
    c.resourceValues[name] = (current + delta).clamp(0, max);
    if (name.toLowerCase() == 'vida') c.hp = c.resourceValues[name]!;
    if (name.toLowerCase() == 'energia') c.energy = c.resourceValues[name]!;
    await state.updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editAttribute(Character c, String name) async {
    final controller = TextEditingController(text: (c.attributes[name] ?? 0).toString());
    final result = await showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Editar $name'),
        content: TextField(controller: controller, autofocus: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, int.tryParse(controller.text)), child: const Text('Salvar')),
        ],
      ),
    );
    controller.dispose();
    if (result == null) return;
    c.attributes[name] = result;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editSection(Character c, String name) async {
    final controller = TextEditingController(text: c.sectionNotes[name] ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(name),
        content: TextField(controller: controller, autofocus: true, textCapitalization: TextCapitalization.sentences, minLines: 5, maxLines: 12, decoration: const InputDecoration(hintText: 'Escreva aqui...')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Salvar')),
        ],
      ),
    );
    controller.dispose();
    if (result == null) return;
    c.sectionNotes[name] = result;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _toggleSkill(Character c, String skill) async {
    if (c.skills.contains(skill)) { c.skills.remove(skill); } else { c.skills.add(skill); }
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _reorderGeneral(Character c, int oldIndex, int newIndex) async {
    const validIds = ['health', 'energy', 'attributes', 'skillTree', 'abilities', 'inventory'];
    final order = <String>[];
    for (final id in c.generalOrder) {
      if (validIds.contains(id) && !order.contains(id)) order.add(id);
    }
    for (final id in validIds) {
      if (!order.contains(id)) order.add(id);
    }
    if (newIndex > oldIndex) newIndex -= 1;
    final item = order.removeAt(oldIndex);
    order.insert(newIndex, item);
    c.generalOrder = order;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }


  static const _defaultTabOrder = ['general', 'attributesResources', 'actions', 'skillTree', 'abilities', 'skills', 'inventory', 'sections'];

  List<String> _normalizedTabOrder(Character c) {
    final order = <String>[];
    for (final id in c.sheetTabOrder) {
      if (_defaultTabOrder.contains(id) && !order.contains(id)) order.add(id);
    }
    for (final id in _defaultTabOrder) {
      if (!order.contains(id)) order.add(id);
    }
    return order;
  }

  String _tabLabel(String id) => switch (id) {
    'general' => 'Resumo',
    'attributesResources' => 'Status',
    'abilities' => 'Habilidades',
    'actions' => 'Ações',
    'skillTree' => 'Árvore',
    'skills' => 'Perícias',
    'inventory' => 'Inventário',
    'sections' => 'Seções',
    _ => id,
  };

  Widget _tabPage(String id, Character c, RpgSystem system) => switch (id) {
    'general' => _GeneralTab(character: c, system: system, onReorder: _reorderGeneral, onChangeResource: _changeResource, onEditResource: _editResource),
    'attributesResources' => _AttributesResourcesTab(character: c, system: system, onEditAttribute: _editAttribute, onChangeResource: _changeResource, onEditResource: _editResource),
    'actions' => _ActionsTab(character: c, system: system),
    'abilities' => _CharacterItemsTab(character: c, items: c.abilities, descriptions: c.abilityDescriptions, details: c.abilityDetails, title: 'Habilidades', singular: 'habilidade', hint: 'Nome da habilidade', iconRole: 'abilities', isAbility: true),
    'skillTree' => SkillTreeScreen(characterId: c.id, embedded: true),
    'skills' => _SkillsTab(character: c, system: system, onToggle: _toggleSkill),
    'inventory' => _CharacterItemsTab(character: c, items: c.inventory, descriptions: c.inventoryDescriptions, details: c.inventoryDetails, title: 'Inventário', singular: 'item', hint: 'Nome do item', iconRole: 'inventory', isAbility: false),
    'sections' => _SectionsTab(character: c, system: system, onEdit: _editSection),
    _ => const SizedBox.shrink(),
  };

  Future<void> _customizeSheet(Character c) async {
    var draft = _normalizedTabOrder(c);
    final saved = await showModalBottomSheet<List<String>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          child: SizedBox(
            height: MediaQuery.sizeOf(context).height * .72,
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.dashboard_customize_outlined),
                  title: const Text('Personalizar ficha'),
                  subtitle: const Text('Arraste para escolher a ordem das abas. A aba Resumo também pode ser reposicionada.'),
                  trailing: TextButton(
                    onPressed: () => setSheetState(() => draft = List<String>.from(_defaultTabOrder)),
                    child: const Text('Restaurar'),
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: ReorderableListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: draft.length,
                    onReorder: (oldIndex, newIndex) {
                      setSheetState(() {
                        if (newIndex > oldIndex) newIndex--;
                        final item = draft.removeAt(oldIndex);
                        draft.insert(newIndex, item);
                      });
                    },
                    itemBuilder: (context, index) {
                      final id = draft[index];
                      return ListTile(
                        key: ValueKey('sheet-tab-$id'),
                        leading: Icon(themedIcon(context.read<AppState>().themeId, id)),
                        title: Text(_tabLabel(id)),
                        trailing: const Icon(Icons.drag_handle),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () => Navigator.pop(sheetContext, draft),
                      icon: const Icon(Icons.save_outlined),
                      label: const Text('Salvar organização'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (saved == null) return;
    c.sheetTabOrder = saved;
    tab = 0;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final c = _findCharacter(state);
    if (c == null) return const Scaffold(body: Center(child: Text('Ficha não encontrada.')));
    final system = _findSystem(state, c);
    if (system == null) return const Scaffold(body: Center(child: Text('Sistema não encontrado.')));

    // Garante que fichas antigas recebam os campos do sistema atual.
    for (final attribute in system.attributes) { c.attributes.putIfAbsent(attribute, () => 10); }
    for (final resource in system.resources) {
      c.resourceValues.putIfAbsent(resource, () => 0);
      c.resourceMaxValues.putIfAbsent(resource, () => 0);
    }
    for (final section in system.sections) { c.sectionNotes.putIfAbsent(section, () => ''); }

    return Scaffold(
      appBar: AppBar(
        title: Text(c.name),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Compartilhar',
            icon: const Icon(Icons.ios_share),
            onSelected: (value) async {
              try {
                if (value == 'file') {
                  await RpgFileService.exportCharacter(c, system);
                } else if (value == 'summary') {
                  await RpgFileService.shareCharacterSummary(c, system);
                }
              } catch (e) {
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Não foi possível compartilhar: $e')),
                );
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'file',
                child: ListTile(
                  leading: Icon(Icons.file_upload_outlined),
                  title: Text('Compartilhar ficha .rpg'),
                  subtitle: Text('Outra pessoa pode importar e editar uma cópia.'),
                ),
              ),
              PopupMenuItem(
                value: 'summary',
                child: ListTile(
                  leading: Icon(Icons.text_snippet_outlined),
                  title: Text('Compartilhar resumo'),
                  subtitle: Text('Envia uma versão em texto para consulta.'),
                ),
              ),
            ],
          ),
          IconButton(onPressed: () => _customizeSheet(c), icon: const Icon(Icons.dashboard_customize_outlined), tooltip: 'Personalizar ficha'),
          IconButton(onPressed: _editBasic, icon: const Icon(Icons.edit), tooltip: 'Editar dados'),
        ],
      ),
      body: Column(
        children: [
          _Header(character: c, system: system),
          Builder(
            builder: (context) {
              final order = _normalizedTabOrder(c);
              if (tab >= order.length) tab = 0;
              return Expanded(
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        border: Border.symmetric(
                          horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.18)),
                        ),
                      ),
                      child: SizedBox(
                        height: 78,
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: order.asMap().entries.map((entry) {
                              final index = entry.key;
                              final id = entry.value;
                              final selected = tab == index;
                              return InkWell(
                                onTap: () => setState(() => tab = index),
                                child: SizedBox(
                                  width: 92,
                                  height: 78,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      AnimatedContainer(
                                        duration: const Duration(milliseconds: 160),
                                        width: 52,
                                        height: 34,
                                        alignment: Alignment.center,
                                        decoration: ShapeDecoration(
                                          color: selected ? Theme.of(context).colorScheme.primaryContainer : Colors.transparent,
                                          shape: themedNavigationIndicatorShape(
                                            state.themeId,
                                            themePreset(state.themeId).radius,
                                          ),
                                        ),
                                        child: Icon(
                                          themedIcon(state.themeId, id),
                                          size: 24,
                                          color: selected
                                              ? Theme.of(context).colorScheme.onPrimaryContainer
                                              : Theme.of(context).colorScheme.onSurfaceVariant,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      SizedBox(
                                        height: 18,
                                        child: Text(
                                          _tabLabel(id),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.center,
                                          style: Theme.of(context).textTheme.labelMedium?.copyWith(fontWeight: selected ? FontWeight.w700 : FontWeight.w600),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: IndexedStack(
                        index: tab,
                        children: order.map((id) => _tabPage(id, c, system)).toList(),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _GeneralTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, int, int) onReorder;
  final Future<void> Function(Character, String, int) onChangeResource;
  final Future<void> Function(Character, String) onEditResource;

  const _GeneralTab({
    required this.character,
    required this.system,
    required this.onReorder,
    required this.onChangeResource,
    required this.onEditResource,
  });

  String _lifeResourceName() {
    for (final name in system.resources) {
      if (name.toLowerCase() == 'vida') return name;
    }
    return system.resources.isNotEmpty ? system.resources.first : '';
  }

  String _energyResourceName() {
    for (final name in system.resources) {
      if (name.toLowerCase() == 'energia') return name;
    }
    for (final name in system.resources) {
      if (name != _lifeResourceName()) return name;
    }
    return '';
  }

  Widget _resourceSummaryCard(
    BuildContext context, {
    required String keyId,
    required String title,
    required String resourceName,
    required bool secondary,
  }) {
    final theme = Theme.of(context);
    final value = resourceName.isEmpty ? 0 : (character.resourceValues[resourceName] ?? 0);
    final max = resourceName.isEmpty ? 0 : (character.resourceMaxValues[resourceName] ?? 0);
    final progress = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0);
    final themeId = context.watch<AppState>().themeId;
    return Card(
      key: ValueKey('general-$keyId'),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(secondary ? Icons.bolt : themedIcon(themeId, 'resources')),
            const SizedBox(width: 8),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold))),
            if (resourceName.isNotEmpty) ...[
              IconButton(
                tooltip: 'Diminuir',
                visualDensity: VisualDensity.compact,
                onPressed: () => onChangeResource(character, resourceName, -1),
                icon: const Icon(Icons.remove),
              ),
              Text('$value / $max', style: theme.textTheme.titleMedium),
              IconButton(
                tooltip: 'Aumentar',
                visualDensity: VisualDensity.compact,
                onPressed: () => onChangeResource(character, resourceName, 1),
                icon: const Icon(Icons.add),
              ),
              IconButton(
                tooltip: 'Ajustar valor',
                visualDensity: VisualDensity.compact,
                onPressed: () => onEditResource(character, resourceName),
                icon: const Icon(Icons.tune, size: 20),
              ),
            ],
          ]),
          if (resourceName.isEmpty) ...[
            const SizedBox(height: 8),
            const Text('Nenhum recurso configurado.'),
          ],
          const SizedBox(height: 8),
          if (resourceName.isNotEmpty)
            _ThemedResourceBar(
              value: progress,
              themeId: themeId,
              secondary: secondary,
            ),
        ]),
      ),
    );
  }

  Widget _verticalSummaryItems(List<String> names, Map<String, Map<String, dynamic>> details, {required bool ability}) {
    if (names.isEmpty) return Text(ability ? 'Nenhuma habilidade.' : 'Nenhum item.');
    final compact = context.watch<AppState>().compactMode;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: names.take(5).map((name) {
        final d = details[name] ?? const <String, dynamic>{};
        final category = d['category']?.toString().trim().isNotEmpty == true ? d['category'].toString() : (ability ? 'Habilidade' : 'Outro');
        final damage = d['damage']?.toString().trim() ?? '';
        final qty = d['quantity']?.toString() ?? '';
        final ammo = d['ammo']?.toString() ?? '';
        final ammoMax = d['ammoMax']?.toString() ?? '';
        final cost = d['cost']?.toString() ?? '';
        final resource = d['resource']?.toString() ?? 'Energia';
        final durationType = d['durationType']?.toString() ?? '';
        final turns = d['turns']?.toString() ?? '';
        return Padding(
          padding: EdgeInsets.only(bottom: compact ? 6 : 10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(category, style: Theme.of(context).textTheme.labelSmall?.copyWith(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700)),
            Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
            if (damage.isNotEmpty) Text('Dano: $damage'),
            if (!ability && category == 'Consumível') Text('Quantidade: ${qty.isEmpty ? '1' : qty}'),
            if (!ability && category == 'Arma' && ammoMax.isNotEmpty) Text('Munição: ${ammo.isEmpty ? ammoMax : ammo}/$ammoMax'),
            if (ability && category == 'Magia' && cost.isNotEmpty) Text('Custo: $cost $resource'),
            if (ability && durationType == 'turns' && turns.isNotEmpty) Text('Duração: $turns turno(s)'),
            if (ability && durationType == 'instant') const Text('Duração: Instantânea'),
          ]),
        );
      }).toList(),
    );
  }

  Widget _summaryCard(BuildContext context, String id) {
    final themeId = context.watch<AppState>().themeId;
    switch (id) {
      case 'attributes':
        return Card(
          key: const ValueKey('general-attributes'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(themedIcon(themeId, 'attributes')), const SizedBox(width: 8), const Text('Atributos', style: TextStyle(fontWeight: FontWeight.bold))]),
              const SizedBox(height: 10),
              if (system.attributes.isEmpty)
                const Text('Nenhum atributo configurado.')
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: system.attributes.map((name) => Chip(label: Text('$name: ${character.attributes[name] ?? 0}'))).toList(),
                ),
            ]),
          ),
        );
      case 'health':
        final resource = _lifeResourceName();
        return _resourceSummaryCard(
          context,
          keyId: 'health',
          title: resource.isEmpty ? 'Vida' : resource,
          resourceName: resource,
          secondary: false,
        );
      case 'energy':
        final resource = _energyResourceName();
        return _resourceSummaryCard(
          context,
          keyId: 'energy',
          title: resource.isEmpty ? 'Energia' : resource,
          resourceName: resource,
          secondary: true,
        );
      case 'skillTree':
        final unlocked = character.skillTree.where((node) => node['unlocked'] == true).toList();
        final names = unlocked.map((node) => node['name']?.toString() ?? 'Habilidade').where((name) => name.isNotEmpty).toList();
        return Card(
          key: const ValueKey('general-skill-tree'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(themedIcon(themeId, 'skillTree')),
                const SizedBox(width: 8),
                const Expanded(child: Text('Árvore de Habilidades', style: TextStyle(fontWeight: FontWeight.bold))),
                Text('${unlocked.length}/${character.skillTree.length}'),
              ]),
              const SizedBox(height: 8),
              _compactLines(names, character.skillTree.isEmpty ? 'Nenhuma skill criada.' : 'Nenhuma skill desbloqueada.'),
            ]),
          ),
        );
      case 'inventory':
        final lines = character.inventory;
        return Card(
          key: const ValueKey('general-inventory'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(themedIcon(themeId, 'inventory')), const SizedBox(width: 8), const Text('Inventário', style: TextStyle(fontWeight: FontWeight.bold)), const Spacer(), Text('${character.inventory.length} item(ns)')]),
              const SizedBox(height: 8),
              _verticalSummaryItems(lines, character.inventoryDetails, ability: false),
            ]),
          ),
        );
      case 'abilities':
        final lines = character.abilities;
        return Card(
          key: const ValueKey('general-abilities'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(themedIcon(themeId, 'abilities')), const SizedBox(width: 8), const Text('Habilidades', style: TextStyle(fontWeight: FontWeight.bold)), const Spacer(), Text('${character.abilities.length}')]),
              const SizedBox(height: 8),
              _verticalSummaryItems(lines, character.abilityDetails, ability: true),
            ]),
          ),
        );
      default:
        return const SizedBox.shrink(key: ValueKey('general-unknown'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final validIds = const ['health', 'energy', 'attributes', 'skillTree', 'abilities', 'inventory'];
    final order = <String>[];
    for (final id in character.generalOrder) {
      if (validIds.contains(id) && !order.contains(id)) order.add(id);
    }
    for (final id in validIds) {
      if (!order.contains(id)) order.add(id);
    }

    return ReorderableListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      itemCount: order.length,
      onReorder: (oldIndex, newIndex) => onReorder(character, oldIndex, newIndex),
      buildDefaultDragHandles: false,
      itemBuilder: (context, index) {
        final id = order[index];
        return Padding(
          key: ValueKey('general-item-$id'),
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(children: [
            Expanded(child: _summaryCard(context, id)),
            ReorderableDragStartListener(
              index: index,
              child: const Padding(padding: EdgeInsets.only(left: 8), child: Icon(Icons.drag_handle)),
            ),
          ]),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  const _Header({required this.character, required this.system});

  @override
  Widget build(BuildContext context) {
    final hasPortrait = character.portraitPath.isNotEmpty && File(character.portraitPath).existsSync();
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        CircleAvatar(
          radius: 34,
          backgroundImage: hasPortrait ? FileImage(File(character.portraitPath)) : null,
          child: hasPortrait ? null : Text(
            character.name.isEmpty ? '?' : character.name[0].toUpperCase(),
            style: const TextStyle(fontSize: 28),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(character.name, style: Theme.of(context).textTheme.titleLarge),
          Text('${character.race.isEmpty ? 'Sem raça' : character.race} • ${character.className.isEmpty ? 'Sem classe' : character.className} • Nível ${character.level}'),
          const SizedBox(height: 4),
          Chip(avatar: const Icon(Icons.auto_awesome, size: 16), label: Text(system.name)),
        ])),
      ]),
    );
  }
}

class _AttributesResourcesTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onEditAttribute;
  final Future<void> Function(Character, String, int) onChangeResource;
  final Future<void> Function(Character, String) onEditResource;

  const _AttributesResourcesTab({
    required this.character,
    required this.system,
    required this.onEditAttribute,
    required this.onChangeResource,
    required this.onEditResource,
  });

  @override
  Widget build(BuildContext context) {
    final themeId = context.watch<AppState>().themeId;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Icon(themedIcon(themeId, 'attributes'), size: 22),
            const SizedBox(width: 8),
            Text('Atributos', style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
        const SizedBox(height: 10),
        if (system.attributes.isEmpty)
          const Text('Este sistema não possui atributos configurados.')
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: system.attributes.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 2.75,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemBuilder: (_, index) {
              final name = system.attributes[index];
              final value = character.attributes[name] ?? 0;
              return Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => onEditAttribute(character, name),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w700),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 0),
                        Text(
                          '$value',
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        const SizedBox(height: 24),
        Row(
          children: [
            Icon(themedIcon(themeId, 'resources')),
            const SizedBox(width: 8),
            Text('Recursos', style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
        const SizedBox(height: 10),
        if (system.resources.isEmpty)
          const Text('Este sistema não possui recursos configurados.'),
        ...system.resources.map((name) {
          final value = character.resourceValues[name] ?? 0;
          final max = character.resourceMaxValues[name] ?? 0;
          final progress = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0);
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(name.toLowerCase() == 'vida'
                          ? themedIcon(themeId, 'resources')
                          : Icons.bolt),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      IconButton(
                        onPressed: () => onChangeResource(character, name, -1),
                        icon: const Icon(Icons.remove),
                      ),
                      Text('$value / $max'),
                      IconButton(
                        onPressed: () => onChangeResource(character, name, 1),
                        icon: const Icon(Icons.add),
                      ),
                      IconButton(
                        onPressed: () => onEditResource(character, name),
                        icon: const Icon(Icons.tune),
                      ),
                    ],
                  ),
                  _ThemedResourceBar(
                    value: progress,
                    themeId: themeId,
                    secondary: name.toLowerCase() != 'vida',
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }
}

class _ThemedResourceBar extends StatelessWidget {
  final double value;
  final String themeId;
  final bool secondary;

  const _ThemedResourceBar({
    required this.value,
    required this.themeId,
    this.secondary = false,
  });

  @override
  Widget build(BuildContext context) {
    final fillColors = themedResourceBarColors(themeId, secondary: secondary);
    final trackColor = themedResourceTrackColor(themeId);
    final scheme = Theme.of(context).colorScheme;
    final normalized = value.clamp(0.0, 1.0);

    return Container(
      height: 14,
      decoration: BoxDecoration(
        color: trackColor,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: scheme.outlineVariant.withOpacity(.45)),
        boxShadow: [
          BoxShadow(
            color: scheme.primary.withOpacity(.08),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final fillWidth = constraints.maxWidth * normalized;
          return Stack(
            children: [
              if (fillWidth > 0)
                Align(
                  alignment: Alignment.center,
                  child: Container(
                  width: fillWidth,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: fillColors),
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
                ),
              if (themeId == 'cyberpunk' && fillWidth > 18)
                Positioned.fill(
                  child: IgnorePointer(
                    child: CustomPaint(
                      painter: _CyberpunkBarPainter(progress: normalized),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _CyberpunkBarPainter extends CustomPainter {
  final double progress;
  const _CyberpunkBarPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final activeWidth = size.width * progress;
    final paint = Paint()
      ..color = Colors.white.withOpacity(.14)
      ..strokeWidth = 1;
    const segment = 16.0;
    for (double x = segment; x < activeWidth; x += segment) {
      canvas.drawLine(Offset(x, 2), Offset(x, size.height - 2), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _CyberpunkBarPainter oldDelegate) => oldDelegate.progress != progress;
}

class _SkillsTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onToggle;
  const _SkillsTab({required this.character, required this.system, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Perícias do sistema', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8),
      if (system.skills.isEmpty) const Text('Este sistema não possui perícias configuradas.')
      else ...system.skills.map((skill) => Card(child: CheckboxListTile(value: character.skills.contains(skill), onChanged: (_) => onToggle(character, skill), title: Text(skill), secondary: const Icon(Icons.psychology)))),
      const SizedBox(height: 16),
      if (character.skills.isNotEmpty) Text('Perícias selecionadas: ${character.skills.join(', ')}', style: Theme.of(context).textTheme.bodySmall),
    ]);
  }
}

class _SectionsTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onEdit;
  const _SectionsTab({required this.character, required this.system, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Seções da ficha', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 10),
      if (system.sections.isEmpty) const Text('Este sistema não possui seções configuradas.'),
      ...system.sections.map((section) => Card(child: ListTile(title: Text(section), subtitle: Text((character.sectionNotes[section] ?? '').isEmpty ? 'Toque para preencher.' : character.sectionNotes[section]!), trailing: const Icon(Icons.edit), onTap: () => onEdit(character, section)))),
    ]);
  }
}

class _ActionsTab extends StatefulWidget {
  final Character character;
  final RpgSystem system;
  const _ActionsTab({required this.character, required this.system});

  @override
  State<_ActionsTab> createState() => _ActionsTabState();
}

class _ActionsTabState extends State<_ActionsTab> with SingleTickerProviderStateMixin {
  late final AnimationController _idle;
  @override
  void initState() {
    super.initState();
    _idle = AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))..repeat(reverse: true);
  }
  @override
  void dispose() { _idle.dispose(); super.dispose(); }

  Future<void> _save([String? message]) async {
    await context.read<AppState>().updateCharacter(widget.character);
    if (!mounted) return;
    setState(() {});
    if (message != null) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), duration: const Duration(milliseconds: 900)));
  }

  Future<void> _useItem(String name) async {
    final d = widget.character.inventoryDetails[name] ??= <String, dynamic>{};
    final cat = d['category']?.toString() ?? 'Outro';
    if (cat == 'Consumível') {
      final q = (d['quantity'] as num?)?.toInt() ?? 1;
      if (q <= 0) return _save('Sem unidades de $name.');
      d['quantity'] = q - 1;
      return _save('$name usado. Restam ${q - 1}.');
    }
    if (cat == 'Arma') {
      final max = (d['ammoMax'] as num?)?.toInt() ?? 0;
      final ammo = (d['ammo'] as num?)?.toInt() ?? max;
      if (max > 0) {
        if (ammo <= 0) return _save('$name está sem munição.');
        d['ammo'] = ammo - 1;
      }
      return _save('$name usado${max > 0 ? '. Munição: ${d['ammo']}/$max' : ''}.');
    }
  }

  Future<void> _reload(String name) async {
    final d = widget.character.inventoryDetails[name] ??= <String, dynamic>{};
    final max = (d['ammoMax'] as num?)?.toInt() ?? 0;
    if (max <= 0) return;
    d['ammo'] = max;
    await _save('$name recarregada.');
  }

  Future<void> _cast(String name) async {
    final d = widget.character.abilityDetails[name] ??= <String, dynamic>{};
    final cost = (d['cost'] as num?)?.toInt() ?? 0;
    final resource = d['resource']?.toString().isNotEmpty == true ? d['resource'].toString() : 'Energia';
    final current = widget.character.resourceValues[resource] ?? 0;
    if (current < cost) return _save('$resource insuficiente para $name.');
    widget.character.resourceValues[resource] = current - cost;
    if (resource.toLowerCase() == 'energia') widget.character.energy = current - cost;
    await _save('$name lançada. -$cost $resource.');
  }

  Widget _resource(String name) {
    final current = widget.character.resourceValues[name] ?? 0;
    final max = widget.character.resourceMaxValues[name] ?? 0;
    final value = max <= 0 ? 0.0 : (current / max).clamp(0.0, 1.0);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Text(name, style: const TextStyle(fontWeight: FontWeight.w700)), const Spacer(), Text('$current/$max')]),
      const SizedBox(height: 5), LinearProgressIndicator(value: value, minHeight: 8),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.character;
    final compact = context.watch<AppState>().compactMode;
    final hasPortrait = c.portraitPath.isNotEmpty && File(c.portraitPath).existsSync();
    final usableItems = c.inventory.where((n) { final cat = c.inventoryDetails[n]?['category']; return cat == 'Consumível' || cat == 'Arma'; }).toList();
    final activeAbilities = c.abilities.where((n) { final cat = c.abilityDetails[n]?['category']; return cat == 'Magia' || cat == 'Técnica' || cat == 'Habilidade'; }).toList();
    return ListView(padding: EdgeInsets.all(compact ? 8 : 14), children: [
      Card(child: Padding(padding: EdgeInsets.all(compact ? 10 : 14), child: Column(children: [
        SizedBox(height: compact ? 150 : 210, child: Center(child: AnimatedBuilder(animation: _idle, builder: (_, child) => Transform.translate(offset: Offset(0, -3 + (_idle.value * 6)), child: Transform.scale(scale: .99 + (_idle.value * .015), child: child)), child: hasPortrait ? Image.file(File(c.portraitPath), fit: BoxFit.contain) : Icon(Icons.accessibility_new_rounded, size: compact ? 90 : 130)))),
        const SizedBox(height: 8), _resource('Vida'), const SizedBox(height: 10), _resource('Energia'),
      ]))),
      SizedBox(height: compact ? 8 : 12),
      Text('Ações rápidas', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
      SizedBox(height: compact ? 4 : 8),
      ...usableItems.map((name) { final d=c.inventoryDetails[name]??{}; final cat=d['category']?.toString()??''; final ammo=(d['ammo'] as num?)?.toInt(); final max=(d['ammoMax'] as num?)?.toInt(); final q=(d['quantity'] as num?)?.toInt(); return Card(child: Padding(padding: EdgeInsets.all(compact?8:12), child: Row(children:[Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text(cat, style: Theme.of(context).textTheme.labelSmall), Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), if(cat=='Consumível') Text('Quantidade: ${q??1}'), if(cat=='Arma' && max!=null && max>0) Text('Munição: ${ammo??max}/$max')])), FilledButton(onPressed: ()=>_useItem(name), child: Text(cat=='Arma'?'Atirar':'Usar')), if(cat=='Arma' && max!=null && max>0) IconButton(onPressed: ()=>_reload(name), tooltip:'Recarregar', icon: const Icon(Icons.refresh))]))); }),
      ...activeAbilities.map((name) { final d=c.abilityDetails[name]??{}; final cat=d['category']?.toString()??''; final cost=(d['cost'] as num?)?.toInt()??0; final resource=d['resource']?.toString()??'Energia'; return Card(child: Padding(padding: EdgeInsets.all(compact?8:12), child: Row(children:[Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text(cat, style: Theme.of(context).textTheme.labelSmall), Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), if(cost>0) Text('Custo: $cost $resource')])), FilledButton(onPressed: ()=>_cast(name), child: Text(cat=='Magia'?'Lançar magia':'Usar'))]))); }),
      if (usableItems.isEmpty && activeAbilities.isEmpty) const Padding(padding: EdgeInsets.all(18), child: Text('Cadastre consumíveis, armas, magias ou habilidades ativas para usá-las aqui.')),
    ]);
  }
}

class _CharacterItemsTab extends StatefulWidget {
  final Character character;
  final List<String> items;
  final Map<String, String> descriptions;
  final Map<String, Map<String, dynamic>> details;
  final String title;
  final String singular;
  final String hint;
  final String iconRole;
  final bool isAbility;

  const _CharacterItemsTab({
    required this.character,
    required this.items,
    required this.descriptions,
    required this.details,
    required this.title,
    required this.singular,
    required this.hint,
    required this.iconRole,
    required this.isAbility,
  });

  @override
  State<_CharacterItemsTab> createState() => _CharacterItemsTabState();
}

class _CharacterItemsTabState extends State<_CharacterItemsTab> {
  List<String> get _categories => widget.isAbility
      ? const ['Habilidade', 'Magia', 'Técnica', 'Passiva', 'Outro']
      : const ['Arma', 'Armadura', 'Consumível', 'Acessório', 'Ferramenta', 'Outro'];

  Future<void> _openEditor({int? index}) async {
    final editing = index != null;
    final oldName = editing ? widget.items[index] : '';
    final old = editing ? (widget.details[oldName] ?? <String, dynamic>{}) : <String, dynamic>{};
    final name = TextEditingController(text: oldName);
    final description = TextEditingController(text: editing ? (widget.descriptions[oldName] ?? '') : '');
    final damage = TextEditingController(text: old['damage']?.toString() ?? '');
    final turns = TextEditingController(text: old['turns']?.toString() ?? '');
    final quantity = TextEditingController(text: old['quantity']?.toString() ?? '1');
    final ammo = TextEditingController(text: old['ammo']?.toString() ?? '');
    final ammoMax = TextEditingController(text: old['ammoMax']?.toString() ?? '');
    final cost = TextEditingController(text: old['cost']?.toString() ?? '');
    String resource = old['resource']?.toString() ?? 'Energia';
    String category = old['category']?.toString() ?? (widget.isAbility ? 'Habilidade' : 'Outro');
    if (!_categories.contains(category)) category = widget.isAbility ? 'Habilidade' : 'Outro';
    String durationType = old['durationType']?.toString() ?? 'instant';

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) {
          final isMagic = widget.isAbility && category == 'Magia';
          final isWeapon = !widget.isAbility && category == 'Arma';
          final isConsumable = !widget.isAbility && category == 'Consumível';
          return AlertDialog(
            title: Text(editing ? 'Editar ${widget.singular}' : 'Adicionar ${widget.singular}'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(controller: name, textCapitalization: TextCapitalization.sentences, autofocus: !editing, decoration: InputDecoration(labelText: widget.hint)),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: category,
                  decoration: const InputDecoration(labelText: 'Categoria'),
                  items: _categories.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                  onChanged: (v) => setDialogState(() => category = v ?? category),
                ),
                const SizedBox(height: 12),
                TextField(controller: description, textCapitalization: TextCapitalization.sentences, minLines: 3, maxLines: 6, decoration: const InputDecoration(labelText: 'Descrição', hintText: 'Detalhes, efeitos, observações...')),
                if (isWeapon || isMagic) ...[
                  const SizedBox(height: 12),
                  TextField(controller: damage, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Dano', hintText: 'Ex.: 1d8, 2d6+3 ou 5')),
                ],
                if (isWeapon) ...[
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: TextField(controller: ammo, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Munição atual'))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: ammoMax, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Munição máxima'))),
                  ]),
                ],
                if (isConsumable) ...[
                  const SizedBox(height: 12),
                  TextField(controller: quantity, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantidade')),
                ],
                if (isMagic && category != 'Passiva') ...[
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: TextField(controller: cost, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Custo'))),
                    const SizedBox(width: 8),
                    Expanded(child: DropdownButtonFormField<String>(value: widget.character.resourceValues.containsKey(resource) ? resource : (widget.character.resourceValues.keys.isNotEmpty ? widget.character.resourceValues.keys.first : 'Energia'), decoration: const InputDecoration(labelText: 'Recurso'), items: widget.character.resourceValues.keys.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(), onChanged: (v) => setDialogState(() => resource = v ?? resource))),
                  ]),
                ],
                if (isMagic) ...[
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: durationType,
                    decoration: const InputDecoration(labelText: 'Duração'),
                    items: const [
                      DropdownMenuItem(value: 'instant', child: Text('Direto / instantâneo')),
                      DropdownMenuItem(value: 'turns', child: Text('Por turnos')),
                    ],
                    onChanged: (v) => setDialogState(() => durationType = v ?? durationType),
                  ),
                  if (durationType == 'turns') ...[
                    const SizedBox(height: 12),
                    TextField(controller: turns, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantidade de turnos')),
                  ],
                ],
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
              FilledButton(
                onPressed: () {
                  final n = name.text.trim();
                  if (n.isEmpty) return;
                  Navigator.pop(dialogContext, {
                    'name': n,
                    'description': description.text.trim(),
                    'category': category,
                    'damage': (isWeapon || isMagic) ? damage.text.trim() : '',
                    'durationType': isMagic ? durationType : '',
                    'turns': isMagic && durationType == 'turns' ? turns.text.trim() : '',
                    'quantity': isConsumable ? (int.tryParse(quantity.text) ?? 1).clamp(0, 999999) : null,
                    'ammo': isWeapon ? (int.tryParse(ammo.text) ?? 0).clamp(0, 999999) : null,
                    'ammoMax': isWeapon ? (int.tryParse(ammoMax.text) ?? 0).clamp(0, 999999) : null,
                    'cost': isMagic ? (int.tryParse(cost.text) ?? 0).clamp(0, 999999) : null,
                    'resource': isMagic ? resource : '',
                  });
                },
                child: const Text('Salvar'),
              ),
            ],
          );
        },
      ),
    );
    name.dispose(); description.dispose(); damage.dispose(); turns.dispose(); quantity.dispose(); ammo.dispose(); ammoMax.dispose(); cost.dispose();
    if (result == null) return;
    final newName = result['name'] as String;
    if (editing) {
      widget.items[index] = newName;
      if (oldName != newName) {
        widget.descriptions.remove(oldName);
        widget.details.remove(oldName);
      }
    } else {
      widget.items.add(newName);
    }
    widget.descriptions[newName] = result['description'] as String? ?? '';
    widget.details[newName] = Map<String, dynamic>.from(result)..remove('name')..remove('description');
    await context.read<AppState>().updateCharacter(widget.character);
    if (mounted) setState(() {});
  }

  Future<void> _delete(int index) async {
    final removed = widget.items[index];
    widget.items.removeAt(index);
    widget.descriptions.remove(removed);
    widget.details.remove(removed);
    await context.read<AppState>().updateCharacter(widget.character);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final icon = themedIcon(context.watch<AppState>().themeId, widget.iconRole);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(children: [
              Row(children: [Icon(icon), const SizedBox(width: 8), Text(widget.title, style: Theme.of(context).textTheme.titleMedium), const Spacer(), IconButton(onPressed: () => _openEditor(), icon: const Icon(Icons.add_circle))]),
              if (widget.items.isEmpty)
                const Padding(padding: EdgeInsets.all(18), child: Text('Nenhum item adicionado.'))
              else
                ...widget.items.asMap().entries.map((entry) {
                  final item = entry.value;
                  final detail = widget.details[item] ?? const <String, dynamic>{};
                  final category = detail['category']?.toString() ?? 'Outro';
                  final damage = detail['damage']?.toString() ?? '';
                  final durationType = detail['durationType']?.toString() ?? '';
                  final turns = detail['turns']?.toString() ?? '';
                  final description = widget.descriptions[item] ?? '';
                  final qty = detail['quantity']?.toString() ?? '';
                  final ammo = detail['ammo']?.toString() ?? '';
                  final ammoMax = detail['ammoMax']?.toString() ?? '';
                  final cost = detail['cost']?.toString() ?? '';
                  final resource = detail['resource']?.toString() ?? 'Energia';
                  final vertical = <String>[category, item];
                  if (damage.isNotEmpty) vertical.add('Dano: $damage');
                  if (!widget.isAbility && category == 'Consumível') vertical.add('Quantidade: ${qty.isEmpty ? '1' : qty}');
                  if (!widget.isAbility && category == 'Arma' && ammoMax.isNotEmpty) vertical.add('Munição: ${ammo.isEmpty ? ammoMax : ammo}/$ammoMax');
                  if (widget.isAbility && category == 'Magia' && cost.isNotEmpty) vertical.add('Custo: $cost $resource');
                  if (durationType == 'turns' && turns.isNotEmpty) vertical.add('Duração: $turns turno(s)');
                  if (durationType == 'instant' && category == 'Magia') vertical.add('Duração: Instantânea');
                  if (description.isNotEmpty) vertical.add(description);
                  return ListTile(
                    dense: context.watch<AppState>().compactMode,
                    leading: Icon(icon),
                    title: Text(vertical.join('\n'), maxLines: 7, overflow: TextOverflow.ellipsis),
                    onTap: () => _openEditor(index: entry.key),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(tooltip: 'Editar', onPressed: () => _openEditor(index: entry.key), icon: const Icon(Icons.edit_outlined)),
                      IconButton(tooltip: 'Excluir', onPressed: () => _delete(entry.key), icon: const Icon(Icons.delete_outline)),
                    ]),
                  );
                }),
            ]),
          ),
        ),
      ],
    );
  }
}

