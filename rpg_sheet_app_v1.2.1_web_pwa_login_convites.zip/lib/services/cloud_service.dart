import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';

import 'package:shared_preferences/shared_preferences.dart';

class CloudSession {
  final String accessToken;
  final String refreshToken;
  final String userId;
  final String email;
  final bool isAnonymous;

  const CloudSession({
    required this.accessToken,
    required this.refreshToken,
    required this.userId,
    required this.email,
    required this.isAnonymous,
  });

  String get displayName => isAnonymous || email.trim().isEmpty ? 'Nuvem anônima' : email;
}

class CloudSnapshot {
  final Map<String, dynamic> payload;
  final DateTime? updatedAt;

  const CloudSnapshot({required this.payload, required this.updatedAt});
}

class CloudService {
  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://dbmyuocbglxbyiptjprd.supabase.co',
  );
  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'sb_publishable_mZfehw2WE9NYvy5hEAHVwQ_IuOuq-j3',
  );

  static const _accessKey = 'cloud_access_token';
  static const _refreshKey = 'cloud_refresh_token';
  static const _userIdKey = 'cloud_user_id';
  static const _emailKey = 'cloud_email';
  static const _anonymousKey = 'cloud_is_anonymous';
  static String get authCallbackUrl => kIsWeb ? Uri.base.origin : 'rpgsheet://auth-callback';

  static bool get configured => supabaseUrl.trim().isNotEmpty && supabaseAnonKey.trim().isNotEmpty;

  static Future<CloudSession?> loadSession() async {
    final prefs = await SharedPreferences.getInstance();
    final access = prefs.getString(_accessKey) ?? '';
    final refresh = prefs.getString(_refreshKey) ?? '';
    final userId = prefs.getString(_userIdKey) ?? '';
    final email = prefs.getString(_emailKey) ?? '';
    final isAnonymous = prefs.getBool(_anonymousKey) ?? email.isEmpty;
    if (access.isEmpty || userId.isEmpty) return null;
    return CloudSession(
      accessToken: access,
      refreshToken: refresh,
      userId: userId,
      email: email,
      isAnonymous: isAnonymous,
    );
  }

  static Future<void> _saveSession(CloudSession session) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_accessKey, session.accessToken);
    await prefs.setString(_refreshKey, session.refreshToken);
    await prefs.setString(_userIdKey, session.userId);
    await prefs.setString(_emailKey, session.email);
    await prefs.setBool(_anonymousKey, session.isAnonymous);
  }

  static Future<void> signOut() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_accessKey);
    await prefs.remove(_refreshKey);
    await prefs.remove(_userIdKey);
    await prefs.remove(_emailKey);
    await prefs.remove(_anonymousKey);
  }

  static Future<dynamic> _rawRequest(
    String method,
    Uri uri, {
    Map<String,String>? headers,
    Object? body,
  }) async {
    try {
      final request=http.Request(method,uri);
      request.headers.addAll({'Content-Type':'application/json','apikey':supabaseAnonKey,...?headers});
      if(body!=null) request.body=jsonEncode(body);
      final streamed=await request.send();
      final text=await streamed.stream.bytesToString();
      dynamic decoded;
      if(text.trim().isNotEmpty){try{decoded=jsonDecode(text);}catch(_){decoded={'message':text};}}
      if(streamed.statusCode<200 || streamed.statusCode>=300){
        final msg=decoded is Map?(decoded['msg']??decoded['message']??decoded['error_description']??decoded['error']):null;
        throw Exception(msg?.toString()??'Erro de conexão (${streamed.statusCode}).');
      }
      return decoded;
    } catch(e) {
      if(e is Exception) rethrow;
      throw Exception('Não foi possível acessar a nuvem. Verifique a conexão e tente novamente.');
    }
  }

  static Future<Map<String,dynamic>> _request(String method,Uri uri,{Map<String,String>? headers,Object? body}) async {
    final decoded=await _rawRequest(method,uri,headers:headers,body:body);
    if(decoded is Map) return Map<String,dynamic>.from(decoded);
    return {'data':decoded};
  }

  static CloudSession _sessionFromAuth(Map<String, dynamic> data, {String fallbackEmail = ''}) {
    final user = Map<String, dynamic>.from(data['user'] ?? {});
    final token = data['access_token']?.toString() ?? '';
    final userId = user['id']?.toString() ?? '';
    if (token.isEmpty || userId.isEmpty) {
      throw Exception('Não foi possível iniciar a sessão da nuvem.');
    }
    return CloudSession(
      accessToken: token,
      refreshToken: data['refresh_token']?.toString() ?? '',
      userId: userId,
      email: user['email']?.toString() ?? fallbackEmail,
      isAnonymous: user['is_anonymous'] == true || (user['email']?.toString() ?? fallbackEmail).isEmpty,
    );
  }

  static Future<CloudSession> signInAnonymously() async {
    if (!configured) throw Exception('Supabase ainda não configurado neste APK.');
    final data = await _request(
      'POST',
      Uri.parse('$supabaseUrl/auth/v1/signup'),
      body: const <String, dynamic>{},
    );
    final session = _sessionFromAuth(data);
    await _saveSession(session);
    return session;
  }

  static Future<CloudSession> ensureSession() async {
    final current = await loadSession();
    if (current == null) return signInAnonymously();
    if (current.refreshToken.isEmpty) return current;
    try {
      return await refreshSession(current);
    } catch (_) {
      return current;
    }
  }

  static Future<CloudSession> refreshSession(CloudSession current) async {
    if (current.refreshToken.isEmpty) return current;
    final data = await _request(
      'POST',
      Uri.parse('$supabaseUrl/auth/v1/token?grant_type=refresh_token'),
      body: {'refresh_token': current.refreshToken},
    );
    final session = _sessionFromAuth(data, fallbackEmail: current.email);
    await _saveSession(session);
    return session;
  }

  static Future<CloudSession> signIn(String email, String password) async {
    if (!configured) throw Exception('Supabase ainda não configurado neste APK.');
    final data = await _request(
      'POST',
      Uri.parse('$supabaseUrl/auth/v1/token?grant_type=password'),
      body: {'email': email.trim(), 'password': password},
    );
    final session = _sessionFromAuth(data, fallbackEmail: email.trim());
    await _saveSession(session);
    return session;
  }

  static Future<CloudSession?> signUp(String email, String password) async {
    if (!configured) throw Exception('Supabase ainda não configurado neste APK.');
    final data = await _request(
      'POST',
      Uri.parse('$supabaseUrl/auth/v1/signup'),
      body: {'email': email.trim(), 'password': password},
    );
    final token = data['access_token']?.toString() ?? '';
    if (token.isEmpty) return null;
    final session = _sessionFromAuth(data, fallbackEmail: email.trim());
    await _saveSession(session);
    return session;
  }

  static Future<CloudSession> protectAnonymousWithEmail(
    CloudSession current, {
    required String email,
    required String password,
  }) async {
    if (!current.isAnonymous) return current;
    if (email.trim().isEmpty || !email.contains('@')) {
      throw Exception('Informe um e-mail válido.');
    }
    if (password.length < 6) {
      throw Exception('A senha precisa ter pelo menos 6 caracteres.');
    }

    final data = await _request(
      'PUT',
      Uri.parse('$supabaseUrl/auth/v1/user?redirect_to=${Uri.encodeComponent(authCallbackUrl)}'),
      headers: {'Authorization': 'Bearer ${current.accessToken}'},
      body: {'email': email.trim(), 'password': password},
    );

    final user = Map<String, dynamic>.from(data);
    final updated = CloudSession(
      accessToken: current.accessToken,
      refreshToken: current.refreshToken,
      userId: current.userId,
      email: user['email']?.toString() ?? email.trim(),
      isAnonymous: user['is_anonymous'] == true,
    );
    await _saveSession(updated);
    return updated;
  }


  static Map<String, String> _callbackParameters(Uri uri) {
    final values = <String, String>{...uri.queryParameters};
    if (uri.fragment.isNotEmpty) {
      try { values.addAll(Uri.splitQueryString(uri.fragment)); } catch (_) {}
    }
    return values;
  }

  static Future<CloudSession?> handleAuthCallback(Uri uri) async {
    if (!kIsWeb && (uri.scheme != 'rpgsheet' || uri.host != 'auth-callback')) return null;
    final params = _callbackParameters(uri);
    final error = params['error_description'] ?? params['error'];
    if (error != null && error.trim().isNotEmpty) throw Exception(Uri.decodeComponent(error));

    final callbackAccess = params['access_token'] ?? '';
    final callbackRefresh = params['refresh_token'] ?? '';
    CloudSession? current = await loadSession();

    if (callbackAccess.isNotEmpty) {
      final user = await _request('GET', Uri.parse('$supabaseUrl/auth/v1/user'),
        headers: {'Authorization': 'Bearer $callbackAccess'});
      final session = CloudSession(
        accessToken: callbackAccess,
        refreshToken: callbackRefresh.isNotEmpty ? callbackRefresh : (current?.refreshToken ?? ''),
        userId: user['id']?.toString() ?? current?.userId ?? '',
        email: user['email']?.toString() ?? current?.email ?? '',
        isAnonymous: user['is_anonymous'] == true,
      );
      if (session.userId.isEmpty) throw Exception('Confirmação recebida, mas a sessão não pôde ser validada.');
      await _saveSession(session);
      return session;
    }

    if (current == null) return null;
    if (current.refreshToken.isNotEmpty) current = await refreshSession(current);
    final user = await _request('GET', Uri.parse('$supabaseUrl/auth/v1/user'),
      headers: {'Authorization': 'Bearer ${current.accessToken}'});
    final updated = CloudSession(
      accessToken: current.accessToken, refreshToken: current.refreshToken,
      userId: user['id']?.toString() ?? current.userId,
      email: user['email']?.toString() ?? current.email,
      isAnonymous: user['is_anonymous'] == true,
    );
    await _saveSession(updated);
    return updated;
  }


  static Future<void> uploadBackup(CloudSession session, Map<String, dynamic> payload) async {
    if (!configured) throw Exception('Supabase ainda não configurado neste APK.');
    await _request(
      'POST',
      Uri.parse('$supabaseUrl/rest/v1/rpg_cloud_backups?on_conflict=user_id'),
      headers: {
        'Authorization': 'Bearer ${session.accessToken}',
        'Prefer': 'resolution=merge-duplicates,return=minimal',
      },
      body: {
        'user_id': session.userId,
        'payload': payload,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
    );
  }

  static Future<CloudSnapshot?> downloadSnapshot(CloudSession session) async {
    if (!configured) throw Exception('Supabase ainda não configurado.');
    final uri=Uri.parse('$supabaseUrl/rest/v1/rpg_cloud_backups?user_id=eq.${Uri.encodeComponent(session.userId)}&select=payload,updated_at&limit=1');
    final decoded=await _rawRequest('GET',uri,headers:{'Authorization':'Bearer ${session.accessToken}'});
    if(decoded is! List || decoded.isEmpty) return null;
    final row=Map<String,dynamic>.from(decoded.first as Map);
    final payload=row['payload']; if(payload is! Map) return null;
    return CloudSnapshot(payload:Map<String,dynamic>.from(payload),updatedAt:DateTime.tryParse(row['updated_at']?.toString()??'')?.toUtc());
  }


  static Future<void> publishCharacter(CloudSession session, Map<String, dynamic> snapshot, String shareCode) async {
    await _request('POST', Uri.parse('$supabaseUrl/rest/v1/rpg_shared_characters?on_conflict=owner_id,character_id'), headers: {
      'Authorization': 'Bearer ${session.accessToken}',
      'Prefer': 'resolution=merge-duplicates,return=minimal',
    }, body: {'owner_id': session.userId, 'character_id': snapshot['id'], 'share_code': shareCode, 'snapshot': snapshot, 'updated_at': DateTime.now().toUtc().toIso8601String()});
  }

  static Future<Map<String,dynamic>?> lookupSharedCharacter(CloudSession session,String code) async {
    final decoded=await _rawRequest('POST',Uri.parse('$supabaseUrl/rest/v1/rpc/resolve_rpg_share_code'),headers:{'Authorization':'Bearer ${session.accessToken}'},body:{'p_code':code.trim().toUpperCase()});
    if(decoded is! List || decoded.isEmpty) return null;
    return Map<String,dynamic>.from(decoded.first as Map);
  }


  static Future<void> requestCharacterLink(CloudSession session, Map<String, dynamic> shared, String campaignId) async {
    await _request('POST', Uri.parse('$supabaseUrl/rest/v1/rpg_character_link_requests'), headers: {
      'Authorization': 'Bearer ${session.accessToken}', 'Prefer': 'return=minimal',
    }, body: {'share_code': shared['share_code'], 'character_owner_id': shared['owner_id'], 'requester_id': session.userId, 'campaign_id': campaignId, 'status': 'pending'});
  }


  static Future<void> publishSessionState(CloudSession session, String campaignId, Map<String, dynamic> state) async {
    await _request('POST', Uri.parse('$supabaseUrl/rest/v1/rpg_campaign_session_state?on_conflict=campaign_id'), headers: {
      'Authorization': 'Bearer ${session.accessToken}',
      'Prefer': 'resolution=merge-duplicates,return=minimal',
    }, body: {
      'campaign_id': campaignId,
      'master_id': session.userId,
      'round': state['round'] ?? 1,
      'active': state['active'] == true,
      'current_index': state['current_index'] ?? 0,
      'initiative': state['initiative'] ?? <dynamic>[],
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  static Future<Map<String,dynamic>?> fetchSessionState(CloudSession session,String campaignId) async {
    final uri=Uri.parse('$supabaseUrl/rest/v1/rpg_campaign_session_state?campaign_id=eq.${Uri.encodeComponent(campaignId)}&select=round,active,current_index,initiative,updated_at&limit=1');
    final decoded=await _rawRequest('GET',uri,headers:{'Authorization':'Bearer ${session.accessToken}'});
    if(decoded is! List || decoded.isEmpty) return null;
    return Map<String,dynamic>.from(decoded.first as Map);
  }


  static Future<List<Map<String,dynamic>>> incomingLinkRequests(CloudSession session) async {
    final uri=Uri.parse('$supabaseUrl/rest/v1/rpg_character_link_requests?character_owner_id=eq.${Uri.encodeComponent(session.userId)}&status=eq.pending&select=id,share_code,requester_id,campaign_id,status,created_at&order=created_at.desc');
    final decoded=await _rawRequest('GET',uri,headers:{'Authorization':'Bearer ${session.accessToken}'});
    return (decoded as List? ?? []).whereType<Map>().map((e)=>Map<String,dynamic>.from(e)).toList();
  }


  static Future<void> updateLinkStatus(CloudSession session, String requestId, String status) async {
    await _request('PATCH', Uri.parse('$supabaseUrl/rest/v1/rpg_character_link_requests?id=eq.${Uri.encodeComponent(requestId)}'), headers: {
      'Authorization': 'Bearer ${session.accessToken}', 'Prefer': 'return=minimal',
    }, body: {'status': status, 'updated_at': DateTime.now().toUtc().toIso8601String()});
  }

  static Future<List<Map<String,dynamic>>> approvedLinksForCampaign(CloudSession session,String campaignId) async {
    final uri=Uri.parse('$supabaseUrl/rest/v1/rpg_character_link_requests?requester_id=eq.${Uri.encodeComponent(session.userId)}&campaign_id=eq.${Uri.encodeComponent(campaignId)}&status=eq.approved&select=id,share_code,character_owner_id,campaign_id,status');
    final decoded=await _rawRequest('GET',uri,headers:{'Authorization':'Bearer ${session.accessToken}'});
    return (decoded as List? ?? []).whereType<Map>().map((e)=>Map<String,dynamic>.from(e)).toList();
  }


  static Future<Map<String,dynamic>?> sharedCharacterByCode(CloudSession session,String code) async {
    final uri=Uri.parse('$supabaseUrl/rest/v1/rpg_shared_characters?share_code=eq.${Uri.encodeComponent(code)}&select=owner_id,character_id,share_code,snapshot,master_patch,master_patch_updated_at,updated_at&limit=1');
    final decoded=await _rawRequest('GET',uri,headers:{'Authorization':'Bearer ${session.accessToken}'});
    if(decoded is! List || decoded.isEmpty) return null;
    return Map<String,dynamic>.from(decoded.first as Map);
  }


  static Future<void> updateSharedCharacterPatch(CloudSession session,String code,Map<String,dynamic> patch) async {
    final ok=await _rawRequest('POST',Uri.parse('$supabaseUrl/rest/v1/rpc/set_rpg_master_patch'),headers:{'Authorization':'Bearer ${session.accessToken}'},body:{'p_share_code':code,'p_patch':patch});
    if(ok!=true) throw Exception('Sem permissão para alterar esta ficha.');
  }

  static Future<void> clearSharedCharacterPatch(CloudSession session, String code) async {
    await _request('PATCH', Uri.parse('$supabaseUrl/rest/v1/rpg_shared_characters?share_code=eq.${Uri.encodeComponent(code)}'), headers: {
      'Authorization': 'Bearer ${session.accessToken}', 'Prefer':'return=minimal',
    }, body: {'master_patch': <String,dynamic>{}, 'master_patch_updated_at': null});
  }

  static Future<Map<String, dynamic>?> downloadBackup(CloudSession session) async {
    final snapshot = await downloadSnapshot(session);
    return snapshot?.payload;
  }
  static Future<bool> hasAppAccess(CloudSession session) async {
    final decoded=await _rawRequest('POST',Uri.parse('$supabaseUrl/rest/v1/rpc/has_rpg_app_access'),headers:{'Authorization':'Bearer ${session.accessToken}'},body:const {});
    return decoded==true;
  }

  static Future<bool> redeemInvite(CloudSession session,String code) async {
    final decoded=await _rawRequest('POST',Uri.parse('$supabaseUrl/rest/v1/rpc/redeem_rpg_invite'),headers:{'Authorization':'Bearer ${session.accessToken}'},body:{'p_code':code.trim().toUpperCase()});
    return decoded==true;
  }

  static Future<List<Map<String,dynamic>>> approvedPlayerCampaigns(CloudSession session) async {
    final uri=Uri.parse('$supabaseUrl/rest/v1/rpg_character_link_requests?character_owner_id=eq.${Uri.encodeComponent(session.userId)}&status=eq.approved&share_code=not.is.null&select=campaign_id,share_code');
    final decoded=await _rawRequest('GET',uri,headers:{'Authorization':'Bearer ${session.accessToken}'});
    return (decoded as List? ?? []).whereType<Map>().map((e)=>Map<String,dynamic>.from(e)).toList();
  }


}
