# RPG Sheet App — V0.8

## V0.8 — Mestre e Jogador
- Modo Jogador e Modo Mestre dentro das campanhas.
- Notas privadas exclusivas do Mestre.
- Controle de visibilidade das fichas da campanha.
- No Modo Jogador, fichas ocultas e ferramentas privadas não aparecem.
- Gerenciamento de personagens, NPCs e locais concentrado no Modo Mestre.
- Compatibilidade com campanhas salvas nas versões anteriores.
- Mantém fichas dinâmicas, sistemas personalizados, importação/exportação, backup e dados avançados.

Versão do projeto: 0.8.0+11
