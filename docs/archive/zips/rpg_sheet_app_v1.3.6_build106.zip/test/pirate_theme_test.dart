import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:rpg_sheet_app/app/theme.dart';

void main() {
  test('tema sombrio usa identidade pirata sem trocar o id persistido', () {
    final preset = themePreset('parchment');
    expect(preset.id, 'parchment');
    expect(preset.name, 'Sombrio Pirata');
    expect(preset.icon, Icons.anchor);
    expect(themedMainIcon('parchment', 'campaigns'), Icons.sailing);
    expect(themedMainIcon('parchment', 'systems'), Icons.map_outlined);
    expect(themedIcon('parchment', 'resources'), Icons.anchor);
  });

  test('tema pirata possui acabamento próprio', () {
    final theme = buildTheme('parchment');
    expect(theme.scaffoldBackgroundColor, Colors.transparent);
    expect(theme.navigationBarTheme.indicatorShape, isA<BeveledRectangleBorder>());
    expect(theme.cardTheme.shape, isA<BeveledRectangleBorder>());
    expect(theme.colorScheme.primary, const Color(0xFFD1A85A));
  });
}
