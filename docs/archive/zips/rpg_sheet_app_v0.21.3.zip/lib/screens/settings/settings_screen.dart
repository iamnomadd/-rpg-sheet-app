import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/app_state.dart';
import 'import_export_screen.dart';
import 'sync_screen.dart';
import 'theme_screen.dart';
import 'beta_check_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Configurações')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Aparência', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.palette_outlined),
                    title: const Text('Aparência e temas'),
                    subtitle: const Text('Escolha entre 10 estilos visuais para o RPG Sheet.'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ThemeScreen())),
                  ),
                  const Divider(height: 1),
                  SwitchListTile(
                    secondary: const Icon(Icons.text_fields),
                    title: const Text('Texto maior'),
                    subtitle: const Text('Aumenta os textos do aplicativo para facilitar a leitura.'),
                    value: state.largeText,
                    onChanged: state.setLargeText,
                  ),
                  const Divider(height: 1),
                  SwitchListTile(
                    secondary: const Icon(Icons.density_small),
                    title: const Text('Modo compacto'),
                    subtitle: const Text('Reduz o espaço de controles para mostrar mais conteúdo na tela.'),
                    value: state.compactMode,
                    onChanged: state.setCompactMode,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text('Dados e segurança', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.import_export),
                    title: const Text('Importar e exportar'),
                    subtitle: const Text('Compartilhe sistemas, fichas e campanhas ou faça um backup local.'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ImportExportScreen())),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.cloud_sync_outlined),
                    title: const Text('Conta e sincronização'),
                    subtitle: const Text('Status da nuvem, dados locais e backup para sincronização.'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SyncScreen())),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text('Manutenção', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.storage_outlined),
                    title: const Text('Resumo dos dados locais'),
                    subtitle: Text('${state.characters.length} fichas • ${state.systems.length} sistemas • ${state.campaigns.length} campanhas • ${state.diceHistory.length} rolagens'),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: Icon(
                      state.dataIntegrityIssues.isEmpty
                          ? Icons.verified_outlined
                          : Icons.warning_amber_rounded,
                    ),
                    title: const Text('Verificação beta'),
                    subtitle: Text(
                      state.dataIntegrityIssues.isEmpty
                          ? 'Nenhum problema estrutural detectado.'
                          : '${state.dataIntegrityIssues.length} ponto(s) para revisar.',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const BetaCheckScreen()),
                    ),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.history_toggle_off),
                    title: const Text('Limpar histórico de dados'),
                    subtitle: const Text('Remove somente o histórico de rolagens.'),
                    onTap: state.diceHistory.isEmpty ? null : () => _clearDice(context),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Center(child: Text('RPG Sheet • V0.21.3 Beta')),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => _clear(context),
              icon: const Icon(Icons.delete_forever),
              label: const Text('Apagar todos os dados locais'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _clearDice(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Limpar histórico?'),
        content: const Text('As fichas, sistemas e campanhas não serão alterados.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Limpar')),
        ],
      ),
    );
    if (result == true && context.mounted) {
      context.read<AppState>().clearDiceHistory();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Histórico de rolagens limpo.')));
    }
  }

  Future<void> _clear(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Apagar todos os dados?'),
        content: const Text('Esta ação remove fichas, sistemas personalizados e campanhas deste dispositivo. Faça um backup antes se quiser preservar os dados.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Apagar')),
        ],
      ),
    );
    if (result == true && context.mounted) {
      await context.read<AppState>().clearAll();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Dados locais apagados.')));
    }
  }
}
