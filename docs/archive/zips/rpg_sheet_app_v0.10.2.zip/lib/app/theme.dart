import 'package:flutter/material.dart';

class AppThemePreset {
  final String id;
  final String name;
  final String description;
  final IconData icon;
  final Color seed;
  final Color background;
  final Color card;
  final Brightness brightness;
  final double radius;

  const AppThemePreset({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    required this.seed,
    required this.background,
    required this.card,
    this.brightness = Brightness.dark,
    this.radius = 20,
  });
}

const appThemes = <AppThemePreset>[
  AppThemePreset(id: 'classic', name: 'Clássico Escuro', description: 'Roxo e preto, o visual original do RPG Sheet.', icon: Icons.dark_mode, seed: Color(0xFF7C4DFF), background: Color(0xFF101014), card: Color(0xFF1A1A21)),
  AppThemePreset(id: 'parchment', name: 'Pergaminho', description: 'Tons quentes inspirados em mapas e grimórios.', icon: Icons.history_edu, seed: Color(0xFFFFA726), background: Color(0xFF1C1208), card: Color(0xFF3B2410), radius: 12),
  AppThemePreset(id: 'medieval', name: 'Medieval', description: 'Ferro, bronze e tavernas de fantasia.', icon: Icons.shield, seed: Color(0xFFFFB300), background: Color(0xFF12110D), card: Color(0xFF302713), radius: 10),
  AppThemePreset(id: 'arcane', name: 'Arcano', description: 'Magia violeta e energia mística.', icon: Icons.auto_awesome, seed: Color(0xFF9C6CFF), background: Color(0xFF120E1D), card: Color(0xFF211832)),
  AppThemePreset(id: 'vampire', name: 'Vampírico', description: 'Vermelho profundo e atmosfera sombria.', icon: Icons.nightlight_round, seed: Color(0xFFFF1744), background: Color(0xFF100508), card: Color(0xFF351018), radius: 16),
  AppThemePreset(id: 'forest', name: 'Floresta', description: 'Verde natural para aventuras selvagens.', icon: Icons.forest, seed: Color(0xFF00C853), background: Color(0xFF06130B), card: Color(0xFF10351C)),
  AppThemePreset(id: 'ocean', name: 'Oceano', description: 'Azul profundo e exploração marítima.', icon: Icons.water, seed: Color(0xFF00B8D4), background: Color(0xFF04131D), card: Color(0xFF07364A)),
  AppThemePreset(id: 'cyberpunk', name: 'Cyberpunk', description: 'Neon e tecnologia para cenários futuristas.', icon: Icons.memory, seed: Color(0xFF00BCD4), background: Color(0xFF090B12), card: Color(0xFF151827), radius: 8),
  AppThemePreset(id: 'infernal', name: 'Infernal', description: 'Laranja e fogo para mundos hostis.', icon: Icons.local_fire_department, seed: Color(0xFFFF3D00), background: Color(0xFF160603), card: Color(0xFF421208), radius: 14),
  AppThemePreset(id: 'ice', name: 'Gelo', description: 'Azul-claro e tons frios.', icon: Icons.ac_unit, seed: Color(0xFF00E5FF), background: Color(0xFF041219), card: Color(0xFF0A3442)),
];

AppThemePreset themePreset(String id) => appThemes.firstWhere(
  (theme) => theme.id == id,
  orElse: () => appThemes.first,
);

IconData themedIcon(String themeId, String role) {
  const sets = <String, Map<String, IconData>>{
    'classic': {'general': Icons.dashboard, 'attributes': Icons.bar_chart, 'skills': Icons.psychology, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.backpack, 'inventory': Icons.backpack, 'abilities': Icons.auto_awesome},
    'cyberpunk': {'general': Icons.grid_view_rounded, 'attributes': Icons.monitor_heart_outlined, 'skills': Icons.hub_outlined, 'resources': Icons.battery_charging_full, 'sections': Icons.view_in_ar_outlined, 'extras': Icons.inventory_2_outlined, 'inventory': Icons.inventory_2_outlined, 'abilities': Icons.bolt},
    'arcane': {'general': Icons.blur_circular, 'attributes': Icons.auto_graph, 'skills': Icons.psychology_alt, 'resources': Icons.favorite_border, 'sections': Icons.auto_stories, 'extras': Icons.all_inclusive, 'inventory': Icons.shopping_bag_outlined, 'abilities': Icons.auto_awesome},
    'parchment': {'general': Icons.map_outlined, 'attributes': Icons.format_list_numbered, 'skills': Icons.school_outlined, 'resources': Icons.favorite, 'sections': Icons.history_edu, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.workspace_premium_outlined},
    'medieval': {'general': Icons.shield_outlined, 'attributes': Icons.fitness_center, 'skills': Icons.military_tech, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.backpack, 'inventory': Icons.backpack, 'abilities': Icons.flash_on},
    'vampire': {'general': Icons.nightlight_round, 'attributes': Icons.bloodtype_outlined, 'skills': Icons.visibility_outlined, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.dark_mode},
    'forest': {'general': Icons.forest, 'attributes': Icons.park_outlined, 'skills': Icons.pets_outlined, 'resources': Icons.eco, 'sections': Icons.menu_book, 'extras': Icons.backpack, 'inventory': Icons.backpack, 'abilities': Icons.spa},
    'ocean': {'general': Icons.water, 'attributes': Icons.waves, 'skills': Icons.explore_outlined, 'resources': Icons.water_drop, 'sections': Icons.map_outlined, 'extras': Icons.sailing, 'inventory': Icons.inventory_2, 'abilities': Icons.bubble_chart},
    'infernal': {'general': Icons.local_fire_department, 'attributes': Icons.whatshot, 'skills': Icons.psychology_alt, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.bolt},
    'ice': {'general': Icons.ac_unit, 'attributes': Icons.stacked_line_chart, 'skills': Icons.diamond_outlined, 'resources': Icons.severe_cold, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.auto_awesome},
  };
  return sets[themeId]?[role] ?? sets['classic']![role] ?? Icons.circle;
}

ThemeData buildTheme([String themeId = 'classic']) {
  final preset = themePreset(themeId);
  final scheme = ColorScheme.fromSeed(seedColor: preset.seed, brightness: preset.brightness);
  final radius = preset.radius;
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: preset.background,
    appBarTheme: const AppBarTheme(centerTitle: false, backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent),
    navigationBarTheme: NavigationBarThemeData(
      height: 72,
      labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(fontWeight: states.contains(WidgetState.selected) ? FontWeight.w700 : FontWeight.w500)),
    ),
    cardTheme: CardThemeData(color: preset.card, elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius))),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: preset.card, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16), border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius.clamp(10, 16)), borderSide: BorderSide.none)),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius.clamp(8, 14))))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius.clamp(8, 14))))),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
    dividerTheme: const DividerThemeData(space: 24),
  );
}
