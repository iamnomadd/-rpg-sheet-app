import 'package:flutter/material.dart';

class AppThemePreset {
  final String id;
  final String name;
  final String description;
  final IconData icon;
  final Color seed;
  final Color background;
  final Color card;
  final Brightness brightness;
  final double radius;

  const AppThemePreset({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    required this.seed,
    required this.background,
    required this.card,
    this.brightness = Brightness.dark,
    this.radius = 20,
  });
}

const appThemes = <AppThemePreset>[
  AppThemePreset(id: 'classic', name: 'Clássico Escuro', description: 'Roxo e preto, o visual original do RPG Sheet.', icon: Icons.dark_mode, seed: Color(0xFF7C4DFF), background: Color(0xFF101014), card: Color(0xFF1A1A21)),
  AppThemePreset(id: 'parchment', name: 'Sombrio', description: 'Preto profundo e cinza forte com atmosfera obscura.', icon: Icons.dark_mode, seed: Color(0xFFBDBDBD), background: Color(0xFF000000), card: Color(0xFF181818), radius: 12),
  AppThemePreset(id: 'medieval', name: 'Medieval', description: 'Ferro, bronze e tavernas de fantasia.', icon: Icons.shield, seed: Color(0xFFFFB300), background: Color(0xFF12110D), card: Color(0xFF302713), radius: 10),
  AppThemePreset(id: 'arcane', name: 'Arcano', description: 'Magia violeta e energia mística.', icon: Icons.auto_awesome, seed: Color(0xFF9C6CFF), background: Color(0xFF120E1D), card: Color(0xFF211832)),
  AppThemePreset(id: 'vampire', name: 'Vampírico', description: 'Vermelho profundo e atmosfera sombria.', icon: Icons.nightlight_round, seed: Color(0xFFFF1744), background: Color(0xFF100508), card: Color(0xFF351018), radius: 16),
  AppThemePreset(id: 'forest', name: 'Elemento Terra', description: 'Marrom, pedra e tons terrosos para uma identidade elemental forte.', icon: Icons.landscape, seed: Color(0xFFE08A32), background: Color(0xFF160B03), card: Color(0xFF4A2810)),
  AppThemePreset(id: 'ocean', name: 'Elemento Ar', description: 'Branco e cinza com contraste forte e visual elemental.', icon: Icons.air, seed: Color(0xFFFFFFFF), background: Color(0xFF101215), card: Color(0xFF34383D)),
  AppThemePreset(id: 'cyberpunk', name: 'Cyberpunk', description: 'Azul elétrico e neon para cenários futuristas.', icon: Icons.memory, seed: Color(0xFF0401FE), background: Color(0xFF05051A), card: Color(0xFF11134A), radius: 8),
  AppThemePreset(id: 'infernal', name: 'Infernal', description: 'Vermelho intenso e fogo para mundos hostis.', icon: Icons.local_fire_department, seed: Color(0xFFFD0F04), background: Color(0xFF180201), card: Color(0xFF4A0804), radius: 14),
  AppThemePreset(id: 'ice', name: 'Gelo', description: 'Azul-claro e tons frios.', icon: Icons.ac_unit, seed: Color(0xFF00E5FF), background: Color(0xFF041219), card: Color(0xFF0A3442)),
];

AppThemePreset themePreset(String id) => appThemes.firstWhere(
  (theme) => theme.id == id,
  orElse: () => appThemes.first,
);

IconData themedIcon(String themeId, String role) {
  const sets = <String, Map<String, IconData>>{
    'classic': {'general': Icons.dashboard, 'attributes': Icons.bar_chart, 'attributesResources': Icons.dashboard_customize, 'combat': Icons.sports_martial_arts, 'skills': Icons.psychology, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.backpack, 'inventory': Icons.backpack, 'abilities': Icons.auto_awesome, 'skillTree': Icons.account_tree_outlined},
    'cyberpunk': {'general': Icons.grid_view_rounded, 'attributes': Icons.monitor_heart_outlined, 'attributesResources': Icons.monitor_heart_outlined, 'combat': Icons.flash_on, 'skills': Icons.hub_outlined, 'resources': Icons.battery_charging_full, 'sections': Icons.terminal, 'extras': Icons.inventory_2_outlined, 'inventory': Icons.inventory_2_outlined, 'abilities': Icons.bolt, 'skillTree': Icons.hub_outlined},
    'arcane': {'general': Icons.blur_circular, 'attributes': Icons.auto_graph, 'attributesResources': Icons.auto_graph, 'combat': Icons.local_fire_department_outlined, 'skills': Icons.psychology_alt, 'resources': Icons.favorite_border, 'sections': Icons.auto_stories, 'extras': Icons.all_inclusive, 'inventory': Icons.shopping_bag_outlined, 'abilities': Icons.auto_awesome, 'skillTree': Icons.device_hub},
    'parchment': {'general': Icons.dark_mode, 'attributes': Icons.stacked_bar_chart, 'attributesResources': Icons.tune, 'combat': Icons.sports_mma_outlined, 'skills': Icons.visibility_outlined, 'resources': Icons.blur_on, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.nightlight_round, 'skillTree': Icons.account_tree_outlined},
    'medieval': {'general': Icons.shield_outlined, 'attributes': Icons.fitness_center, 'attributesResources': Icons.shield_outlined, 'combat': Icons.sports_martial_arts, 'skills': Icons.military_tech, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.backpack, 'inventory': Icons.backpack, 'abilities': Icons.flash_on, 'skillTree': Icons.account_tree_outlined},
    'vampire': {'general': Icons.nightlight_round, 'attributes': Icons.bloodtype_outlined, 'attributesResources': Icons.bloodtype_outlined, 'combat': Icons.flash_on, 'skills': Icons.visibility_outlined, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.dark_mode, 'skillTree': Icons.account_tree},
    'forest': {'general': Icons.landscape, 'attributes': Icons.fitness_center, 'attributesResources': Icons.landscape, 'combat': Icons.sports_martial_arts, 'skills': Icons.psychology, 'resources': Icons.eco, 'sections': Icons.menu_book, 'extras': Icons.backpack, 'inventory': Icons.backpack, 'abilities': Icons.bolt, 'skillTree': Icons.terrain},
    'ocean': {'general': Icons.air, 'attributes': Icons.speed, 'attributesResources': Icons.air, 'combat': Icons.bolt_outlined, 'skills': Icons.explore_outlined, 'resources': Icons.cloud_outlined, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.bolt, 'skillTree': Icons.alt_route},
    'infernal': {'general': Icons.local_fire_department, 'attributes': Icons.whatshot, 'attributesResources': Icons.whatshot, 'combat': Icons.local_fire_department, 'skills': Icons.psychology_alt, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.bolt, 'skillTree': Icons.call_split},
    'ice': {'general': Icons.ac_unit, 'attributes': Icons.stacked_line_chart, 'attributesResources': Icons.ac_unit, 'combat': Icons.bolt_outlined, 'skills': Icons.diamond_outlined, 'resources': Icons.severe_cold, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.auto_awesome, 'skillTree': Icons.hub_outlined},
  };
  return sets[themeId]?[role] ?? sets['classic']![role] ?? Icons.circle;
}


IconData themedSelectedIcon(String themeId, String role) => themedIcon(themeId, role);

IconData themedMainIcon(String themeId, String role) {
  const sets = <String, Map<String, IconData>>{
    'classic': {
      'characters': Icons.people_alt_outlined, 'systems': Icons.auto_awesome, 'tree': Icons.account_tree_outlined,
      'dice': Icons.casino_outlined, 'campaigns': Icons.groups_outlined, 'settings': Icons.settings_outlined,
    },
    'cyberpunk': {
      'characters': Icons.badge_outlined, 'systems': Icons.memory, 'tree': Icons.hub_outlined,
      'dice': Icons.casino_outlined, 'campaigns': Icons.wifi_tethering, 'settings': Icons.tune,
    },
    'arcane': {
      'characters': Icons.person_outline, 'systems': Icons.auto_awesome, 'tree': Icons.device_hub,
      'dice': Icons.casino, 'campaigns': Icons.groups_outlined, 'settings': Icons.tune,
    },
    'parchment': {
      'characters': Icons.visibility_outlined, 'systems': Icons.dark_mode, 'tree': Icons.account_tree_outlined,
      'dice': Icons.casino_outlined, 'campaigns': Icons.groups, 'settings': Icons.settings_outlined,
    },
    'medieval': {
      'characters': Icons.shield_outlined, 'systems': Icons.menu_book, 'tree': Icons.account_tree_outlined,
      'dice': Icons.casino, 'campaigns': Icons.groups, 'settings': Icons.settings,
    },
    'vampire': {
      'characters': Icons.nightlight_round, 'systems': Icons.bloodtype_outlined, 'tree': Icons.account_tree,
      'dice': Icons.casino_outlined, 'campaigns': Icons.groups_outlined, 'settings': Icons.settings_outlined,
    },
    'forest': {
      'characters': Icons.landscape, 'systems': Icons.eco, 'tree': Icons.terrain,
      'dice': Icons.casino_outlined, 'campaigns': Icons.groups_outlined, 'settings': Icons.tune,
    },
    'ocean': {
      'characters': Icons.air, 'systems': Icons.cloud_outlined, 'tree': Icons.alt_route,
      'dice': Icons.casino_outlined, 'campaigns': Icons.groups_outlined, 'settings': Icons.tune,
    },
    'infernal': {
      'characters': Icons.local_fire_department, 'systems': Icons.whatshot, 'tree': Icons.call_split,
      'dice': Icons.casino, 'campaigns': Icons.groups, 'settings': Icons.settings,
    },
    'ice': {
      'characters': Icons.ac_unit, 'systems': Icons.severe_cold, 'tree': Icons.hub_outlined,
      'dice': Icons.casino_outlined, 'campaigns': Icons.groups_outlined, 'settings': Icons.settings_outlined,
    },
  };
  return sets[themeId]?[role] ?? sets['classic']![role] ?? Icons.circle;
}

List<Color> themedResourceBarColors(String themeId, {bool secondary = false}) {
  switch (themeId) {
    case 'cyberpunk':
      return secondary ? [const Color(0xFF6A00F4), const Color(0xFF00E5FF)] : [const Color(0xFF00E5FF), const Color(0xFF00FFC6)];
    case 'arcane':
      return secondary ? [const Color(0xFF6A1B9A), const Color(0xFFB388FF)] : [const Color(0xFF8E24AA), const Color(0xFFD1C4E9)];
    case 'parchment':
      return secondary ? [const Color(0xFF757575), const Color(0xFFBDBDBD)] : [const Color(0xFF9E9E9E), const Color(0xFFE0E0E0)];
    case 'medieval':
      return secondary ? [const Color(0xFF8D6E63), const Color(0xFFFFCC80)] : [const Color(0xFFB87333), const Color(0xFFFFD54F)];
    case 'vampire':
      return secondary ? [const Color(0xFF6A1B1A), const Color(0xFFFF5252)] : [const Color(0xFFB71C1C), const Color(0xFFFF8A80)];
    case 'forest':
      return secondary ? [const Color(0xFF6D4C41), const Color(0xFFBCAAA4)] : [const Color(0xFF8D6E63), const Color(0xFFD7B899)];
    case 'ocean':
      return secondary ? [const Color(0xFF90A4AE), const Color(0xFFECEFF1)] : [const Color(0xFFB0BEC5), const Color(0xFFFFFFFF)];
    case 'infernal':
      return secondary ? [const Color(0xFFFF6D00), const Color(0xFFFFAB40)] : [const Color(0xFFFF3D00), const Color(0xFFFF8A65)];
    case 'ice':
      return secondary ? [const Color(0xFF00B8D4), const Color(0xFFB2EBF2)] : [const Color(0xFF00E5FF), const Color(0xFFE1F5FE)];
    default:
      return secondary ? [const Color(0xFF7E57C2), const Color(0xFFD1C4E9)] : [const Color(0xFFB39DDB), const Color(0xFFEDE7F6)];
  }
}

Color themedResourceTrackColor(String themeId) {
  switch (themeId) {
    case 'cyberpunk':
      return const Color(0xFF101A28);
    case 'arcane':
      return const Color(0xFF1D1630);
    case 'parchment':
      return const Color(0xFF1C1D22);
    case 'medieval':
      return const Color(0xFF241B10);
    case 'vampire':
      return const Color(0xFF220B11);
    case 'forest':
      return const Color(0xFF24160E);
    case 'ocean':
      return const Color(0xFF1A1E24);
    case 'infernal':
      return const Color(0xFF2A0B05);
    case 'ice':
      return const Color(0xFF07202A);
    default:
      return const Color(0xFF181824);
  }
}

ShapeBorder themedNavigationIndicatorShape(String themeId, double radius) {
  switch (themeId) {
    case 'cyberpunk':
      return BeveledRectangleBorder(borderRadius: BorderRadius.circular(8));
    case 'arcane':
      return const StadiumBorder();
    case 'medieval':
      return RoundedRectangleBorder(borderRadius: BorderRadius.circular(6));
    case 'parchment':
      return RoundedRectangleBorder(borderRadius: BorderRadius.circular(4));
    case 'infernal':
      return BeveledRectangleBorder(borderRadius: BorderRadius.circular(12));
    default:
      return RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius.clamp(10, 22)));
  }
}

ThemeData buildTheme([String themeId = 'classic']) {
  final preset = themePreset(themeId);
  final scheme = ColorScheme.fromSeed(seedColor: preset.seed, brightness: preset.brightness);
  final radius = preset.radius;
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: preset.background,
    appBarTheme: const AppBarTheme(centerTitle: false, backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent),
    navigationBarTheme: NavigationBarThemeData(
      height: 76,
      backgroundColor: preset.card,
      indicatorColor: scheme.primaryContainer,
      indicatorShape: themedNavigationIndicatorShape(themeId, radius),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return IconThemeData(
          size: 24,
          color: selected ? scheme.onPrimaryContainer : scheme.onSurfaceVariant,
        );
      }),
      labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(
        fontSize: states.contains(WidgetState.selected) ? 11 : 10.5,
        fontWeight: states.contains(WidgetState.selected) ? FontWeight.w700 : FontWeight.w600,
      )),
    ),
    cardTheme: CardThemeData(color: preset.card, elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius))),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: preset.card, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16), border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius.clamp(10, 16)), borderSide: BorderSide.none)),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius.clamp(8, 14))))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius.clamp(8, 14))))),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
    dividerTheme: const DividerThemeData(space: 24),
  );
}
