import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/character.dart';
import '../../services/app_state.dart';

class SkillTreeScreen extends StatefulWidget {
  final String characterId;
  final bool embedded;
  const SkillTreeScreen({super.key, required this.characterId, this.embedded = false});
  @override State<SkillTreeScreen> createState() => _SkillTreeScreenState();
}

class _SkillTreeScreenState extends State<SkillTreeScreen> {
  Character? _character(AppState s) { for (final c in s.characters) { if (c.id == widget.characterId) return c; } return null; }

  Future<void> _add(Character c) async {
    final name = TextEditingController(); final desc = TextEditingController(); String parent = '';
    final result = await showDialog<Map<String,String>>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx,setD) => AlertDialog(
      title: const Text('Nova habilidade da árvore'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller:name, autofocus:true, decoration:const InputDecoration(labelText:'Nome')),
        const SizedBox(height:12), TextField(controller:desc, minLines:2,maxLines:4, decoration:const InputDecoration(labelText:'Descrição')),
        const SizedBox(height:12), DropdownButtonFormField<String>(value:parent, decoration:const InputDecoration(labelText:'Pré-requisito'), items:[const DropdownMenuItem(value:'',child:Text('Nenhum — habilidade inicial')), ...c.skillTree.map((n)=>DropdownMenuItem(value:n['id'].toString(),child:Text(n['name']?.toString()??'Habilidade')))], onChanged:(v)=>setD(()=>parent=v??'')),
      ])),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(ctx,{'name':name.text.trim(),'description':desc.text.trim(),'parentId':parent}),child:const Text('Adicionar'))]
    )));
    name.dispose(); desc.dispose(); if(result==null || result['name']!.isEmpty) return;
    c.skillTree.add({'id':DateTime.now().microsecondsSinceEpoch.toString(),'name':result['name'],'description':result['description'],'parentId':result['parentId'],'unlocked':false});
    await context.read<AppState>().updateCharacter(c); if(mounted)setState((){});
  }

  Future<void> _toggle(Character c, Map<String,dynamic> node) async { node['unlocked']=!(node['unlocked']==true); await context.read<AppState>().updateCharacter(c); if(mounted)setState((){}); }
  Future<void> _delete(Character c, Map<String,dynamic> node) async { final id=node['id'].toString(); c.skillTree.removeWhere((n)=>n['id'].toString()==id); for(final n in c.skillTree){if(n['parentId']?.toString()==id)n['parentId']='';} await context.read<AppState>().updateCharacter(c); if(mounted)setState((){}); }

  Widget _body(Character c) {
    final roots=c.skillTree.where((n)=>(n['parentId']??'').toString().isEmpty).toList();
    Widget nodeCard(Map<String,dynamic> n, int depth){ final children=c.skillTree.where((x)=>x['parentId']?.toString()==n['id']?.toString()).toList(); final unlocked=n['unlocked']==true; return Padding(padding:EdgeInsets.only(left:depth*20.0,bottom:8),child:Column(children:[Card(child:ListTile(leading:Icon(unlocked?Icons.lock_open_rounded:Icons.lock_outline_rounded),title:Text(n['name']?.toString()??''),subtitle:(n['description']??'').toString().isEmpty?null:Text(n['description'].toString()),trailing:Row(mainAxisSize:MainAxisSize.min,children:[Checkbox(value:unlocked,onChanged:(_)=>_toggle(c,n)),IconButton(onPressed:()=>_delete(c,n),icon:const Icon(Icons.delete_outline))]))),...children.map((x)=>nodeCard(x,depth+1))])); }
    return ListView(padding:const EdgeInsets.all(16),children:[
      Row(children:[const Icon(Icons.account_tree_outlined),const SizedBox(width:8),Text('Árvore de habilidades',style:Theme.of(context).textTheme.titleLarge),const Spacer(),IconButton(onPressed:()=>_add(c),icon:const Icon(Icons.add_circle_outline))]),
      const SizedBox(height:6),Text('Crie habilidades, conecte pré-requisitos e marque o que ${c.name} já desbloqueou.',style:Theme.of(context).textTheme.bodySmall),const SizedBox(height:16),
      if(c.skillTree.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(24),child:Text('Nenhuma habilidade na árvore. Toque em + para criar a primeira.'))) else ...roots.map((n)=>nodeCard(n,0)),
    ]);
  }
  @override Widget build(BuildContext context){ final c=_character(context.watch<AppState>()); if(c==null)return const Center(child:Text('Ficha não encontrada.')); if(widget.embedded)return _body(c); return Scaffold(appBar:AppBar(title:Text('Árvore • ${c.name}')),body:_body(c)); }
}
