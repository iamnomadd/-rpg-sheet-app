import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/app_state.dart';

import '../screens/home/home_screen.dart';
import '../screens/systems/systems_screen.dart';
import '../screens/campaigns/campaigns_screen.dart';
import '../screens/dice/dice_screen.dart';
import '../screens/settings/settings_screen.dart';
import '../screens/home/skill_trees_screen.dart';
import 'theme.dart';

class RpgSheetApp extends StatefulWidget {
  const RpgSheetApp({super.key});

  @override
  State<RpgSheetApp> createState() => _RpgSheetAppState();
}

class _RpgSheetAppState extends State<RpgSheetApp> {
  int index = 0;

  final pages = const [
    HomeScreen(),
    SystemsScreen(),
    SkillTreesScreen(),
    DiceScreen(),
    CampaignsScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final baseTheme = buildTheme(appState.themeId);
    return MaterialApp(
      title: 'RPG Sheet',
      debugShowCheckedModeBanner: false,
      theme: baseTheme.copyWith(
        visualDensity: appState.compactMode ? VisualDensity.compact : VisualDensity.standard,
      ),
      builder: (context, child) {
        final media = MediaQuery.of(context);
        return MediaQuery(
          data: media.copyWith(
            textScaler: TextScaler.linear(appState.largeText ? 1.15 : 1.0),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: Scaffold(
        body: IndexedStack(index: index, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) => setState(() => index = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.people), label: 'Fichas'),
            NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Sistemas'),
            NavigationDestination(icon: Icon(Icons.account_tree_outlined), label: 'Árvore'),
            NavigationDestination(icon: Icon(Icons.casino), label: 'Dados'),
            NavigationDestination(icon: Icon(Icons.groups), label: 'Campanhas'),
            NavigationDestination(icon: Icon(Icons.settings), label: 'Config.'),
          ],
        ),
      ),
    );
  }
}
