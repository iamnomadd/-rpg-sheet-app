import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/character.dart';
import '../../models/rpg_system.dart';
import '../../services/app_state.dart';
import 'skill_tree_screen.dart';
import '../../services/rpg_file_service.dart';
import '../../app/theme.dart';
import '../../app/condition_presets.dart';
import '../../services/skill_tree_templates.dart';

class CharacterScreen extends StatefulWidget {
  final String characterId;

  const CharacterScreen({super.key, required this.characterId});

  @override
  State<CharacterScreen> createState() => _CharacterScreenState();
}

class _CharacterScreenState extends State<CharacterScreen> {
  int tab = 0;

  Character? _findCharacter(AppState state) {
    for (final c in state.characters) {
      if (c.id == widget.characterId) return c;
    }
    return null;
  }

  RpgSystem? _findSystem(AppState state, Character character) {
    for (final system in state.systems) {
      if (system.id == character.systemId) return system;
    }
    return state.systems.isNotEmpty ? state.systems.first : null;
  }

  Widget _compactLines(List<String> lines, String emptyText) {
    if (lines.isEmpty) {
      return Text(emptyText);
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: lines
          .map((line) => Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text(line, maxLines: 2, overflow: TextOverflow.ellipsis),
              ))
          .toList(),
    );
  }

  Future<void> _editBasic() async {
    final state = context.read<AppState>();
    final c = _findCharacter(state);
    if (c == null) return;

    final name = TextEditingController(text: c.name);
    final player = TextEditingController(text: c.player);
    final originalClassName = c.className;
    final className = TextEditingController(text: c.className);
    final race = TextEditingController(text: c.race);
    final background = TextEditingController(text: c.background);
    final level = TextEditingController(text: c.level.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Dados do personagem'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(controller: name, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Nome')),
              const SizedBox(height: 10),
              TextField(controller: player, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Jogador')),
              const SizedBox(height: 10),
              TextField(controller: className, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Classe')),
              const SizedBox(height: 10),
              TextField(controller: race, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Raça')),
              const SizedBox(height: 10),
              TextField(controller: background, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Antecedente')),
              const SizedBox(height: 10),
              TextField(controller: level, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Nível')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      c.name = name.text.trim().isEmpty ? c.name : name.text.trim();
      c.player = player.text.trim();
      c.className = className.text.trim();
      c.race = race.text.trim();
      c.background = background.text.trim();
      c.level = (int.tryParse(level.text) ?? c.level).clamp(1, 999);
      final classChanged = originalClassName.trim().toLowerCase() != c.className.trim().toLowerCase();
      if (classChanged && c.skillTree.isEmpty && SkillTreeTemplates.hasTemplate(c.className)) {
        c.skillTree = SkillTreeTemplates.forClass(c.className);
      }
      await state.updateCharacter(c);
      if (mounted) setState(() {});
    }

    name.dispose(); player.dispose(); className.dispose(); race.dispose(); background.dispose(); level.dispose();
  }

  Future<void> _editResource(Character c, String name) async {
    final state = context.read<AppState>();
    final current = c.resourceValues[name] ?? 0;
    final maximum = c.resourceMaxValues[name] ?? 0;
    final value = TextEditingController(text: current.toString());
    final max = TextEditingController(text: maximum.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Configurar $name'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: value, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor atual')),
          const SizedBox(height: 10),
          TextField(controller: max, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor máximo')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      final newMax = (int.tryParse(max.text) ?? maximum).clamp(0, 999999);
      c.resourceMaxValues[name] = newMax;
      c.resourceValues[name] = (int.tryParse(value.text) ?? current).clamp(0, newMax);
      if (name.toLowerCase() == 'vida') { c.maxHp = newMax; c.hp = c.resourceValues[name]!; }
      if (name.toLowerCase() == 'energia') { c.maxEnergy = newMax; c.energy = c.resourceValues[name]!; }
      await state.updateCharacter(c);
      if (mounted) setState(() {});
    }
    value.dispose(); max.dispose();
  }

  Future<void> _changeResource(Character c, String name, int delta) async {
    final state = context.read<AppState>();
    final max = c.resourceMaxValues[name] ?? 0;
    final current = c.resourceValues[name] ?? 0;
    c.resourceValues[name] = (current + delta).clamp(0, max);
    if (name.toLowerCase() == 'vida') c.hp = c.resourceValues[name]!;
    if (name.toLowerCase() == 'energia') c.energy = c.resourceValues[name]!;
    await state.updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editAttribute(Character c, String name) async {
    final controller = TextEditingController(text: (c.attributes[name] ?? 0).toString());
    final result = await showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Editar $name'),
        content: TextField(controller: controller, autofocus: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, int.tryParse(controller.text)), child: const Text('Salvar')),
        ],
      ),
    );
    controller.dispose();
    if (result == null) return;
    c.attributes[name] = result;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editSection(Character c, String name) async {
    final controller = TextEditingController(text: c.sectionNotes[name] ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(name),
        content: TextField(controller: controller, autofocus: true, textCapitalization: TextCapitalization.sentences, minLines: 5, maxLines: 12, decoration: const InputDecoration(hintText: 'Escreva aqui...')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Salvar')),
        ],
      ),
    );
    controller.dispose();
    if (result == null) return;
    c.sectionNotes[name] = result;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _toggleSkill(Character c, String skill) async {
    if (c.skills.contains(skill)) { c.skills.remove(skill); } else { c.skills.add(skill); }
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _reorderGeneral(Character c, int oldIndex, int newIndex) async {
    const validIds = ['health', 'energy', 'attributes', 'skillTree', 'abilities', 'inventory'];
    final order = <String>[];
    for (final id in c.generalOrder) {
      if (validIds.contains(id) && !order.contains(id)) order.add(id);
    }
    for (final id in validIds) {
      if (!order.contains(id)) order.add(id);
    }
    if (newIndex > oldIndex) newIndex -= 1;
    final item = order.removeAt(oldIndex);
    order.insert(newIndex, item);
    c.generalOrder = order;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }


  static const _defaultTabOrder = ['general', 'attributesResources', 'actions', 'skillTree', 'abilities', 'skills', 'inventory', 'sections'];

  List<String> _normalizedTabOrder(Character c) {
    final order = <String>[];
    for (final id in c.sheetTabOrder) {
      if (_defaultTabOrder.contains(id) && !order.contains(id)) order.add(id);
    }
    for (final id in _defaultTabOrder) {
      if (!order.contains(id)) order.add(id);
    }
    return order;
  }

  String _tabLabel(String id) => switch (id) {
    'general' => 'Resumo',
    'attributesResources' => 'Status',
    'abilities' => 'Habilidades',
    'actions' => 'Ações',
    'skillTree' => 'Árvore',
    'skills' => 'Perícias',
    'inventory' => 'Inventário',
    'sections' => 'Seções',
    _ => id,
  };

  Widget _tabPage(String id, Character c, RpgSystem system) => switch (id) {
    'general' => _GeneralTab(character: c, system: system, onReorder: _reorderGeneral, onChangeResource: _changeResource, onEditResource: _editResource),
    'attributesResources' => _AttributesResourcesTab(character: c, system: system, onEditAttribute: _editAttribute, onChangeResource: _changeResource, onEditResource: _editResource),
    'actions' => _ActionsTab(character: c, system: system),
    'abilities' => _CharacterItemsTab(character: c, items: c.abilities, descriptions: c.abilityDescriptions, details: c.abilityDetails, title: 'Habilidades', singular: 'habilidade', hint: 'Nome da habilidade', iconRole: 'abilities', isAbility: true),
    'skillTree' => SkillTreeScreen(characterId: c.id, embedded: true),
    'skills' => _SkillsTab(character: c, system: system, onToggle: _toggleSkill),
    'inventory' => _CharacterItemsTab(character: c, items: c.inventory, descriptions: c.inventoryDescriptions, details: c.inventoryDetails, title: 'Inventário', singular: 'item', hint: 'Nome do item', iconRole: 'inventory', isAbility: false),
    'sections' => _SectionsTab(character: c, system: system, onEdit: _editSection),
    _ => const SizedBox.shrink(),
  };

  Future<void> _customizeSheet(Character c) async {
    var draft = _normalizedTabOrder(c);
    final saved = await showModalBottomSheet<List<String>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          child: SizedBox(
            height: MediaQuery.sizeOf(context).height * .72,
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.dashboard_customize_outlined),
                  title: const Text('Personalizar ficha'),
                  subtitle: const Text('Arraste para escolher a ordem das abas. A aba Resumo também pode ser reposicionada.'),
                  trailing: TextButton(
                    onPressed: () => setSheetState(() => draft = List<String>.from(_defaultTabOrder)),
                    child: const Text('Restaurar'),
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: ReorderableListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: draft.length,
                    onReorder: (oldIndex, newIndex) {
                      setSheetState(() {
                        if (newIndex > oldIndex) newIndex--;
                        final item = draft.removeAt(oldIndex);
                        draft.insert(newIndex, item);
                      });
                    },
                    itemBuilder: (context, index) {
                      final id = draft[index];
                      return ListTile(
                        key: ValueKey('sheet-tab-$id'),
                        leading: Icon(themedIcon(context.read<AppState>().themeId, id)),
                        title: Text(_tabLabel(id)),
                        trailing: const Icon(Icons.drag_handle),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () => Navigator.pop(sheetContext, draft),
                      icon: const Icon(Icons.save_outlined),
                      label: const Text('Salvar organização'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (saved == null) return;
    c.sheetTabOrder = saved;
    tab = 0;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final c = _findCharacter(state);
    if (c == null) return const Scaffold(body: Center(child: Text('Ficha não encontrada.')));
    final system = _findSystem(state, c);
    if (system == null) return const Scaffold(body: Center(child: Text('Sistema não encontrado.')));

    // Garante que fichas antigas recebam os campos do sistema atual.
    for (final attribute in system.attributes) { c.attributes.putIfAbsent(attribute, () => 10); }
    for (final resource in system.resources) {
      c.resourceValues.putIfAbsent(resource, () => 0);
      c.resourceMaxValues.putIfAbsent(resource, () => 0);
    }
    for (final section in system.sections) { c.sectionNotes.putIfAbsent(section, () => ''); }

    return Scaffold(
      appBar: AppBar(
        title: Text(c.name),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Compartilhar',
            icon: const Icon(Icons.ios_share),
            onSelected: (value) async {
              try {
                if (value == 'file') {
                  await RpgFileService.exportCharacter(c, system);
                } else if (value == 'summary') {
                  await RpgFileService.shareCharacterSummary(c, system);
                }
              } catch (e) {
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Não foi possível compartilhar: $e')),
                );
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'file',
                child: ListTile(
                  leading: Icon(Icons.file_upload_outlined),
                  title: Text('Compartilhar ficha .rpg'),
                  subtitle: Text('Outra pessoa pode importar e editar uma cópia.'),
                ),
              ),
              PopupMenuItem(
                value: 'summary',
                child: ListTile(
                  leading: Icon(Icons.text_snippet_outlined),
                  title: Text('Compartilhar resumo'),
                  subtitle: Text('Envia uma versão em texto para consulta.'),
                ),
              ),
            ],
          ),
          IconButton(onPressed: _editBasic, icon: const Icon(Icons.edit), tooltip: 'Editar dados'),
        ],
      ),
      body: Column(
        children: [
          _Header(character: c, system: system),
          Builder(
            builder: (context) {
              final order = _normalizedTabOrder(c);
              if (tab >= order.length) tab = 0;
              return Expanded(
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Theme.of(context).colorScheme.outlineVariant.withOpacity(.20)))),
                      child: SizedBox(height: 54, child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                        child: Row(children: order.asMap().entries.map((entry) {
                          final index=entry.key,id=entry.value,selected=tab==index; final colors=Theme.of(context).colorScheme;
                          return Padding(padding:const EdgeInsets.only(right:6),child:InkWell(
                            borderRadius:BorderRadius.circular(12),onTap:()=>setState(()=>tab=index),
                            child:AnimatedContainer(duration:const Duration(milliseconds:160),padding:const EdgeInsets.symmetric(horizontal:12,vertical:8),
                              decoration:BoxDecoration(color:selected?colors.primary.withOpacity(.16):Colors.transparent,borderRadius:BorderRadius.circular(12),border:Border.all(color:selected?colors.primary.withOpacity(.28):Colors.transparent)),
                              child:Row(mainAxisSize:MainAxisSize.min,children:[
                                Icon(themedIcon(state.themeId,id),size:18,color:selected?colors.primary:colors.onSurfaceVariant),const SizedBox(width:7),
                                Text(_tabLabel(id),style:Theme.of(context).textTheme.labelLarge?.copyWith(color:selected?colors.onSurface:colors.onSurfaceVariant,fontWeight:selected?FontWeight.w700:FontWeight.w600)),
                              ]),
                            ),
                          ));
                        }).toList()),
                      )),
                    ),
                    Expanded(
                      child: IndexedStack(
                        index: tab,
                        children: order.map((id) => _tabPage(id, c, system)).toList(),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _GeneralTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, int, int) onReorder;
  final Future<void> Function(Character, String, int) onChangeResource;
  final Future<void> Function(Character, String) onEditResource;

  const _GeneralTab({
    required this.character,
    required this.system,
    required this.onReorder,
    required this.onChangeResource,
    required this.onEditResource,
  });

  Widget _compactLines(List<String> lines, String emptyText) {
    if (lines.isEmpty) return Text(emptyText);
    return Text(lines.take(5).join('\n'));
  }

  String _lifeResourceName() {
    for (final name in system.resources) {
      if (name.toLowerCase() == 'vida') return name;
    }
    return system.resources.isNotEmpty ? system.resources.first : '';
  }

  String _energyResourceName() {
    for (final name in system.resources) {
      if (name.toLowerCase() == 'energia') return name;
    }
    for (final name in system.resources) {
      if (name != _lifeResourceName()) return name;
    }
    return '';
  }

  Widget _resourceSummaryCard(
    BuildContext context, {
    required String keyId,
    required String title,
    required String resourceName,
    required bool secondary,
  }) {
    final theme = Theme.of(context);
    final value = resourceName.isEmpty ? 0 : (character.resourceValues[resourceName] ?? 0);
    final max = resourceName.isEmpty ? 0 : (character.resourceMaxValues[resourceName] ?? 0);
    final progress = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0);
    final themeId = context.watch<AppState>().themeId;
    return Card(
      key: ValueKey('general-$keyId'),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(secondary ? Icons.bolt : themedIcon(themeId, 'resources')),
            const SizedBox(width: 8),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold))),
            if (resourceName.isNotEmpty) ...[
              IconButton(
                tooltip: 'Diminuir',
                visualDensity: VisualDensity.compact,
                onPressed: () => onChangeResource(character, resourceName, -1),
                icon: const Icon(Icons.remove),
              ),
              Text('$value / $max', style: theme.textTheme.titleMedium),
              IconButton(
                tooltip: 'Aumentar',
                visualDensity: VisualDensity.compact,
                onPressed: () => onChangeResource(character, resourceName, 1),
                icon: const Icon(Icons.add),
              ),
              IconButton(
                tooltip: 'Ajustar valor',
                visualDensity: VisualDensity.compact,
                onPressed: () => onEditResource(character, resourceName),
                icon: const Icon(Icons.tune, size: 20),
              ),
            ],
          ]),
          if (resourceName.isEmpty) ...[
            const SizedBox(height: 8),
            const Text('Nenhum recurso configurado.'),
          ],
          const SizedBox(height: 8),
          if (resourceName.isNotEmpty)
            _ThemedResourceBar(
              value: progress,
              themeId: themeId,
              secondary: secondary,
            ),
        ]),
      ),
    );
  }

  Widget _verticalSummaryItems(BuildContext context, List<String> names, Map<String, Map<String, dynamic>> details, {required bool ability}) {
    if (names.isEmpty) return Text(ability ? 'Nenhuma habilidade.' : 'Nenhum item.');
    final compact = context.watch<AppState>().compactMode;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: names.take(5).map((name) {
        final d = details[name] ?? const <String, dynamic>{};
        final category = d['category']?.toString().trim().isNotEmpty == true ? d['category'].toString() : (ability ? 'Habilidade' : 'Outro');
        final damage = d['damage']?.toString().trim() ?? '';
        final qty = d['quantity']?.toString() ?? '';
        final ammo = d['ammo']?.toString() ?? '';
        final ammoMax = d['ammoMax']?.toString() ?? '';
        final cost = d['cost']?.toString() ?? '';
        final resource = d['resource']?.toString() ?? 'Energia';
        final durationType = d['durationType']?.toString() ?? '';
        final turns = d['turns']?.toString() ?? '';
        return Padding(
          padding: EdgeInsets.only(bottom: compact ? 6 : 10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(category, style: Theme.of(context).textTheme.labelSmall?.copyWith(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700)),
            Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
            if (damage.isNotEmpty) Text('Dano: $damage'),
            if (!ability && category == 'Consumível') Text('Quantidade: ${qty.isEmpty ? '1' : qty}'),
            if (!ability && category == 'Arma' && ammoMax.isNotEmpty) Text('Munição: ${ammo.isEmpty ? ammoMax : ammo}/$ammoMax'),
            if (ability && category == 'Magia' && cost.isNotEmpty) Text('Custo: $cost $resource'),
            if (ability && durationType == 'turns' && turns.isNotEmpty) Text('Duração: $turns turno(s)'),
            if (ability && durationType == 'instant') const Text('Duração: Instantânea'),
          ]),
        );
      }).toList(),
    );
  }

  Widget _summaryCard(BuildContext context, String id) {
    final themeId = context.watch<AppState>().themeId;
    switch (id) {
      case 'attributes':
        return Card(
          key: const ValueKey('general-attributes'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(themedIcon(themeId, 'attributes')), const SizedBox(width: 8), const Text('Atributos', style: TextStyle(fontWeight: FontWeight.bold))]),
              const SizedBox(height: 10),
              if (system.attributes.isEmpty)
                const Text('Nenhum atributo configurado.')
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: system.attributes.map((name) => Chip(label: Text('$name: ${character.attributes[name] ?? 0}'))).toList(),
                ),
            ]),
          ),
        );
      case 'health':
        final resource = _lifeResourceName();
        return _resourceSummaryCard(
          context,
          keyId: 'health',
          title: resource.isEmpty ? 'Vida' : resource,
          resourceName: resource,
          secondary: false,
        );
      case 'energy':
        final resource = _energyResourceName();
        return _resourceSummaryCard(
          context,
          keyId: 'energy',
          title: resource.isEmpty ? 'Energia' : resource,
          resourceName: resource,
          secondary: true,
        );
      case 'skillTree':
        final unlocked = character.skillTree.where((node) => node['unlocked'] == true).toList();
        final names = unlocked.map((node) => node['name']?.toString() ?? 'Habilidade').where((name) => name.isNotEmpty).toList();
        return Card(
          key: const ValueKey('general-skill-tree'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(themedIcon(themeId, 'skillTree')),
                const SizedBox(width: 8),
                const Expanded(child: Text('Árvore de Habilidades', style: TextStyle(fontWeight: FontWeight.bold))),
                Text('${unlocked.length}/${character.skillTree.length}'),
              ]),
              const SizedBox(height: 8),
              _compactLines(names, character.skillTree.isEmpty ? 'Nenhuma skill criada.' : 'Nenhuma skill desbloqueada.'),
            ]),
          ),
        );
      case 'inventory':
        final lines = character.inventory;
        return Card(
          key: const ValueKey('general-inventory'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(themedIcon(themeId, 'inventory')), const SizedBox(width: 8), const Text('Inventário', style: TextStyle(fontWeight: FontWeight.bold)), const Spacer(), Text('${character.inventory.length} item(ns)')]),
              const SizedBox(height: 8),
              _verticalSummaryItems(context, lines, character.inventoryDetails, ability: false),
            ]),
          ),
        );
      case 'abilities':
        final lines = character.abilities;
        return Card(
          key: const ValueKey('general-abilities'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(themedIcon(themeId, 'abilities')), const SizedBox(width: 8), const Text('Habilidades', style: TextStyle(fontWeight: FontWeight.bold)), const Spacer(), Text('${character.abilities.length}')]),
              const SizedBox(height: 8),
              _verticalSummaryItems(context, lines, character.abilityDetails, ability: true),
            ]),
          ),
        );
      default:
        return const SizedBox.shrink(key: ValueKey('general-unknown'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final validIds = const ['health', 'energy', 'attributes', 'skillTree', 'abilities', 'inventory'];
    final order = <String>[];
    for (final id in character.generalOrder) {
      if (validIds.contains(id) && !order.contains(id)) order.add(id);
    }
    for (final id in validIds) {
      if (!order.contains(id)) order.add(id);
    }

    return ReorderableListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      itemCount: order.length,
      onReorder: (oldIndex, newIndex) => onReorder(character, oldIndex, newIndex),
      buildDefaultDragHandles: false,
      itemBuilder: (context, index) {
        final id = order[index];
        return Padding(
          key: ValueKey('general-item-$id'),
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(children: [
            Expanded(child: _summaryCard(context, id)),
            ReorderableDragStartListener(
              index: index,
              child: const Padding(padding: EdgeInsets.only(left: 8), child: Icon(Icons.drag_handle)),
            ),
          ]),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  const _Header({required this.character, required this.system});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 16),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(character.name, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(
            '${character.race.isEmpty ? 'Sem raça' : character.race} • ${character.className.isEmpty ? 'Sem classe' : character.className} • Nível ${character.level}',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerHighest.withOpacity(.42),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: scheme.outlineVariant.withOpacity(.22)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.auto_awesome, size: 14, color: scheme.primary),
              const SizedBox(width: 6),
              Flexible(child: Text(system.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w600))),
            ]),
          ),
        ])),
      ]),
    );
  }
}

class _AttributesResourcesTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onEditAttribute;
  final Future<void> Function(Character, String, int) onChangeResource;
  final Future<void> Function(Character, String) onEditResource;

  const _AttributesResourcesTab({
    required this.character,
    required this.system,
    required this.onEditAttribute,
    required this.onChangeResource,
    required this.onEditResource,
  });

  @override
  Widget build(BuildContext context) {
    final themeId = context.watch<AppState>().themeId;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Icon(themedIcon(themeId, 'attributes'), size: 22),
            const SizedBox(width: 8),
            Text('Atributos', style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
        const SizedBox(height: 10),
        if (system.attributes.isEmpty)
          const Text('Este sistema não possui atributos configurados.')
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: system.attributes.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 2.75,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemBuilder: (_, index) {
              final name = system.attributes[index];
              final value = character.attributes[name] ?? 0;
              return Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => onEditAttribute(character, name),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w700),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 0),
                        Text(
                          '$value',
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        const SizedBox(height: 24),
        Row(
          children: [
            Icon(themedIcon(themeId, 'resources')),
            const SizedBox(width: 8),
            Text('Recursos', style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
        const SizedBox(height: 10),
        if (system.resources.isEmpty)
          const Text('Este sistema não possui recursos configurados.'),
        ...system.resources.map((name) {
          final value = character.resourceValues[name] ?? 0;
          final max = character.resourceMaxValues[name] ?? 0;
          final progress = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0);
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(name.toLowerCase() == 'vida'
                          ? themedIcon(themeId, 'resources')
                          : Icons.bolt),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      IconButton(
                        onPressed: () => onChangeResource(character, name, -1),
                        icon: const Icon(Icons.remove),
                      ),
                      Text('$value / $max'),
                      IconButton(
                        onPressed: () => onChangeResource(character, name, 1),
                        icon: const Icon(Icons.add),
                      ),
                      IconButton(
                        onPressed: () => onEditResource(character, name),
                        icon: const Icon(Icons.tune),
                      ),
                    ],
                  ),
                  _ThemedResourceBar(
                    value: progress,
                    themeId: themeId,
                    secondary: name.toLowerCase() != 'vida',
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }
}

class _ThemedResourceBar extends StatelessWidget {
  final double value;
  final String themeId;
  final bool secondary;

  const _ThemedResourceBar({
    required this.value,
    required this.themeId,
    this.secondary = false,
  });

  @override
  Widget build(BuildContext context) {
    final fillColors = themedResourceBarColors(themeId, secondary: secondary);
    final trackColor = themedResourceTrackColor(themeId);
    final scheme = Theme.of(context).colorScheme;
    final normalized = value.clamp(0.0, 1.0);

    return Container(
      height: 14,
      decoration: BoxDecoration(
        color: trackColor,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: scheme.outlineVariant.withOpacity(.45)),
        boxShadow: [
          BoxShadow(
            color: scheme.primary.withOpacity(.08),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final fillWidth = constraints.maxWidth * normalized;
          return Stack(
            children: [
              if (fillWidth > 0)
                Align(
                  alignment: Alignment.center,
                  child: Container(
                  width: fillWidth,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: fillColors),
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
                ),
              if (themeId == 'cyberpunk' && fillWidth > 18)
                Positioned.fill(
                  child: IgnorePointer(
                    child: CustomPaint(
                      painter: _CyberpunkBarPainter(progress: normalized),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _CyberpunkBarPainter extends CustomPainter {
  final double progress;
  const _CyberpunkBarPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final activeWidth = size.width * progress;
    final paint = Paint()
      ..color = Colors.white.withOpacity(.14)
      ..strokeWidth = 1;
    const segment = 16.0;
    for (double x = segment; x < activeWidth; x += segment) {
      canvas.drawLine(Offset(x, 2), Offset(x, size.height - 2), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _CyberpunkBarPainter oldDelegate) => oldDelegate.progress != progress;
}

class _SkillsTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onToggle;
  const _SkillsTab({required this.character, required this.system, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Perícias do sistema', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8),
      if (system.skills.isEmpty) const Text('Este sistema não possui perícias configuradas.')
      else ...system.skills.map((skill) => Card(child: CheckboxListTile(value: character.skills.contains(skill), onChanged: (_) => onToggle(character, skill), title: Text(skill), secondary: const Icon(Icons.psychology)))),
      const SizedBox(height: 16),
      if (character.skills.isNotEmpty) Text('Perícias selecionadas: ${character.skills.join(', ')}', style: Theme.of(context).textTheme.bodySmall),
    ]);
  }
}

class _SectionsTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onEdit;
  const _SectionsTab({required this.character, required this.system, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Seções da ficha', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 10),
      if (system.sections.isEmpty) const Text('Este sistema não possui seções configuradas.'),
      ...system.sections.map((section) => Card(child: ListTile(title: Text(section), subtitle: Text((character.sectionNotes[section] ?? '').isEmpty ? 'Toque para preencher.' : character.sectionNotes[section]!), trailing: const Icon(Icons.edit), onTap: () => onEdit(character, section)))),
    ]);
  }
}

class _ActionsTab extends StatefulWidget {
  final Character character;
  final RpgSystem system;
  const _ActionsTab({required this.character, required this.system});
  @override State<_ActionsTab> createState() => _ActionsTabState();
}

class _ActionsTabState extends State<_ActionsTab> with SingleTickerProviderStateMixin {
  late final AnimationController _idle;
  static const _groups = ['weapons', 'spells', 'abilities', 'consumables'];
  static const _labels = {'weapons':'Armas','spells':'Magias','abilities':'Habilidades','consumables':'Consumíveis'};
  @override void initState(){super.initState();_idle=AnimationController(vsync:this,duration:const Duration(milliseconds:2600))..repeat(reverse:true);}
  @override void dispose(){_idle.dispose();super.dispose();}
  Future<void> _save() async {await context.read<AppState>().updateCharacter(widget.character);if(!mounted)return;setState((){});}
  void _actionError(String message){if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(message)));}

  Future<void> _useItem(String name) async {
    final d=widget.character.inventoryDetails[name]??=<String,dynamic>{}; final cat=d['category']?.toString()??'Outro';
    if(cat=='Consumível'){
      final q=(d['quantity'] as num?)?.toInt()??1;if(q<=0){_actionError('Sem unidades de $name.');return;}
      d['quantity']=q-1; final effect=(d['effectValue'] as num?)?.toInt()??0; final resource=d['effectResource']?.toString()??'';
      if(effect!=0 && resource.isNotEmpty && widget.character.resourceValues.containsKey(resource)){
        final cur=widget.character.resourceValues[resource]??0, max=widget.character.resourceMaxValues[resource]??cur;
        widget.character.resourceValues[resource]=(cur+effect).clamp(0,max);
        if(resource.toLowerCase()=='vida')widget.character.hp=widget.character.resourceValues[resource]!;
        if(resource.toLowerCase()=='energia')widget.character.energy=widget.character.resourceValues[resource]!;
      }
      return _save();
    }
    if(cat=='Arma'){
      final max=(d['ammoMax'] as num?)?.toInt()??0, ammo=(d['ammo'] as num?)?.toInt()??max;
      if(max>0){if(ammo<=0){_actionError('$name está sem munição.');return;}d['ammo']=ammo-1;}
      return _save();
    }
  }
  Future<void> _reload(String name) async {
    final d=widget.character.inventoryDetails[name]??=<String,dynamic>{};final max=(d['ammoMax'] as num?)?.toInt()??0, current=(d['ammo'] as num?)?.toInt()??0;if(max<=0||current>=max)return;
    final needed=max-current, ammoItem=d['ammoItem']?.toString()??'';
    if(ammoItem.isEmpty){d['ammo']=max;return _save();}
    final stock=widget.character.inventoryDetails[ammoItem];if(stock==null){_actionError('Estoque de munição não encontrado.');return;}
    final available=(stock['quantity'] as num?)?.toInt()??0;if(available<=0){_actionError('Sem $ammoItem no inventário.');return;}
    final used=available<needed?available:needed;d['ammo']=current+used;stock['quantity']=available-used;
    return _save();
  }
  Future<void> _cast(String name) async {final d=widget.character.abilityDetails[name]??=<String,dynamic>{};final cost=(d['cost'] as num?)?.toInt()??0;final resource=d['resource']?.toString().isNotEmpty==true?d['resource'].toString():'Energia';final current=widget.character.resourceValues[resource]??0;if(current<cost){_actionError('$resource insuficiente para $name.');return;}widget.character.resourceValues[resource]=current-cost;if(resource.toLowerCase()=='energia')widget.character.energy=current-cost;if(resource.toLowerCase()=='vida')widget.character.hp=current-cost;await _save();}
  Future<void> _changeResource(String name,int delta) async{final current=widget.character.resourceValues[name]??0,max=widget.character.resourceMaxValues[name]??0;widget.character.resourceValues[name]=(current+delta).clamp(0,max);if(name.toLowerCase()=='vida')widget.character.hp=widget.character.resourceValues[name]!;if(name.toLowerCase()=='energia')widget.character.energy=widget.character.resourceValues[name]!;await _save();}
  Future<void> _editResourceValue(String name) async{final current=widget.character.resourceValues[name]??0,max=widget.character.resourceMaxValues[name]??0;final a=TextEditingController(text:'$current'),b=TextEditingController(text:'$max');final result=await showDialog<List<int>>(context:context,builder:(ctx)=>AlertDialog(title:Text('Ajustar $name'),content:Row(children:[Expanded(child:TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Atual'))),const SizedBox(width:10),Expanded(child:TextField(controller:b,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Máximo')))]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(ctx,[int.tryParse(a.text)??current,int.tryParse(b.text)??max]),child:const Text('Salvar'))]));a.dispose();b.dispose();if(result==null)return;final nextMax=result[1]<0?0:result[1];widget.character.resourceMaxValues[name]=nextMax;widget.character.resourceValues[name]=result[0].clamp(0,nextMax);if(name.toLowerCase()=='vida')widget.character.hp=widget.character.resourceValues[name]!;if(name.toLowerCase()=='energia')widget.character.energy=widget.character.resourceValues[name]!;await _save();}
  Widget _resource(String name){final current=widget.character.resourceValues[name]??0,max=widget.character.resourceMaxValues[name]??0,value=max<=0?0.0:(current/max).clamp(0.0,1.0);final themeId=context.watch<AppState>().themeId,secondary=name.toLowerCase()!='vida';return Card(child:Padding(padding:const EdgeInsets.fromLTRB(14,10,14,12),child:Column(children:[Row(children:[Icon(secondary?Icons.bolt:themedIcon(themeId,'resources'),size:22),const SizedBox(width:8),Expanded(child:Text(name,style:const TextStyle(fontWeight:FontWeight.w700))),IconButton(tooltip:'Diminuir',visualDensity:VisualDensity.compact,onPressed:()=>_changeResource(name,-1),icon:const Icon(Icons.remove)),Text('$current / $max',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w600)),IconButton(tooltip:'Aumentar',visualDensity:VisualDensity.compact,onPressed:()=>_changeResource(name,1),icon:const Icon(Icons.add)),IconButton(tooltip:'Ajustar valor',visualDensity:VisualDensity.compact,onPressed:()=>_editResourceValue(name),icon:const Icon(Icons.tune,size:20))]),const SizedBox(height:7),_ThemedResourceBar(value:value,themeId:themeId,secondary:secondary)])));}

  Future<void> _selectConditions() async {
    final initial = widget.character.conditions.toSet();
    final selected = <String>{...initial};
    final result = await showModalBottomSheet<Set<String>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) {
          final custom = selected.where((name) => conditionPresetFor(name) == null).toList();
          final scheme = Theme.of(context).colorScheme;
          return SafeArea(
            child: Padding(
              padding: EdgeInsets.fromLTRB(18, 0, 18, MediaQuery.of(context).viewInsets.bottom + 18),
              child: SingleChildScrollView(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Condições do personagem', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 5),
                  Text('Marque as condições ativas. Você pode alterar várias de uma vez.', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: scheme.onSurfaceVariant)),
                  const SizedBox(height: 16),
                  Text('Condições', style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: conditionPresets.map((preset) {
                      final active = selected.contains(preset.name);
                      return FilterChip(
                        selected: active,
                        avatar: Icon(preset.icon, size: 18),
                        label: Text(preset.name),
                        onSelected: (value) => setSheetState(() => value ? selected.add(preset.name) : selected.remove(preset.name)),
                      );
                    }).toList(),
                  ),
                  if (custom.isNotEmpty) ...[
                    const SizedBox(height: 18),
                    Text('Condições antigas/personalizadas', style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    Wrap(spacing: 8, runSpacing: 8, children: custom.map((name) => InputChip(
                      avatar: const Icon(Icons.flag_outlined, size: 18),
                      label: Text(name),
                      onDeleted: () => setSheetState(() => selected.remove(name)),
                    )).toList()),
                  ],
                  const SizedBox(height: 20),
                  Row(children: [
                    TextButton(onPressed: () => setSheetState(selected.clear), child: const Text('Limpar')),
                    const Spacer(),
                    TextButton(onPressed: () => Navigator.pop(sheetContext), child: const Text('Cancelar')),
                    const SizedBox(width: 8),
                    FilledButton(onPressed: () => Navigator.pop(sheetContext, selected), child: const Text('Aplicar')),
                  ]),
                ]),
              ),
            ),
          );
        },
      ),
    );
    if (result == null) return;
    final ordered = <String>[
      ...conditionPresets.where((preset) => result.contains(preset.name)).map((preset) => preset.name),
      ...result.where((name) => conditionPresetFor(name) == null),
    ];
    widget.character.conditions = ordered;
    await _save();
  }

  Widget _conditionChip(String name) {
    final preset = conditionPresetFor(name);
    final scheme = Theme.of(context).colorScheme;
    return InputChip(
      avatar: Icon(preset?.icon ?? Icons.flag_outlined, size: 18, color: preset?.positive == true ? scheme.tertiary : scheme.primary),
      label: Text(name),
      onPressed: _selectConditions,
      onDeleted: () async {
        widget.character.conditions.remove(name);
        await _save();
      },
    );
  }
  Future<void> _customize() async {
    var order = <String>[
      ...widget.character.actionOrder.where(_groups.contains),
      ..._groups.where((g) => !widget.character.actionOrder.contains(g)),
    ];
    var hidden = <String>{...widget.character.hiddenActionGroups};
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => SafeArea(
          child: SizedBox(
            height: 420,
            child: Column(
              children: [
                const ListTile(
                  title: Text('Personalizar Ações'),
                  subtitle: Text('Arraste os grupos e escolha quais aparecem.'),
                ),
                Expanded(
                  child: ReorderableListView(
                    onReorder: (oldIndex, newIndex) {
                      setSheet(() {
                        if (newIndex > oldIndex) newIndex--;
                        final item = order.removeAt(oldIndex);
                        order.insert(newIndex, item);
                      });
                    },
                    children: [
                      for (final group in order)
                        SwitchListTile(
                          key: ValueKey(group),
                          value: !hidden.contains(group),
                          onChanged: (visible) => setSheet(() {
                            if (visible) { hidden.remove(group); } else { hidden.add(group); }
                          }),
                          title: Text(_labels[group]!),
                          secondary: const Icon(Icons.drag_handle),
                        ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => Navigator.pop(ctx, {'order': order, 'hidden': hidden.toList()}),
                      child: const Text('Salvar'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (result != null) {
      widget.character.actionOrder = List<String>.from(result['order']);
      widget.character.hiddenActionGroups = List<String>.from(result['hidden']);
      await _save();
    }
  }

  Widget _group(String id,bool compact){final c=widget.character;List<String> names=[];if(id=='weapons')names=c.inventory.where((n)=>c.inventoryDetails[n]?['category']=='Arma').toList();if(id=='consumables')names=c.inventory.where((n)=>c.inventoryDetails[n]?['category']=='Consumível').toList();if(id=='spells')names=c.abilities.where((n)=>c.abilityDetails[n]?['category']=='Magia').toList();if(id=='abilities')names=c.abilities.where((n){final x=c.abilityDetails[n]?['category'];return x=='Técnica'||x=='Habilidade';}).toList();if(names.isEmpty)return const SizedBox.shrink();return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Padding(padding:EdgeInsets.fromLTRB(2,compact?5:10,2,4),child:Text(_labels[id]!,style:Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight:FontWeight.bold))),...names.map((name){final d=(id=='weapons'||id=='consumables')?c.inventoryDetails[name]??{}:c.abilityDetails[name]??{};final sub=<String>[];if(d['damage']?.toString().isNotEmpty==true)sub.add('Dano: ${d['damage']}');if(id=='weapons'){final max=(d['ammoMax'] as num?)?.toInt()??0;if(max>0)sub.add('Munição: ${(d['ammo'] as num?)?.toInt()??max}/$max');final linked=d['ammoItem']?.toString()??'';if(linked.isNotEmpty)sub.add('Estoque: ${c.inventoryDetails[linked]?['quantity']??0}');}if(id=='consumables'){sub.add('Quantidade: ${d['quantity']??1}');final e=(d['effectValue'] as num?)?.toInt()??0;if(e!=0)sub.add('Efeito: ${e>0?'+':''}$e ${d['effectResource']??''}');}if(id=='spells'||id=='abilities'){final cost=(d['cost'] as num?)?.toInt()??0;if(cost>0)sub.add('Custo: $cost ${d['resource']??'Energia'}');}return Card(margin:EdgeInsets.only(bottom:compact?4:7),child:Padding(padding:EdgeInsets.all(compact?7:10),child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(name,style:const TextStyle(fontWeight:FontWeight.bold)),if(sub.isNotEmpty)Text(sub.join(' • '),style:Theme.of(context).textTheme.bodySmall)])),if(id=='weapons'&&((d['ammoMax'] as num?)?.toInt()??0)>0)IconButton(visualDensity:VisualDensity.compact,onPressed:()=>_reload(name),tooltip:'Recarregar',icon:const Icon(Icons.refresh)),FilledButton.tonal(onPressed:()=>id=='spells'||id=='abilities'?_cast(name):_useItem(name),child:Text(id=='weapons'?'Atirar':id=='spells'?'Lançar':'Usar'))])));})]);}

  @override Widget build(BuildContext context){final c=widget.character,compact=context.watch<AppState>().compactMode;final order=[...c.actionOrder.where(_groups.contains),..._groups.where((g)=>!c.actionOrder.contains(g))];return ListView(padding:EdgeInsets.fromLTRB(compact?10:16,compact?10:14,compact?10:16,28),children:[_resource('Vida'),SizedBox(height:compact?6:8),_resource('Energia'),SizedBox(height:compact?10:14),Row(children:[Text('Condições ativas',style:Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight:FontWeight.w700)),const Spacer(),TextButton.icon(onPressed:_selectConditions,icon:const Icon(Icons.flag_outlined,size:18),label:const Text('Alterar'))]),if(c.conditions.isEmpty)Text('Nenhuma condição ativa.',style:Theme.of(context).textTheme.bodySmall?.copyWith(color:Theme.of(context).colorScheme.onSurfaceVariant))else Wrap(spacing:7,runSpacing:7,children:c.conditions.map(_conditionChip).toList()),SizedBox(height:compact?10:14),Row(children:[Text('Ações rápidas',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w700)),const Spacer(),IconButton(tooltip:'Personalizar',visualDensity:VisualDensity.compact,onPressed:_customize,icon:const Icon(Icons.tune,size:20))]),...order.where((g)=>!c.hiddenActionGroups.contains(g)).map((g)=>_group(g,compact))]);}
}

class _CharacterItemsTab extends StatefulWidget {
  final Character character;
  final List<String> items;
  final Map<String, String> descriptions;
  final Map<String, Map<String, dynamic>> details;
  final String title;
  final String singular;
  final String hint;
  final String iconRole;
  final bool isAbility;

  const _CharacterItemsTab({
    required this.character,
    required this.items,
    required this.descriptions,
    required this.details,
    required this.title,
    required this.singular,
    required this.hint,
    required this.iconRole,
    required this.isAbility,
  });

  @override
  State<_CharacterItemsTab> createState() => _CharacterItemsTabState();
}

class _CharacterItemsTabState extends State<_CharacterItemsTab> {
  IconData _itemIcon(String category){if(widget.isAbility)return category=='Magia'?Icons.auto_awesome_outlined:category=='Técnica'?Icons.sports_martial_arts:Icons.bolt_outlined;return switch(category){'Arma'=>Icons.gps_fixed,'Armadura'=>Icons.shield_outlined,'Consumível'=>Icons.local_drink_outlined,'Munição'=>Icons.more_horiz,'Acessório'=>Icons.diamond_outlined,'Ferramenta'=>Icons.build_outlined,_=>Icons.inventory_2_outlined};}
  List<String> get _categories => widget.isAbility
      ? const ['Habilidade', 'Magia', 'Técnica', 'Passiva', 'Outro']
      : const ['Arma', 'Armadura', 'Consumível', 'Munição', 'Acessório', 'Ferramenta', 'Outro'];

  Future<void> _openEditor({int? index}) async {
    final editing = index != null;
    final oldName = editing ? widget.items[index] : '';
    final old = editing ? (widget.details[oldName] ?? <String, dynamic>{}) : <String, dynamic>{};
    final name = TextEditingController(text: oldName);
    final description = TextEditingController(text: editing ? (widget.descriptions[oldName] ?? '') : '');
    final damage = TextEditingController(text: old['damage']?.toString() ?? '');
    final turns = TextEditingController(text: old['turns']?.toString() ?? '');
    final quantity = TextEditingController(text: old['quantity']?.toString() ?? '1');
    final ammo = TextEditingController(text: old['ammo']?.toString() ?? '');
    final ammoMax = TextEditingController(text: old['ammoMax']?.toString() ?? '');
    final cost = TextEditingController(text: old['cost']?.toString() ?? '');
    final effectValue = TextEditingController(text: old['effectValue']?.toString() ?? '');
    String effectResource = old['effectResource']?.toString() ?? 'Vida';
    String ammoItem = old['ammoItem']?.toString() ?? '';
    String resource = old['resource']?.toString() ?? 'Energia';
    String category = old['category']?.toString() ?? (widget.isAbility ? 'Habilidade' : 'Outro');
    if (!_categories.contains(category)) category = widget.isAbility ? 'Habilidade' : 'Outro';
    String durationType = old['durationType']?.toString() ?? 'instant';

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) {
          final isMagic = widget.isAbility && category == 'Magia';
          final isWeapon = !widget.isAbility && category == 'Arma';
          final isConsumable = !widget.isAbility && category == 'Consumível';
          final isAmmo = !widget.isAbility && category == 'Munição';
          return AlertDialog(
            title: Text(editing ? 'Editar ${widget.singular}' : 'Adicionar ${widget.singular}'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(controller: name, textCapitalization: TextCapitalization.sentences, autofocus: !editing, decoration: InputDecoration(labelText: widget.hint)),
                const SizedBox(height: 12),
                DropdownMenu<String>(
                  initialSelection: category,
                  expandedInsets: EdgeInsets.zero,
                  label: const Text('Categoria'),
                  menuStyle: const MenuStyle(alignment: AlignmentDirectional.bottomStart),
                  dropdownMenuEntries: _categories.map((e) => DropdownMenuEntry(value: e, label: e)).toList(),
                  onSelected: (v) { if (v != null) setDialogState(() => category = v); },
                ),
                const SizedBox(height: 12),
                TextField(controller: description, textCapitalization: TextCapitalization.sentences, minLines: 3, maxLines: 6, decoration: const InputDecoration(labelText: 'Descrição', hintText: 'Detalhes, efeitos, observações...')),
                if (isWeapon || isMagic) ...[
                  const SizedBox(height: 12),
                  TextField(controller: damage, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Dano', hintText: 'Ex.: 1d8, 2d6+3 ou 5')),
                ],
                if (isWeapon) ...[
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: TextField(controller: ammo, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Munição atual'))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: ammoMax, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Munição máxima'))),
                  ]),
                
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: widget.character.inventory.contains(ammoItem) ? ammoItem : '',
                    decoration: const InputDecoration(labelText: 'Estoque de munição vinculado'),
                    items: [
                      const DropdownMenuItem(value: '', child: Text('Nenhum — recarga livre')),
                      ...widget.character.inventory.where((i) { final cat = widget.character.inventoryDetails[i]?['category']; return i != oldName && (cat == 'Munição' || (i == ammoItem && cat == 'Consumível')); }).map((i) => DropdownMenuItem(value: i, child: Text(i))),
                    ],
                    onChanged: (v) => setDialogState(() => ammoItem = v ?? ''),
                  ),
                ],
                if (isConsumable || isAmmo) ...[
                  const SizedBox(height: 12),
                  TextField(controller: quantity, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantidade')),
                ],
                if (isConsumable) ...[
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: DropdownButtonFormField<String>(
                      value: widget.character.resourceValues.containsKey(effectResource) ? effectResource : (widget.character.resourceValues.keys.isNotEmpty ? widget.character.resourceValues.keys.first : null),
                      decoration: const InputDecoration(labelText: 'Efeito opcional'),
                      items: widget.character.resourceValues.keys.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
                      onChanged: (v) => setDialogState(() => effectResource = v ?? effectResource),
                    )),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: effectValue, keyboardType: const TextInputType.numberWithOptions(signed: true), decoration: const InputDecoration(labelText: 'Valor', hintText: 'Ex.: 10 ou -5'))),
                  ]),
                ],
                if (isMagic && category != 'Passiva') ...[
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: TextField(controller: cost, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Custo'))),
                    const SizedBox(width: 8),
                    Expanded(child: DropdownButtonFormField<String>(value: widget.character.resourceValues.containsKey(resource) ? resource : (widget.character.resourceValues.keys.isNotEmpty ? widget.character.resourceValues.keys.first : 'Energia'), decoration: const InputDecoration(labelText: 'Recurso'), items: widget.character.resourceValues.keys.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(), onChanged: (v) => setDialogState(() => resource = v ?? resource))),
                  ]),
                ],
                if (isMagic) ...[
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: durationType,
                    decoration: const InputDecoration(labelText: 'Duração'),
                    items: const [
                      DropdownMenuItem(value: 'instant', child: Text('Direto / instantâneo')),
                      DropdownMenuItem(value: 'turns', child: Text('Por turnos')),
                    ],
                    onChanged: (v) => setDialogState(() => durationType = v ?? durationType),
                  ),
                  if (durationType == 'turns') ...[
                    const SizedBox(height: 12),
                    TextField(controller: turns, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantidade de turnos')),
                  ],
                ],
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
              FilledButton(
                onPressed: () {
                  final n = name.text.trim();
                  if (n.isEmpty) return;
                  Navigator.pop(dialogContext, {
                    'name': n,
                    'description': description.text.trim(),
                    'category': category,
                    'damage': (isWeapon || isMagic) ? damage.text.trim() : '',
                    'durationType': isMagic ? durationType : '',
                    'turns': isMagic && durationType == 'turns' ? turns.text.trim() : '',
                    'quantity': (isConsumable || isAmmo) ? (int.tryParse(quantity.text) ?? 1).clamp(0, 999999) : null,
                    'ammo': isWeapon ? (int.tryParse(ammo.text) ?? 0).clamp(0, 999999) : null,
                    'ammoMax': isWeapon ? (int.tryParse(ammoMax.text) ?? 0).clamp(0, 999999) : null,
                    'ammoItem': isWeapon ? ammoItem : '',
                    'effectResource': isConsumable ? effectResource : '',
                    'effectValue': isConsumable ? (int.tryParse(effectValue.text) ?? 0) : 0,
                    'cost': isMagic ? (int.tryParse(cost.text) ?? 0).clamp(0, 999999) : null,
                    'resource': isMagic ? resource : '',
                  });
                },
                child: const Text('Salvar'),
              ),
            ],
          );
        },
      ),
    );
    name.dispose(); description.dispose(); damage.dispose(); turns.dispose(); quantity.dispose(); ammo.dispose(); ammoMax.dispose(); cost.dispose(); effectValue.dispose();
    if (result == null) return;
    final newName = result['name'] as String;
    if (editing) {
      widget.items[index] = newName;
      if (oldName != newName) {
        widget.descriptions.remove(oldName);
        widget.details.remove(oldName);
      }
    } else {
      widget.items.add(newName);
    }
    widget.descriptions[newName] = result['description'] as String? ?? '';
    widget.details[newName] = Map<String, dynamic>.from(result)..remove('name')..remove('description');
    await context.read<AppState>().updateCharacter(widget.character);
    if (mounted) setState(() {});
  }

  Future<void> _delete(int index) async {
    final removed = widget.items[index];
    widget.items.removeAt(index);
    widget.descriptions.remove(removed);
    widget.details.remove(removed);
    await context.read<AppState>().updateCharacter(widget.character);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context){final icon=themedIcon(context.watch<AppState>().themeId,widget.iconRole),compact=context.watch<AppState>().compactMode;return ListView(padding:EdgeInsets.fromLTRB(compact?10:16,compact?10:14,compact?10:16,28),children:[Row(children:[Icon(icon,size:20),const SizedBox(width:8),Text(widget.title,style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w700)),const Spacer(),IconButton(onPressed:()=>_openEditor(),tooltip:'Adicionar',icon:const Icon(Icons.add))]),SizedBox(height:compact?6:10),if(widget.items.isEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:24),child:Center(child:Text('Nenhum item adicionado.',style:Theme.of(context).textTheme.bodyMedium?.copyWith(color:Theme.of(context).colorScheme.onSurfaceVariant))))else ...widget.items.asMap().entries.map((entry){final item=entry.value,detail=widget.details[item]??const <String,dynamic>{};final category=detail['category']?.toString()??'Outro',damage=detail['damage']?.toString()??'',qty=detail['quantity']?.toString()??'',ammo=detail['ammo']?.toString()??'',ammoMax=detail['ammoMax']?.toString()??'',cost=detail['cost']?.toString()??'',resource=detail['resource']?.toString()??'Energia';final meta=<String>[category];if(damage.isNotEmpty)meta.add('Dano $damage');if(!widget.isAbility&&(category=='Consumível'||category=='Munição'))meta.add('Qtd. ${qty.isEmpty?'1':qty}');if(!widget.isAbility&&category=='Arma'&&ammoMax.isNotEmpty)meta.add('${ammo.isEmpty?ammoMax:ammo}/$ammoMax');if(widget.isAbility&&category=='Magia'&&cost.isNotEmpty)meta.add('$cost $resource');return Card(margin:EdgeInsets.only(bottom:compact?5:8),child:InkWell(borderRadius:BorderRadius.circular(14),onTap:()=>_openEditor(index:entry.key),child:Padding(padding:EdgeInsets.symmetric(horizontal:compact?10:12,vertical:compact?8:11),child:Row(children:[Container(width:compact?34:40,height:compact?34:40,alignment:Alignment.center,decoration:BoxDecoration(color:Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(.42),borderRadius:BorderRadius.circular(10)),child:Icon(_itemIcon(category),size:compact?18:20,color:Theme.of(context).colorScheme.onSurfaceVariant)),const SizedBox(width:11),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(item,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w700)),const SizedBox(height:2),Text(meta.join(' • '),maxLines:1,overflow:TextOverflow.ellipsis,style:Theme.of(context).textTheme.bodySmall?.copyWith(color:Theme.of(context).colorScheme.onSurfaceVariant))])),PopupMenuButton<String>(tooltip:'Opções',onSelected:(v){if(v=='edit')_openEditor(index:entry.key);if(v=='delete')_delete(entry.key);},itemBuilder:(_)=>const [PopupMenuItem(value:'edit',child:Text('Editar')),PopupMenuItem(value:'delete',child:Text('Excluir'))])]))));})]);}
}

