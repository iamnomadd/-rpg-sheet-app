# RPG Sheet App — V0.11

## V0.9 — Preparação para conta e sincronização
- Nova central de Conta e Sincronização.
- Resumo dos dados locais: fichas, sistemas, campanhas e histórico de dados.
- Atalho para gerar backup completo antes da futura sincronização.
- Interface preparada para login e nuvem, sem fingir que existe um backend conectado.
- Nenhum dado é enviado à internet nesta versão.
- Mantém todas as funções da V0.8.

### Importante
A sincronização real entre aparelhos exige configurar um backend (por exemplo, Supabase ou Firebase). A V0.9 deixa a base de interface pronta, mas não ativa um serviço externo sem configuração/credenciais.

Versão do projeto: 0.11.0+18


## V0.10.0 — Interface e experiência

- Padronização visual geral em Material 3.
- Cards, campos, botões e navegação com espaçamento e cantos consistentes.
- Melhor leitura em telas pequenas e grandes.
- Estados vazios e confirmações preservados/melhorados.
- Tela de fichas, sistemas, dados, campanhas e configurações revisadas visualmente.
- Aba Geral continua somente leitura e com blocos reordenáveis.
- Criador de sistemas continua sem fórmulas automáticas/atributos derivados.
- Identificação visual da versão: V0.10.0.
- Mantém compatibilidade com os dados locais das versões anteriores.

## V0.10.1 — Temas
- 10 temas visuais: Clássico Escuro, Pergaminho, Medieval, Arcano, Vampírico, Floresta, Oceano, Cyberpunk, Infernal e Gelo.
- Seletor em Configurações > Aparência e temas.
- O tema altera cores, superfícies, cantos e a identidade por ícones da tela de seleção.
- A escolha é salva localmente e restaurada ao abrir o app.


## V0.10.2 — Identidade dos Temas
- Paletas reforçadas para Pergaminho, Medieval, Vampírico, Floresta, Oceano, Infernal e Gelo.
- Clássico, Cyberpunk e Arcano preservam suas paletas aprovadas.
- Ícones principais da ficha agora mudam de linguagem visual conforme o tema.
- Cyberpunk usa símbolos mais tecnológicos/HUD; Arcano usa símbolos místicos; demais temas recebem identidade própria.
- Sem fórmulas automáticas/atributos derivados.


## V0.10.3 — Temas e navegação da ficha

- Oceano foi substituído por **Elemento Ar** (branco/cinza).
- Floresta foi substituída por **Elemento Terra** (tons terrosos).
- Pergaminho foi substituído por **Sombrio** (preto/cinza).
- Nova ordem da ficha: **Geral → Atrib./Rec. → Habilidades → Perícias → Inventário → Seções**.
- Atributos e Recursos agora compartilham uma única aba.
- Habilidades e Inventário ganharam abas próprias.
- A aba Extras foi removida da navegação principal.
- Compatibilidade com os dados existentes foi preservada.


## V0.10.4 — Refinamento visual

- Barra de navegação da ficha refinada.
- Ícones selecionados agora possuem variações próprias por tema.
- Tema Cyberpunk recebeu navegação mais angular e tecnológica.
- Tema Arcano usa indicador mais suave/místico.
- Temas Medieval, Sombrio e Infernal possuem formas de seleção próprias.
- Melhor contraste entre ícones ativos e inativos.
- Leve destaque de borda na barra da ficha para separar a navegação do conteúdo.
- Mantida a ordem: Geral → Atrib./Rec. → Habilidades → Perícias → Inventário → Seções.
- Versão 0.10.4+17.

## V0.11 — Criador de Sistemas Avançado

- Editor de sistemas reorganizado com resumo da estrutura e contadores.
- Atributos, perícias, recursos e seções agora podem ser renomeados diretamente.
- Itens podem ser reorganizados por arrastar e soltar; a nova ordem é refletida na ficha.
- Proteção contra nomes duplicados dentro da mesma categoria.
- Confirmação antes de excluir elementos estruturais.
- Renomeações preservam os valores já preenchidos nas fichas vinculadas ao sistema.
- Novos elementos são sincronizados com fichas existentes ao salvar o sistema.
- Editor de dados mantido e organização automática dos dados por quantidade de faces.
- Fórmulas automáticas/atributos derivados não foram adicionados nesta versão.
- Versão 0.11.0+18.

## V0.12 — Sessão de RPG

- Nova central **Sessão de RPG** dentro das campanhas no Modo Mestre.
- Contador de rodadas com avanço, retorno e reinício.
- Rastreador de iniciativa com ordenação automática do maior para o menor.
- Controle rápido dos recursos das fichas vinculadas à campanha, com botões de +1 e -1.
- Registro de condições ativas durante a sessão.
- Notas rápidas da sessão, separadas das notas gerais e das notas privadas do mestre.
- Dados de sessão ficam salvos junto da campanha e entram normalmente em backup/exportação.
- Compatibilidade preservada com campanhas criadas nas versões anteriores.
- Sem fórmulas automáticas/atributos derivados.
- Versão 0.12.0+19.
