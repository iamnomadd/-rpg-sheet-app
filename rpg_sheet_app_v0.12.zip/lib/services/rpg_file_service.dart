import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';

import '../models/campaign.dart';
import '../models/character.dart';
import '../models/rpg_system.dart';
import 'app_state.dart';

class RpgFileService {
  static const format = 'rpg_sheet';
  static const formatVersion = 1;
  static const _uuid = Uuid();

  static Map<String, dynamic> _envelope({
    required String type,
    required dynamic data,
  }) => {
        'format': format,
        'formatVersion': formatVersion,
        'type': type,
        'exportedAt': DateTime.now().toIso8601String(),
        'data': data,
      };

  static Future<void> _shareJson(
    Map<String, dynamic> json,
    String fileName,
  ) async {
    final directory = await getTemporaryDirectory();
    final file = File('${directory.path}/$fileName');
    const encoder = JsonEncoder.withIndent('  ');
    await file.writeAsString(encoder.convert(json));
    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/json')],
      text: 'Arquivo RPG Sheet: $fileName',
    );
  }

  static Future<void> exportSystem(RpgSystem system) => _shareJson(
        _envelope(type: 'system', data: system.toJson()),
        _safeName('${system.name}.rpg'),
      );

  static Future<void> exportCharacter(
    Character character,
    RpgSystem system,
  ) => _shareJson(
        _envelope(
          type: 'character',
          data: {
            'character': character.toJson(),
            'system': system.toJson(),
          },
        ),
        _safeName('${character.name}.rpg'),
      );

  static Future<void> exportBackup(AppState state) => _shareJson(
        _envelope(
          type: 'backup',
          data: {
            'characters': state.characters.map((e) => e.toJson()).toList(),
            'systems': state.systems.map((e) => e.toJson()).toList(),
            'campaigns': state.campaigns.map((e) => e.toJson()).toList(),
          },
        ),
        'rpg-sheet-backup.rpg',
      );

  static Future<Map<String, dynamic>?> pickAndRead() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['rpg', 'json'],
      withData: true,
    );
    if (result == null || result.files.single.bytes == null) return null;

    final text = utf8.decode(result.files.single.bytes!);
    final decoded = jsonDecode(text);
    if (decoded is! Map) throw const FormatException('Arquivo inválido.');
    return Map<String, dynamic>.from(decoded);
  }

  static Future<String> importInto(AppState state) async {
    final json = await pickAndRead();
    if (json == null) return 'cancelled';

    if (json['format'] != format) {
      throw const FormatException('Este arquivo não pertence ao RPG Sheet.');
    }
    if (json['formatVersion'] != formatVersion) {
      throw const FormatException('Versão do arquivo não suportada.');
    }

    final type = json['type'];
    final data = Map<String, dynamic>.from(json['data'] ?? {});

    switch (type) {
      case 'system':
        final original = RpgSystem.fromJson(data);
        final imported = RpgSystem(
          id: _uuid.v4(),
          name: _uniqueSystemName(state, original.name),
          description: original.description,
          attributes: List<String>.from(original.attributes),
          skills: List<String>.from(original.skills),
          resources: List<String>.from(original.resources),
          sections: List<String>.from(original.sections),
        );
        await state.addSystem(imported);
        return 'system';

      case 'character':
        final originalSystem = RpgSystem.fromJson(
          Map<String, dynamic>.from(data['system'] ?? {}),
        );
        final importedSystem = RpgSystem(
          id: _uuid.v4(),
          name: _uniqueSystemName(state, originalSystem.name),
          description: originalSystem.description,
          attributes: List<String>.from(originalSystem.attributes),
          skills: List<String>.from(originalSystem.skills),
          resources: List<String>.from(originalSystem.resources),
          sections: List<String>.from(originalSystem.sections),
        );
        final originalCharacter = Character.fromJson(
          Map<String, dynamic>.from(data['character'] ?? {}),
        );
        final importedCharacter = Character(
          id: _uuid.v4(),
          name: originalCharacter.name,
          player: originalCharacter.player,
          systemId: importedSystem.id,
          className: originalCharacter.className,
          race: originalCharacter.race,
          background: originalCharacter.background,
          history: originalCharacter.history,
          portraitPath: '',
          level: originalCharacter.level,
          hp: originalCharacter.hp,
          maxHp: originalCharacter.maxHp,
          energy: originalCharacter.energy,
          maxEnergy: originalCharacter.maxEnergy,
          attributes: Map<String, int>.from(originalCharacter.attributes),
          resourceValues: Map<String, int>.from(originalCharacter.resourceValues),
          resourceMaxValues: Map<String, int>.from(originalCharacter.resourceMaxValues),
          sectionNotes: Map<String, String>.from(originalCharacter.sectionNotes),
          skills: List<String>.from(originalCharacter.skills),
          abilities: List<String>.from(originalCharacter.abilities),
          inventory: List<String>.from(originalCharacter.inventory),
          equipment: List<String>.from(originalCharacter.equipment),
          generalOrder: List<String>.from(originalCharacter.generalOrder),
        );
        await state.addSystem(importedSystem);
        await state.addImportedCharacter(importedCharacter);
        return 'character';

      case 'backup':
        await state.replaceFromBackup(data);
        return 'backup';

      default:
        throw const FormatException('Tipo de arquivo desconhecido.');
    }
  }

  static String _uniqueSystemName(AppState state, String base) {
    final clean = base.trim().isEmpty ? 'Sistema importado' : base.trim();
    var name = clean;
    var counter = 2;
    while (state.systems.any((s) => s.name.toLowerCase() == name.toLowerCase())) {
      name = '$clean ($counter)';
      counter++;
    }
    return name;
  }

  static String _safeName(String value) {
    final sanitized = value.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_').trim();
    return sanitized.isEmpty ? 'rpg-sheet.rpg' : sanitized;
  }
}
