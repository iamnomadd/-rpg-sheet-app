import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/rpg_system.dart';
import '../../services/app_state.dart';

class DiceScreen extends StatefulWidget {
  const DiceScreen({super.key});

  @override
  State<DiceScreen> createState() => _DiceScreenState();
}

class _DiceScreenState extends State<DiceScreen> {
  int sides = 20;
  int count = 1;
  int modifier = 0;
  String mode = 'normal';
  String? selectedSystemId;
  late TextEditingController expressionController;
  Map<String, dynamic>? lastRoll;

  @override
  void initState() {
    super.initState();
    expressionController = TextEditingController(text: '1d20');
  }

  @override
  void dispose() {
    expressionController.dispose();
    super.dispose();
  }

  List<int> _availableDice(AppState state) {
    if (selectedSystemId == null) return [4, 6, 8, 10, 12, 20, 100];
    RpgSystem? system;
    for (final candidate in state.systems) {
      if (candidate.id == selectedSystemId) {
        system = candidate;
        break;
      }
    }
    return system != null && system.dice.isNotEmpty ? system.dice : [4, 6, 8, 10, 12, 20, 100];
  }

  void _syncExpression() {
    expressionController.text = '${count}d$sides${modifier == 0 ? '' : modifier > 0 ? '+$modifier' : '$modifier'}';
  }

  void _parseExpression() {
    final value = expressionController.text.trim().toLowerCase().replaceAll(' ', '');
    final match = RegExp(r'^(\d*)d(\d+)([+-]\d+)?$').firstMatch(value);
    if (match == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Use uma expressão como 2d6+3.')));
      return;
    }
    final parsedCount = int.tryParse(match.group(1)?.isEmpty == true ? '1' : match.group(1)!) ?? 1;
    final parsedSides = int.tryParse(match.group(2)!) ?? 20;
    final parsedModifier = int.tryParse(match.group(3) ?? '0') ?? 0;
    if (parsedCount < 1 || parsedCount > 100 || parsedSides < 2 || parsedSides > 1000) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Quantidade: 1–100. Faces: 2–1000.')));
      return;
    }
    setState(() {
      count = parsedCount;
      sides = parsedSides;
      modifier = parsedModifier;
    });
    _roll();
  }

  void _roll() {
    final result = context.read<AppState>().rollAdvanced(
      sides: sides,
      count: count,
      modifier: modifier,
      mode: mode,
    );
    setState(() => lastRoll = result);
  }

  String _modeLabel() {
    switch (mode) {
      case 'advantage': return 'Vantagem';
      case 'disadvantage': return 'Desvantagem';
      default: return 'Normal';
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final dice = _availableDice(state);
    if (!dice.contains(sides)) sides = dice.isNotEmpty ? dice.first : 20;

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Dados Avançados')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DropdownButtonFormField<String?>(
              value: selectedSystemId,
              decoration: const InputDecoration(labelText: 'Sistema de RPG', prefixIcon: Icon(Icons.auto_awesome)),
              items: [
                const DropdownMenuItem<String?>(value: null, child: Text('Dados padrão')),
                ...state.systems.map((system) => DropdownMenuItem<String?>(value: system.id, child: Text(system.name))),
              ],
              onChanged: (value) => setState(() => selectedSystemId = value),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  children: [
                    const Text('Último resultado'),
                    const SizedBox(height: 6),
                    Text('${lastRoll?['result'] ?? '—'}', style: Theme.of(context).textTheme.displayLarge),
                    if (lastRoll != null) ...[
                      const SizedBox(height: 4),
                      Text('Rolagens: ${(lastRoll!['rolls'] as List).join(', ')}'),
                      Text('${lastRoll!['expression']} • ${_modeLabel()}'),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            Text('Dado', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: dice.map((d) => ChoiceChip(
                label: Text('d$d'),
                selected: sides == d,
                onSelected: (_) { setState(() { sides = d; count = count.clamp(1, 100); }); _syncExpression(); },
              )).toList(),
            ),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: DropdownButtonFormField<int>(
                value: count.clamp(1, 100) as int,
                decoration: const InputDecoration(labelText: 'Quantidade'),
                items: List.generate(100, (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}'))),
                onChanged: (v) { setState(() => count = v ?? 1); _syncExpression(); },
              )),
              const SizedBox(width: 10),
              Expanded(child: TextFormField(
                initialValue: '0',
                keyboardType: const TextInputType.numberWithOptions(signed: true),
                decoration: const InputDecoration(labelText: 'Modificador'),
                onChanged: (v) => modifier = int.tryParse(v) ?? 0,
              )),
            ]),
            const SizedBox(height: 16),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'normal', label: Text('Normal')),
                ButtonSegment(value: 'advantage', label: Text('Vantagem')),
                ButtonSegment(value: 'disadvantage', label: Text('Desvantagem')),
              ],
              selected: {mode},
              onSelectionChanged: (v) => setState(() => mode = v.first),
            ),
            if (mode != 'normal' && count != 1)
              const Padding(padding: EdgeInsets.only(top: 8), child: Text('Vantagem/desvantagem usa duas rolagens e funciona com quantidade 1.')),
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: _roll, icon: const Icon(Icons.casino), label: const Text('Rolar'))),
              const SizedBox(width: 10),
              OutlinedButton(onPressed: _parseExpression, child: const Text('2d6+3')),
            ]),
            const SizedBox(height: 18),
            Text('Expressão personalizada', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            TextField(
              controller: expressionController,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _parseExpression(),
              decoration: InputDecoration(labelText: 'Ex.: 2d6+3', suffixIcon: IconButton(icon: const Icon(Icons.play_arrow), onPressed: _parseExpression)),
            ),
            const SizedBox(height: 24),
            Row(children: [
              Expanded(child: Text('Histórico', style: Theme.of(context).textTheme.titleLarge)),
              if (state.diceHistory.isNotEmpty) TextButton(onPressed: state.clearDiceHistory, child: const Text('Limpar')),
            ]),
            if (state.diceHistory.isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Text('Nenhuma rolagem registrada.'))
            else
              ...state.diceHistory.take(20).map((entry) => Card(
                child: ListTile(
                  leading: const Icon(Icons.history),
                  title: Text('${entry['expression']} = ${entry['result']}'),
                  subtitle: Text('Rolagens: ${(entry['rolls'] as List).join(', ')}${entry['mode'] == 'normal' ? '' : ' • ${entry['mode'] == 'advantage' ? 'Vantagem' : 'Desvantagem'}'}'),
                ),
              )),
          ],
        ),
      ),
    );
  }
}
