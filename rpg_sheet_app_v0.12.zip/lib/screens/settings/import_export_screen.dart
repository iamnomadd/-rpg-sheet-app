import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/character.dart';
import '../../models/rpg_system.dart';
import '../../services/app_state.dart';
import '../../services/rpg_file_service.dart';

class ImportExportScreen extends StatefulWidget {
  const ImportExportScreen({super.key});

  @override
  State<ImportExportScreen> createState() => _ImportExportScreenState();
}

class _ImportExportScreenState extends State<ImportExportScreen> {
  bool busy = false;

  Future<void> _run(Future<void> Function() action) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      await action();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível concluir: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _import(BuildContext context) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final state = context.read<AppState>();
      final result = await RpgFileService.importInto(state);
      if (!mounted || result == 'cancelled') return;
      final message = switch (result) {
        'system' => 'Sistema importado com sucesso.',
        'character' => 'Ficha e sistema importados com sucesso.',
        'backup' => 'Backup restaurado com sucesso.',
        _ => 'Importação concluída.',
      };
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Arquivo inválido: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _restoreBackup(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Restaurar backup?'),
        content: const Text(
          'A restauração substituirá as fichas, sistemas e campanhas atuais deste dispositivo pelos dados do backup.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Restaurar')),
        ],
      ),
    );
    if (confirm != true || !context.mounted) return;

    await _import(context);
  }

  Future<void> _exportSystem(BuildContext context, RpgSystem system) =>
      _run(() => RpgFileService.exportSystem(system));

  Future<void> _exportCharacter(BuildContext context, Character character) async {
    final state = context.read<AppState>();
    final system = state.systems.firstWhere(
      (s) => s.id == character.systemId,
      orElse: () => state.systems.first,
    );
    await _run(() => RpgFileService.exportCharacter(character, system));
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Importar e exportar')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (busy) const LinearProgressIndicator(),
          const SizedBox(height: 8),
          const Card(
            child: ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('Arquivos .rpg'),
              subtitle: Text('Use este formato para compartilhar sistemas e fichas ou fazer um backup local.'),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: busy ? null : () => _import(context),
            icon: const Icon(Icons.file_open),
            label: const Text('Importar arquivo .rpg'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: busy ? null : () => _restoreBackup(context),
            icon: const Icon(Icons.restore),
            label: const Text('Restaurar backup'),
          ),
          const SizedBox(height: 24),
          Text('Exportar backup', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: busy ? null : () => _run(() => RpgFileService.exportBackup(state)),
            icon: const Icon(Icons.backup),
            label: const Text('Exportar tudo'),
          ),
          const SizedBox(height: 24),
          Text('Exportar sistemas', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ...state.systems.map(
            (system) => Card(
              child: ListTile(
                leading: const Icon(Icons.auto_awesome),
                title: Text(system.name),
                subtitle: Text('${system.attributes.length} atributos • ${system.skills.length} perícias'),
                trailing: IconButton(
                  tooltip: 'Exportar sistema',
                  onPressed: busy ? null : () => _exportSystem(context, system),
                  icon: const Icon(Icons.ios_share),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text('Exportar fichas', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (state.characters.isEmpty)
            const Text('Nenhuma ficha criada.')
          else
            ...state.characters.map(
              (character) => Card(
                child: ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(character.name),
                  subtitle: Text('Nível ${character.level}'),
                  trailing: IconButton(
                    tooltip: 'Exportar ficha',
                    onPressed: busy ? null : () => _exportCharacter(context, character),
                    icon: const Icon(Icons.ios_share),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
