import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/app_state.dart';
import '../../services/rpg_file_service.dart';

class SyncScreen extends StatefulWidget {
  const SyncScreen({super.key});

  @override
  State<SyncScreen> createState() => _SyncScreenState();
}

class _SyncScreenState extends State<SyncScreen> {
  bool busy = false;

  Future<void> _backup() async {
    setState(() => busy = true);
    try {
      await RpgFileService.exportBackup(context.read<AppState>());
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Backup gerado. Guarde o arquivo em um local seguro.')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Conta e sincronização')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: ListTile(
              leading: Icon(Icons.cloud_outlined),
              title: Text('Nuvem ainda não conectada'),
              subtitle: Text(
                'A V0.9 prepara o aplicativo para sincronização. O login e a nuvem real precisam de um serviço de backend antes de serem ativados.',
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Dados deste dispositivo', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  Text('${state.characters.length} fichas'),
                  Text('${state.systems.length} sistemas'),
                  Text('${state.campaigns.length} campanhas'),
                  Text('${state.diceHistory.length} rolagens no histórico'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: busy ? null : _backup,
            icon: const Icon(Icons.cloud_upload_outlined),
            label: const Text('Criar backup para sincronização'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: null,
            icon: const Icon(Icons.login),
            label: const Text('Entrar na conta — requer backend'),
          ),
          const SizedBox(height: 20),
          const Text(
            'Nenhum dado é enviado para a internet nesta versão. Seus dados continuam armazenados localmente até a integração de um serviço de nuvem.',
          ),
        ],
      ),
    );
  }
}
