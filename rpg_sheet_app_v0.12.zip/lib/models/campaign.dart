class Campaign {
  final String id;
  String name;
  String description;
  List<String> characterIds;
  List<String> hiddenCharacterIds;
  List<String> npcs;
  List<String> locations;
  String notes;
  String masterNotes;
  String sessionNotes;
  int sessionRound;
  List<Map<String, dynamic>> initiative;
  List<String> conditions;

  Campaign({
    required this.id,
    required this.name,
    this.description = '',
    List<String>? characterIds,
    List<String>? hiddenCharacterIds,
    List<String>? npcs,
    List<String>? locations,
    this.notes = '',
    this.masterNotes = '',
    this.sessionNotes = '',
    this.sessionRound = 1,
    List<Map<String, dynamic>>? initiative,
    List<String>? conditions,
  })  : characterIds = characterIds ?? [],
        hiddenCharacterIds = hiddenCharacterIds ?? [],
        npcs = npcs ?? [],
        locations = locations ?? [],
        initiative = initiative ?? [],
        conditions = conditions ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'characterIds': characterIds,
        'hiddenCharacterIds': hiddenCharacterIds,
        'npcs': npcs,
        'locations': locations,
        'notes': notes,
        'masterNotes': masterNotes,
        'sessionNotes': sessionNotes,
        'sessionRound': sessionRound,
        'initiative': initiative,
        'conditions': conditions,
      };

  factory Campaign.fromJson(Map<String, dynamic> json) => Campaign(
        id: json['id'] ?? '',
        name: json['name'] ?? 'Campanha',
        description: json['description'] ?? '',
        characterIds: List<String>.from(json['characterIds'] ?? []),
        hiddenCharacterIds: List<String>.from(json['hiddenCharacterIds'] ?? []),
        npcs: List<String>.from(json['npcs'] ?? []),
        locations: List<String>.from(json['locations'] ?? []),
        notes: json['notes'] ?? '',
        masterNotes: json['masterNotes'] ?? '',
        sessionNotes: json['sessionNotes'] ?? '',
        sessionRound: json['sessionRound'] ?? 1,
        initiative: (json['initiative'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e))
            .toList(),
        conditions: List<String>.from(json['conditions'] ?? []),
      );
}
