import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/app_state.dart';
import '../../services/cloud_service.dart';
import '../../services/rpg_file_service.dart';

class SyncScreen extends StatefulWidget {
  const SyncScreen({super.key});

  @override
  State<SyncScreen> createState() => _SyncScreenState();
}

class _SyncScreenState extends State<SyncScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false;
  CloudSession? session;

  @override
  void initState() {
    super.initState();
    _loadSession();
  }

  Future<void> _loadSession() async {
    final loaded = await CloudService.loadSession();
    if (!mounted) return;
    setState(() => session = loaded);
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  void _message(String value) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  Future<void> _run(Future<void> Function() action) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      await action();
    } catch (e) {
      _message(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _signIn() => _run(() async {
        final result = await CloudService.signIn(email.text, password.text);
        setState(() => session = result);
        password.clear();
        await context.read<AppState>().syncNow(silent: true);
        _message('Conta conectada e sincronização iniciada.');
      });

  Future<void> _signUp() => _run(() async {
        final result = await CloudService.signUp(email.text, password.text);
        if (result == null) {
          _message('Conta criada. Confirme o e-mail e depois faça login.');
        } else {
          setState(() => session = result);
          await context.read<AppState>().syncNow(silent: true);
          _message('Conta criada e sincronização iniciada.');
        }
        password.clear();
      });

  Future<void> _upload() => _run(() async {
        final current = session;
        if (current == null) return;
        await CloudService.uploadBackup(current, context.read<AppState>().cloudPayload());
        _message('Dados enviados para a nuvem.');
      });

  Future<void> _download() => _run(() async {
        final current = session;
        if (current == null) return;
        final data = await CloudService.downloadBackup(current);
        if (data == null) {
          _message('Nenhum backup encontrado na nuvem.');
          return;
        }
        if (!mounted) return;
        final confirm = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Restaurar da nuvem?'),
            content: const Text('Os dados locais de fichas, sistemas, campanhas, rolagens e preferências serão substituídos pelo backup da conta.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Restaurar')),
            ],
          ),
        );
        if (confirm != true || !mounted) return;
        await context.read<AppState>().replaceFromBackup(data);
        _message('Dados restaurados da nuvem.');
      });

  Future<void> _syncNow() => _run(() async {
        final result = await context.read<AppState>().syncNow();
        _message(result);
      });

  Future<void> _backupFile() => _run(() async {
        await RpgFileService.exportBackup(context.read<AppState>());
        _message('Backup local gerado.');
      });

  Future<void> _signOut() => _run(() async {
        await CloudService.signOut();
        setState(() => session = null);
        _message('Conta desconectada deste aparelho.');
      });

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final connected = session != null;
    return Scaffold(
      appBar: AppBar(title: const Text('Conta e nuvem')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: Icon(CloudService.configured ? Icons.cloud_done_outlined : Icons.cloud_off_outlined),
              title: Text(CloudService.configured ? (connected ? 'Nuvem conectada' : 'Nuvem disponível') : 'Nuvem aguardando configuração'),
              subtitle: Text(
                !CloudService.configured
                    ? 'A conexão com a nuvem não está configurada neste APK.'
                    : connected
                        ? 'Conectado como ${session!.email}'
                        : 'Entre ou crie uma conta para salvar seus dados na nuvem.',
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (!connected) ...[
            TextField(
              controller: email,
              keyboardType: TextInputType.emailAddress,
              enabled: !busy && CloudService.configured,
              decoration: const InputDecoration(labelText: 'E-mail', prefixIcon: Icon(Icons.email_outlined)),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: password,
              obscureText: true,
              enabled: !busy && CloudService.configured,
              decoration: const InputDecoration(labelText: 'Senha', prefixIcon: Icon(Icons.lock_outline)),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: busy || !CloudService.configured ? null : _signIn, icon: const Icon(Icons.login), label: const Text('Entrar'))),
              const SizedBox(width: 10),
              Expanded(child: OutlinedButton.icon(onPressed: busy || !CloudService.configured ? null : _signUp, icon: const Icon(Icons.person_add_alt_1), label: const Text('Criar conta'))),
            ]),
          ] else ...[
            FilledButton.icon(onPressed: busy ? null : _syncNow, icon: const Icon(Icons.sync), label: const Text('Sincronizar agora')),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: state.autoSync,
              onChanged: busy ? null : state.setAutoSync,
              title: const Text('Sincronização automática'),
              subtitle: Text(state.syncStatus),
              secondary: const Icon(Icons.devices_outlined),
            ),
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: const Text('Opções manuais'),
              children: [
                ListTile(leading: const Icon(Icons.cloud_upload_outlined), title: const Text('Forçar envio deste aparelho'), onTap: busy ? null : _upload),
                ListTile(leading: const Icon(Icons.cloud_download_outlined), title: const Text('Restaurar cópia da nuvem'), onTap: busy ? null : _download),
              ],
            ),
            TextButton.icon(onPressed: busy ? null : _signOut, icon: const Icon(Icons.logout), label: const Text('Desconectar conta')),
          ],
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Dados deste aparelho', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 10),
                Text('${state.characters.length} fichas • ${state.systems.length} sistemas'),
                Text('${state.campaigns.length} campanhas • ${state.savedRolls.length} rolagens favoritas'),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: busy ? null : _backupFile, icon: const Icon(Icons.save_alt), label: const Text('Gerar backup local .rpg')),
          const SizedBox(height: 14),
          Text(state.lastSyncUtc == null ? 'Ainda não houve sincronização neste aparelho.' : 'Última sincronização: ${state.lastSyncUtc!.toLocal()}'),
          const SizedBox(height: 6),
          const Text('A sincronização automática compara a versão local e a versão da nuvem. As opções manuais continuam disponíveis como recuperação.'),
        ],
      ),
    );
  }
}
