# RPG Sheet App — V0.3

Aplicativo Flutter para criação e gerenciamento de fichas de RPG.

## V0.3 — Construtor de sistemas
- Criar sistemas personalizados.
- Editar nome e descrição.
- Definir atributos.
- Definir perícias.
- Definir recursos (Vida, Mana, Sanidade etc.).
- Definir seções da ficha.
- Persistência local.
- Compatibilidade com sistemas criados nas versões anteriores.

## Próxima etapa
A V0.4 usará a definição do sistema para gerar a ficha do personagem dinamicamente.

## Tecnologias
- Flutter / Dart
- Provider
- SharedPreferences
- UUID
- Image Picker
