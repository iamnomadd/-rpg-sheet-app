import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../models/character.dart';
import '../../services/app_state.dart';

class CharacterScreen extends StatefulWidget {
  final String characterId;

  const CharacterScreen({super.key, required this.characterId});

  @override
  State<CharacterScreen> createState() => _CharacterScreenState();
}

class _CharacterScreenState extends State<CharacterScreen> {
  int tab = 0;

  Character? get character {
    final state = context.read<AppState>();
    for (final c in state.characters) {
      if (c.id == widget.characterId) return c;
    }
    return null;
  }

  Future<void> _editBasic() async {
    final c = character;
    if (c == null) return;

    final name = TextEditingController(text: c.name);
    final player = TextEditingController(text: c.player);
    final className = TextEditingController(text: c.className);
    final race = TextEditingController(text: c.race);
    final background = TextEditingController(text: c.background);
    final level = TextEditingController(text: c.level.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Dados do personagem'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
              const SizedBox(height: 10),
              TextField(controller: player, decoration: const InputDecoration(labelText: 'Jogador')),
              const SizedBox(height: 10),
              TextField(controller: className, decoration: const InputDecoration(labelText: 'Classe')),
              const SizedBox(height: 10),
              TextField(controller: race, decoration: const InputDecoration(labelText: 'Raça')),
              const SizedBox(height: 10),
              TextField(controller: background, decoration: const InputDecoration(labelText: 'Antecedente')),
              const SizedBox(height: 10),
              TextField(
                controller: level,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Nível'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      c.name = name.text.trim().isEmpty ? c.name : name.text.trim();
      c.player = player.text.trim();
      c.className = className.text.trim();
      c.race = race.text.trim();
      c.background = background.text.trim();
      c.level = (int.tryParse(level.text) ?? c.level).clamp(1, 999);
      await context.read<AppState>().updateCharacter(c);
      setState(() {});
    }

    name.dispose();
    player.dispose();
    className.dispose();
    race.dispose();
    background.dispose();
    level.dispose();
  }

  Future<void> _pickPortrait() async {
    final c = character;
    if (c == null) return;
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 1000);
    if (image == null) return;
    c.portraitPath = image.path;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editResources() async {
    final c = character;
    if (c == null) return;
    final hp = TextEditingController(text: c.hp.toString());
    final maxHp = TextEditingController(text: c.maxHp.toString());
    final energy = TextEditingController(text: c.energy.toString());
    final maxEnergy = TextEditingController(text: c.maxEnergy.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Recursos'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              _numberField(hp, 'Vida atual'),
              const SizedBox(height: 10),
              _numberField(maxHp, 'Vida máxima'),
              const SizedBox(height: 10),
              _numberField(energy, 'Energia atual'),
              const SizedBox(height: 10),
              _numberField(maxEnergy, 'Energia máxima'),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      c.maxHp = (int.tryParse(maxHp.text) ?? c.maxHp).clamp(0, 999999);
      c.hp = (int.tryParse(hp.text) ?? c.hp).clamp(0, c.maxHp);
      c.maxEnergy = (int.tryParse(maxEnergy.text) ?? c.maxEnergy).clamp(0, 999999);
      c.energy = (int.tryParse(energy.text) ?? c.energy).clamp(0, c.maxEnergy);
      await context.read<AppState>().updateCharacter(c);
      setState(() {});
    }

    hp.dispose();
    maxHp.dispose();
    energy.dispose();
    maxEnergy.dispose();
  }

  TextField _numberField(TextEditingController controller, String label) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(labelText: label),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    Character? c;

    for (final item in state.characters) {
      if (item.id == widget.characterId) {
        c = item;
        break;
      }
    }

    if (c == null) {
      return const Scaffold(body: Center(child: Text('Ficha não encontrada.')));
    }

    final character = c;

    return Scaffold(
      appBar: AppBar(
        title: Text(character.name),
        actions: [
          IconButton(onPressed: _editBasic, icon: const Icon(Icons.edit), tooltip: 'Editar dados'),
        ],
      ),
      body: Column(
        children: [
          _Header(character: character, onPickPortrait: _pickPortrait),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _editResources,
                    icon: const Icon(Icons.favorite_border),
                    label: const Text('Editar recursos'),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (value) => setState(() => tab = value),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Atributos'),
              NavigationDestination(icon: Icon(Icons.psychology), label: 'Perícias'),
              NavigationDestination(icon: Icon(Icons.backpack), label: 'Inventário'),
              NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Habilidades'),
              NavigationDestination(icon: Icon(Icons.menu_book), label: 'História'),
            ],
          ),
          Expanded(
            child: IndexedStack(
              index: tab,
              children: [
                _AttributesTab(character: character, onResources: _editResources),
                _ListTab(
                  title: 'Perícias',
                  items: character.skills,
                  empty: 'Nenhuma perícia adicionada.',
                  icon: Icons.psychology,
                  hint: 'Nome da perícia',
                  onAdd: (value) async {
                    character.skills.add(value);
                    await state.updateCharacter(character);
                    setState(() {});
                  },
                  onDelete: (index) async {
                    character.skills.removeAt(index);
                    await state.updateCharacter(character);
                    setState(() {});
                  },
                ),
                _ListTab(
                  title: 'Inventário',
                  items: character.inventory,
                  empty: 'Nenhum item adicionado.',
                  icon: Icons.backpack,
                  hint: 'Nome do item',
                  onAdd: (value) async {
                    character.inventory.add(value);
                    await state.updateCharacter(character);
                    setState(() {});
                  },
                  onDelete: (index) async {
                    character.inventory.removeAt(index);
                    await state.updateCharacter(character);
                    setState(() {});
                  },
                ),
                _ListTab(
                  title: 'Habilidades',
                  items: character.abilities,
                  empty: 'Nenhuma habilidade adicionada.',
                  icon: Icons.auto_awesome,
                  hint: 'Nome da habilidade',
                  onAdd: (value) async {
                    character.abilities.add(value);
                    await state.updateCharacter(character);
                    setState(() {});
                  },
                  onDelete: (index) async {
                    character.abilities.removeAt(index);
                    await state.updateCharacter(character);
                    setState(() {});
                  },
                ),
                _HistoryTab(character: character),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final Character character;
  final VoidCallback onPickPortrait;

  const _Header({required this.character, required this.onPickPortrait});

  @override
  Widget build(BuildContext context) {
    final hasPortrait = character.portraitPath.isNotEmpty && File(character.portraitPath).existsSync();

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: onPickPortrait,
            child: Stack(
              children: [
                CircleAvatar(
                  radius: 38,
                  backgroundImage: hasPortrait ? FileImage(File(character.portraitPath)) : null,
                  child: hasPortrait
                      ? null
                      : Text(
                          character.name.isEmpty ? '?' : character.name[0].toUpperCase(),
                          style: const TextStyle(fontSize: 28),
                        ),
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: CircleAvatar(
                    radius: 13,
                    child: Icon(Icons.camera_alt, size: 14),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(character.name, style: Theme.of(context).textTheme.titleLarge),
                Text(
                  '${character.race.isEmpty ? 'Sem raça' : character.race} • '
                  '${character.className.isEmpty ? 'Sem classe' : character.className} • Nível ${character.level}',
                ),
                if (character.player.isNotEmpty)
                  Text('Jogador: ${character.player}', style: Theme.of(context).textTheme.bodySmall),
                if (character.background.isNotEmpty)
                  Text('Antecedente: ${character.background}', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AttributesTab extends StatelessWidget {
  final Character character;
  final VoidCallback onResources;

  const _AttributesTab({required this.character, required this.onResources});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _ResourceCard(
          title: 'Vida',
          value: character.hp,
          max: character.maxHp,
          icon: Icons.favorite,
          onMinus: () async {
            character.hp = (character.hp - 1).clamp(0, character.maxHp);
            await state.updateCharacter(character);
          },
          onPlus: () async {
            character.hp = (character.hp + 1).clamp(0, character.maxHp);
            await state.updateCharacter(character);
          },
        ),
        const SizedBox(height: 10),
        _ResourceCard(
          title: 'Energia',
          value: character.energy,
          max: character.maxEnergy,
          icon: Icons.bolt,
          onMinus: () async {
            character.energy = (character.energy - 1).clamp(0, character.maxEnergy);
            await state.updateCharacter(character);
          },
          onPlus: () async {
            character.energy = (character.energy + 1).clamp(0, character.maxEnergy);
            await state.updateCharacter(character);
          },
        ),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton.icon(
            onPressed: onResources,
            icon: const Icon(Icons.tune),
            label: const Text('Configurar recursos'),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Text('Atributos', style: Theme.of(context).textTheme.titleLarge),
            const Spacer(),
            const Text('Toque +1 • segure -1'),
          ],
        ),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: character.attributes.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 1.8,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemBuilder: (_, index) {
            final key = character.attributes.keys.elementAt(index);
            final value = character.attributes[key]!;
            return Card(
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () async {
                  character.attributes[key] = value + 1;
                  await state.updateCharacter(character);
                },
                onLongPress: () async {
                  character.attributes[key] = value - 1;
                  await state.updateCharacter(character);
                },
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(key, style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text('$value', style: Theme.of(context).textTheme.headlineSmall),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class _ResourceCard extends StatelessWidget {
  final String title;
  final int value;
  final int max;
  final IconData icon;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  const _ResourceCard({
    required this.title,
    required this.value,
    required this.max,
    required this.icon,
    required this.onMinus,
    required this.onPlus,
  });

  @override
  Widget build(BuildContext context) {
    final progress = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Row(
              children: [
                Icon(icon),
                const SizedBox(width: 8),
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                IconButton(onPressed: onMinus, icon: const Icon(Icons.remove)),
                Text('$value / $max'),
                IconButton(onPressed: onPlus, icon: const Icon(Icons.add)),
              ],
            ),
            LinearProgressIndicator(value: progress),
          ],
        ),
      ),
    );
  }
}

class _ListTab extends StatelessWidget {
  final String title;
  final List<String> items;
  final String empty;
  final IconData icon;
  final String hint;
  final Future<void> Function(String) onAdd;
  final Future<void> Function(int) onDelete;

  const _ListTab({
    required this.title,
    required this.items,
    required this.empty,
    required this.icon,
    required this.hint,
    required this.onAdd,
    required this.onDelete,
  });

  Future<void> _add(BuildContext context) async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Adicionar em $title'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(labelText: hint),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Adicionar')),
        ],
      ),
    );
    controller.dispose();
    if (value != null && value.isNotEmpty) await onAdd(value);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const Spacer(),
            IconButton(onPressed: () => _add(context), icon: const Icon(Icons.add_circle)),
          ],
        ),
        const SizedBox(height: 8),
        if (items.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Center(child: Text(empty)),
          )
        else
          ...items.asMap().entries.map(
            (entry) => Card(
              child: ListTile(
                leading: Icon(icon),
                title: Text(entry.value),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => onDelete(entry.key),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _HistoryTab extends StatefulWidget {
  final Character character;

  const _HistoryTab({required this.character});

  @override
  State<_HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<_HistoryTab> {
  late final TextEditingController controller;

  @override
  void initState() {
    super.initState();
    controller = TextEditingController(text: widget.character.history);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Expanded(
            child: TextField(
              controller: controller,
              expands: true,
              maxLines: null,
              textAlignVertical: TextAlignVertical.top,
              decoration: const InputDecoration(
                hintText: 'Escreva a história, personalidade, objetivos e anotações...',
              ),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () async {
              widget.character.history = controller.text;
              await state.updateCharacter(widget.character);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('História salva.')),
                );
              }
            },
            icon: const Icon(Icons.save),
            label: const Text('Salvar história'),
          ),
        ],
      ),
    );
  }
}
