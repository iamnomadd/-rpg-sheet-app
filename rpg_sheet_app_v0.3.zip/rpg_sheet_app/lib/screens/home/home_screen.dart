import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/app_state.dart';
import '../../models/character.dart';
import '../character/character_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> _newCharacter(BuildContext context) async {
    final controller = TextEditingController();

    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Nova ficha'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Nome do personagem'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Criar'),
          ),
        ],
      ),
    );

    if (name == null || name.isEmpty || !context.mounted) return;

    final character = await context.read<AppState>().addCharacter(name: name);

    if (!context.mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => CharacterScreen(characterId: character.id)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Minhas Fichas'),
          actions: [
            IconButton(
              tooltip: 'Nova ficha',
              onPressed: () => _newCharacter(context),
              icon: const Icon(Icons.add),
            ),
          ],
        ),
        body: !state.loaded
            ? const Center(child: CircularProgressIndicator())
            : state.characters.isEmpty
                ? _EmptyState(onCreate: () => _newCharacter(context))
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: state.characters.length,
                    itemBuilder: (_, index) {
                      final character = state.characters[index];
                      return _CharacterCard(character: character);
                    },
                  ),
        floatingActionButton: state.characters.isEmpty
            ? null
            : FloatingActionButton.extended(
                onPressed: () => _newCharacter(context),
                icon: const Icon(Icons.person_add),
                label: const Text('Nova ficha'),
              ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final VoidCallback onCreate;

  const _EmptyState({required this.onCreate});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.auto_awesome, size: 72),
            const SizedBox(height: 18),
            Text(
              'Sua aventura começa aqui',
              style: Theme.of(context).textTheme.headlineSmall,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            const Text(
              'Crie sua primeira ficha e organize personagens, atributos, inventário e habilidades.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: onCreate,
              icon: const Icon(Icons.add),
              label: const Text('Criar primeira ficha'),
            ),
          ],
        ),
      ),
    );
  }
}

class _CharacterCard extends StatelessWidget {
  final Character character;

  const _CharacterCard({required this.character});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    final system = state.systems.firstWhere(
      (s) => s.id == character.systemId,
      orElse: () => state.systems.first,
    );

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.all(14),
        leading: CircleAvatar(
          radius: 27,
          child: Text(character.name.isEmpty ? '?' : character.name[0].toUpperCase()),
        ),
        title: Text(
          character.name,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${character.className.isEmpty ? 'Sem classe' : character.className} • ${system.name}\n'
          'Nível ${character.level} • HP ${character.hp}/${character.maxHp}',
        ),
        isThreeLine: true,
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CharacterScreen(characterId: character.id),
            ),
          );
        },
        onLongPress: () => _confirmDelete(context, character),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, Character character) async {
    final delete = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Excluir ficha?'),
        content: Text('A ficha de ${character.name} será removida deste dispositivo.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (delete == true && context.mounted) {
      await context.read<AppState>().deleteCharacter(character.id);
    }
  }
}
