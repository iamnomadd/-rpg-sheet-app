# RPG Sheet App — V0.9

## V0.9 — Preparação para conta e sincronização
- Nova central de Conta e Sincronização.
- Resumo dos dados locais: fichas, sistemas, campanhas e histórico de dados.
- Atalho para gerar backup completo antes da futura sincronização.
- Interface preparada para login e nuvem, sem fingir que existe um backend conectado.
- Nenhum dado é enviado à internet nesta versão.
- Mantém todas as funções da V0.8.

### Importante
A sincronização real entre aparelhos exige configurar um backend (por exemplo, Supabase ou Firebase). A V0.9 deixa a base de interface pronta, mas não ativa um serviço externo sem configuração/credenciais.

Versão do projeto: 0.9.0+12
