const CACHE='rpg-sheet-v1.2.1-fix1';
const CORE=['/','/index.html','/manifest.json','/icons/Icon-192.png','/icons/Icon-512.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;
 event.respondWith(fetch(event.request).then(response=>{
   if(response && response.status===200 && new URL(event.request.url).origin===self.location.origin){
     const copy=response.clone();caches.open(CACHE).then(c=>c.put(event.request,copy));
   }
   return response;
 }).catch(()=>caches.match(event.request).then(r=>r||caches.match('/index.html'))));
});
