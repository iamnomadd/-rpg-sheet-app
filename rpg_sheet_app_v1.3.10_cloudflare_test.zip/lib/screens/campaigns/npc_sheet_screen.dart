import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/condition_presets.dart';
import '../../models/campaign.dart';
import '../../models/character.dart';
import '../../services/app_state.dart';

class NpcSheetScreen extends StatefulWidget {
  final String campaignId;
  final String npcId;
  const NpcSheetScreen({super.key, required this.campaignId, required this.npcId});

  @override
  State<NpcSheetScreen> createState() => _NpcSheetScreenState();
}

class _NpcSheetScreenState extends State<NpcSheetScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 6, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Campaign? _campaign(AppState state) {
    final matches = state.campaigns.where((c) => c.id == widget.campaignId);
    return matches.isEmpty ? null : matches.first;
  }

  Map<String, dynamic>? _npc(Campaign c) {
    final matches = c.npcSheets.where((n) => '${n['id']}' == widget.npcId);
    return matches.isEmpty ? null : matches.first;
  }

  Character? _sheet(Map<String, dynamic> npc) {
    final raw = npc['sheet'];
    if (raw is! Map) return null;
    return Character.fromJson(Map<String, dynamic>.from(raw));
  }

  Future<void> _save(Campaign campaign, Map<String, dynamic> npc, Character sheet) async {
    npc['name'] = sheet.name;
    npc['sheet'] = sheet.toJson();
    await context.read<AppState>().updateCampaign(campaign);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final campaign = _campaign(state);
    if (campaign == null) return const Scaffold(body: Center(child: Text('Campanha não encontrada.')));
    final npc = _npc(campaign);
    if (npc == null) return const Scaffold(body: Center(child: Text('NPC não encontrado.')));
    final sheet = _sheet(npc);
    if (sheet == null) return const Scaffold(body: Center(child: Text('Ficha do NPC inválida.')));
    final kind = '${npc['kind'] ?? 'NPC'}';

    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(sheet.name),
          Text(kind, style: Theme.of(context).textTheme.labelSmall),
        ]),
        bottom: TabBar(
          controller: _tabs,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          tabs: const [
            Tab(icon: Icon(Icons.dashboard_outlined), text: 'Resumo'),
            Tab(icon: Icon(Icons.favorite_outline), text: 'Status'),
            Tab(icon: Icon(Icons.sports_martial_arts_outlined), text: 'Ações'),
            Tab(icon: Icon(Icons.auto_awesome_outlined), text: 'Habilidades'),
            Tab(icon: Icon(Icons.inventory_2_outlined), text: 'Inventário'),
            Tab(icon: Icon(Icons.notes_outlined), text: 'Notas'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          _summary(campaign, npc, sheet),
          _status(campaign, npc, sheet),
          _actions(campaign, npc, sheet),
          _stringList(campaign, npc, sheet, title: 'Habilidades', items: sheet.abilities, descriptions: sheet.abilityDescriptions),
          _stringList(campaign, npc, sheet, title: 'Inventário', items: sheet.inventory, descriptions: sheet.inventoryDescriptions),
          _notes(campaign, npc, sheet),
        ],
      ),
    );
  }

  Widget _summary(Campaign campaign, Map<String, dynamic> npc, Character sheet) {
    final hp = sheet.resourceValues['Vida'] ?? sheet.hp;
    final maxHp = sheet.resourceMaxValues['Vida'] ?? sheet.maxHp;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(radius: 26, child: Icon(_kindIcon('${npc['kind'] ?? 'NPC'}'))),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(sheet.name, style: Theme.of(context).textTheme.titleLarge),
            Text('${npc['kind'] ?? 'NPC'} • ${sheet.systemId}'),
          ])),
          IconButton(onPressed: () => _editIdentity(campaign, npc, sheet), icon: const Icon(Icons.edit_outlined)),
        ]),
        const SizedBox(height: 16),
        LinearProgressIndicator(value: maxHp <= 0 ? 0.0 : (hp / maxHp).clamp(0, 1).toDouble()),
        const SizedBox(height: 6),
        Text('Vida $hp / $maxHp'),
      ]))),
      const SizedBox(height: 12),
      Text('Atributos', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      Wrap(spacing: 8, runSpacing: 8, children: sheet.attributes.entries.map((e) => ActionChip(
        label: Text('${e.key} ${e.value}'),
        onPressed: () => _editAttribute(campaign, npc, sheet, e.key),
      )).toList()),
      const SizedBox(height: 16),
      Text('Recursos', style: Theme.of(context).textTheme.titleMedium),
      ...sheet.resourceValues.entries.map((e) => Card(child: ListTile(
        title: Text(e.key),
        subtitle: LinearProgressIndicator(value: (sheet.resourceMaxValues[e.key] ?? e.value) <= 0 ? 0.0 : (e.value / (sheet.resourceMaxValues[e.key] ?? e.value)).clamp(0, 1).toDouble()),
        trailing: Text('${e.value}/${sheet.resourceMaxValues[e.key] ?? e.value}'),
        onTap: () => _editResource(campaign, npc, sheet, e.key),
      ))),
    ]);
  }

  Widget _status(Campaign campaign, Map<String, dynamic> npc, Character sheet) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Text('Condições ativas', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      if (sheet.conditions.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Nenhuma condição ativa.'))),
      Wrap(spacing: 8, runSpacing: 8, children: sheet.conditions.map((c) => InputChip(
        label: Text(c),
        onDeleted: () async { sheet.conditions.remove(c); await _save(campaign, npc, sheet); },
      )).toList()),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: () => _chooseCondition(campaign, npc, sheet), icon: const Icon(Icons.add), label: const Text('Adicionar condição')),
    ],
  );

  Widget _actions(Campaign campaign, Map<String, dynamic> npc, Character sheet) {
    final weaponNames = sheet.inventory.where((name) => (sheet.inventoryDetails[name]?['damage']?.toString().trim().isNotEmpty ?? false)).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [Expanded(child: Text('Ataques', style: Theme.of(context).textTheme.titleMedium)), IconButton(onPressed: () => _addAction(campaign, npc, sheet, weapon: true), icon: const Icon(Icons.add))]),
      if (weaponNames.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Nenhum ataque cadastrado.'))),
      ...weaponNames.map((name) { final d = sheet.inventoryDetails[name] ?? {}; return Card(child: ListTile(
        leading: const Icon(Icons.gps_fixed),
        title: Text(name),
        subtitle: Text('Dano ${d['damage'] ?? '—'}${d['ammo'] != null ? ' • Munição ${d['ammo']}' : ''}'),
        trailing: const Icon(Icons.edit_outlined),
        onTap: () => _editAction(campaign, npc, sheet, name, weapon: true),
      )); }),
      const SizedBox(height: 14),
      Row(children: [Expanded(child: Text('Poderes / Magias', style: Theme.of(context).textTheme.titleMedium)), IconButton(onPressed: () => _addAction(campaign, npc, sheet, weapon: false), icon: const Icon(Icons.add))]),
      if (sheet.abilities.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Nenhuma habilidade cadastrada.'))),
      ...sheet.abilities.map((name) { final d = sheet.abilityDetails[name] ?? {}; return Card(child: ListTile(
        leading: const Icon(Icons.auto_awesome),
        title: Text(name),
        subtitle: Text([if ((d['damage'] ?? '').toString().isNotEmpty) 'Dano ${d['damage']}', if ((sheet.abilityDescriptions[name] ?? '').isNotEmpty) sheet.abilityDescriptions[name]!].join(' • ')),
        trailing: const Icon(Icons.edit_outlined),
        onTap: () => _editAction(campaign, npc, sheet, name, weapon: false),
      )); }),
    ]);
  }

  Widget _stringList(Campaign campaign, Map<String, dynamic> npc, Character sheet, {required String title, required List<String> items, required Map<String,String> descriptions}) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Row(children: [Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium)), IconButton(onPressed: () => _addSimpleItem(campaign, npc, sheet, title, items, descriptions), icon: const Icon(Icons.add))]),
      if (items.isEmpty) Card(child: Padding(padding: const EdgeInsets.all(16), child: Text('Nenhum item em $title.'))),
      ...items.map((name) => Card(child: ListTile(
        title: Text(name),
        subtitle: (descriptions[name] ?? '').isEmpty ? null : Text(descriptions[name]!),
        trailing: PopupMenuButton<String>(itemBuilder: (_) => const [PopupMenuItem(value:'edit',child:Text('Editar')),PopupMenuItem(value:'delete',child:Text('Excluir'))], onSelected: (v) async {
          if (v == 'delete') { items.remove(name); descriptions.remove(name); await _save(campaign, npc, sheet); }
          else { await _editSimpleItem(campaign, npc, sheet, name, items, descriptions); }
        }),
      ))),
    ],
  );

  Widget _notes(Campaign campaign, Map<String, dynamic> npc, Character sheet) {
    final ctrl = TextEditingController(text: sheet.sectionNotes['npcNotes'] ?? '');
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Notas privadas do Mestre', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      TextField(controller: ctrl, minLines: 10, maxLines: 18, decoration: const InputDecoration(hintText: 'Táticas, personalidade, segredos, comportamento em combate...')),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: () async { sheet.sectionNotes['npcNotes'] = ctrl.text; await _save(campaign, npc, sheet); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notas salvas.'))); }, icon: const Icon(Icons.save_outlined), label: const Text('Salvar notas')),
    ]);
  }

  IconData _kindIcon(String kind) => switch (kind) { 'Monstro' => Icons.bug_report_outlined, 'Chefe' => Icons.workspace_premium_outlined, 'Aliado' => Icons.shield_outlined, _ => Icons.person_outline };

  Future<void> _editIdentity(Campaign campaign, Map<String,dynamic> npc, Character sheet) async {
    final name = TextEditingController(text: sheet.name);
    String kind='${npc['kind'] ?? 'NPC'}';
    final ok=await showDialog<bool>(context:context,builder:(d)=>StatefulBuilder(builder:(context,setD)=>AlertDialog(title:const Text('Identidade'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Nome')),const SizedBox(height:10),DropdownButtonFormField<String>(value:kind,items:const ['NPC','Monstro','Aliado','Chefe'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setD(()=>kind=v??kind))]),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Salvar'))])));
    if(ok==true && name.text.trim().isNotEmpty){ sheet.name=name.text.trim(); npc['kind']=kind; await _save(campaign,npc,sheet); }
  }

  Future<void> _editAttribute(Campaign campaign, Map<String,dynamic> npc, Character sheet, String key) async {
    final c=TextEditingController(text:'${sheet.attributes[key] ?? 0}');
    final v=await showDialog<int>(context:context,builder:(d)=>AlertDialog(title:Text('Atributo $key'),content:TextField(controller:c,keyboardType:TextInputType.number,autofocus:true),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(d,int.tryParse(c.text.trim())),child:const Text('Salvar'))]));
    if(v!=null){sheet.attributes[key]=v;await _save(campaign,npc,sheet);}
  }

  Future<void> _editResource(Campaign campaign, Map<String,dynamic> npc, Character sheet, String key) async {
    final current=sheet.resourceValues[key] ?? 0; final max=sheet.resourceMaxValues[key] ?? current;
    final result=await showModalBottomSheet<Map<String,int>>(context:context,isScrollControlled:true,builder:(d){ final cur=TextEditingController(text:'$current'); final mx=TextEditingController(text:'$max'); final amount=TextEditingController(); return Padding(padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(d).viewInsets.bottom+24),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text('Configurar $key',style:Theme.of(d).textTheme.headlineSmall),const SizedBox(height:14),TextField(controller:cur,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Valor atual')),TextField(controller:mx,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Valor máximo')),const SizedBox(height:10),TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Dano / cura rápida')),const SizedBox(height:12),Wrap(spacing:8,children:[OutlinedButton.icon(onPressed:(){final a=int.tryParse(amount.text)??0;Navigator.pop(d,{'current':(current-a).clamp(0,max).toInt(),'max':max});},icon:const Icon(Icons.heart_broken_outlined),label:const Text('Receber dano')),OutlinedButton.icon(onPressed:(){final a=int.tryParse(amount.text)??0;Navigator.pop(d,{'current':(current+a).clamp(0,max).toInt(),'max':max});},icon:const Icon(Icons.healing),label:const Text('Curar'))]),const SizedBox(height:12),FilledButton(onPressed:(){final m=(int.tryParse(mx.text)??max).clamp(0,999999).toInt();final v=(int.tryParse(cur.text)??current).clamp(0,m).toInt();Navigator.pop(d,{'current':v,'max':m});},child:const Text('Salvar manualmente'))]));});
    if(result!=null){sheet.resourceValues[key]=result['current']!;sheet.resourceMaxValues[key]=result['max']!;if(key=='Vida'){sheet.hp=result['current']!;sheet.maxHp=result['max']!;}await _save(campaign,npc,sheet);}
  }

  Future<void> _chooseCondition(Campaign campaign, Map<String,dynamic> npc, Character sheet) async {
    final name=await showDialog<String>(context:context,builder:(d)=>SimpleDialog(title:const Text('Adicionar condição'),children:[...conditionPresets.where((p)=>!sheet.conditions.contains(p.name)).map((p)=>SimpleDialogOption(onPressed:()=>Navigator.pop(d,p.name),child:Row(children:[Icon(p.icon),const SizedBox(width:10),Text(p.name)]))),SimpleDialogOption(onPressed:()async{final ctrl=TextEditingController();final x=await showDialog<String>(context:d,builder:(x)=>AlertDialog(title:const Text('Condição personalizada'),content:TextField(controller:ctrl,autofocus:true),actions:[FilledButton(onPressed:()=>Navigator.pop(x,ctrl.text.trim()),child:const Text('Adicionar'))]));if(d.mounted)Navigator.pop(d,x);},child:const Row(children:[Icon(Icons.add),SizedBox(width:10),Text('Personalizada')]))]));
    if(name!=null && name.isNotEmpty && !sheet.conditions.contains(name)){sheet.conditions.add(name);await _save(campaign,npc,sheet);}
  }

  Future<void> _addAction(Campaign campaign, Map<String,dynamic> npc, Character sheet,{required bool weapon}) async => _editAction(campaign,npc,sheet,'',weapon:weapon);
  Future<void> _editAction(Campaign campaign, Map<String,dynamic> npc, Character sheet,String oldName,{required bool weapon}) async {
    final details=weapon ? sheet.inventoryDetails : sheet.abilityDetails; final descriptions=weapon ? sheet.inventoryDescriptions : sheet.abilityDescriptions; final items=weapon ? sheet.inventory : sheet.abilities;
    final raw=details[oldName] ?? <String,dynamic>{}; final name=TextEditingController(text:oldName);final damage=TextEditingController(text:'${raw['damage'] ?? ''}');final desc=TextEditingController(text:descriptions[oldName] ?? '');
    final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(title:Text(oldName.isEmpty?'Nova ação':'Editar ação'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Nome')),TextField(controller:damage,decoration:const InputDecoration(labelText:'Dano (ex.: 1d8+3)')),TextField(controller:desc,minLines:2,maxLines:4,decoration:const InputDecoration(labelText:'Descrição'))]),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Salvar'))]));
    final n=name.text.trim();if(ok!=true||n.isEmpty)return;if(oldName.isNotEmpty&&oldName!=n){items.remove(oldName);details.remove(oldName);descriptions.remove(oldName);}if(!items.contains(n))items.add(n);details[n]={...raw,'damage':damage.text.trim()};descriptions[n]=desc.text.trim();await _save(campaign,npc,sheet);
  }

  Future<void> _addSimpleItem(Campaign campaign, Map<String,dynamic> npc, Character sheet,String title,List<String> items,Map<String,String> descriptions) async => _editSimpleItem(campaign,npc,sheet,'',items,descriptions);
  Future<void> _editSimpleItem(Campaign campaign, Map<String,dynamic> npc, Character sheet,String oldName,List<String> items,Map<String,String> descriptions) async {
    final name=TextEditingController(text:oldName);final desc=TextEditingController(text:descriptions[oldName]??'');final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(title:Text(oldName.isEmpty?'Adicionar':'Editar'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Nome')),TextField(controller:desc,minLines:2,maxLines:4,decoration:const InputDecoration(labelText:'Descrição'))]),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Salvar'))]));final n=name.text.trim();if(ok!=true||n.isEmpty)return;if(oldName.isNotEmpty&&oldName!=n){items.remove(oldName);descriptions.remove(oldName);}if(!items.contains(n))items.add(n);descriptions[n]=desc.text.trim();await _save(campaign,npc,sheet);
  }
}
