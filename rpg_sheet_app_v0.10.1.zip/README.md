# RPG Sheet App — V0.9

## V0.9 — Preparação para conta e sincronização
- Nova central de Conta e Sincronização.
- Resumo dos dados locais: fichas, sistemas, campanhas e histórico de dados.
- Atalho para gerar backup completo antes da futura sincronização.
- Interface preparada para login e nuvem, sem fingir que existe um backend conectado.
- Nenhum dado é enviado à internet nesta versão.
- Mantém todas as funções da V0.8.

### Importante
A sincronização real entre aparelhos exige configurar um backend (por exemplo, Supabase ou Firebase). A V0.9 deixa a base de interface pronta, mas não ativa um serviço externo sem configuração/credenciais.

Versão do projeto: 0.9.0+12


## V0.10.0 — Interface e experiência

- Padronização visual geral em Material 3.
- Cards, campos, botões e navegação com espaçamento e cantos consistentes.
- Melhor leitura em telas pequenas e grandes.
- Estados vazios e confirmações preservados/melhorados.
- Tela de fichas, sistemas, dados, campanhas e configurações revisadas visualmente.
- Aba Geral continua somente leitura e com blocos reordenáveis.
- Criador de sistemas continua sem fórmulas automáticas/atributos derivados.
- Identificação visual da versão: V0.10.0.
- Mantém compatibilidade com os dados locais das versões anteriores.

## V0.10.1 — Temas
- 10 temas visuais: Clássico Escuro, Pergaminho, Medieval, Arcano, Vampírico, Floresta, Oceano, Cyberpunk, Infernal e Gelo.
- Seletor em Configurações > Aparência e temas.
- O tema altera cores, superfícies, cantos e a identidade por ícones da tela de seleção.
- A escolha é salva localmente e restaurada ao abrir o app.
