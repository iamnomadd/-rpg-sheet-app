import 'package:flutter/material.dart';

class AppThemePreset {
  final String id;
  final String name;
  final String description;
  final IconData icon;
  final Color seed;
  final Color background;
  final Color card;
  final Brightness brightness;
  final double radius;

  const AppThemePreset({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    required this.seed,
    required this.background,
    required this.card,
    this.brightness = Brightness.dark,
    this.radius = 20,
  });
}

const appThemes = <AppThemePreset>[
  AppThemePreset(id: 'classic', name: 'Clássico Escuro', description: 'Roxo e preto, o visual original do RPG Sheet.', icon: Icons.dark_mode, seed: Color(0xFF7C4DFF), background: Color(0xFF101014), card: Color(0xFF1A1A21)),
  AppThemePreset(id: 'parchment', name: 'Pergaminho', description: 'Tons quentes inspirados em mapas e grimórios.', icon: Icons.history_edu, seed: Color(0xFF8D6E63), background: Color(0xFF211A16), card: Color(0xFF30251F), radius: 12),
  AppThemePreset(id: 'medieval', name: 'Medieval', description: 'Ferro, bronze e tavernas de fantasia.', icon: Icons.shield, seed: Color(0xFFB08D57), background: Color(0xFF151412), card: Color(0xFF24211C), radius: 10),
  AppThemePreset(id: 'arcane', name: 'Arcano', description: 'Magia violeta e energia mística.', icon: Icons.auto_awesome, seed: Color(0xFF9C6CFF), background: Color(0xFF120E1D), card: Color(0xFF211832)),
  AppThemePreset(id: 'vampire', name: 'Vampírico', description: 'Vermelho profundo e atmosfera sombria.', icon: Icons.nightlight_round, seed: Color(0xFFC62828), background: Color(0xFF140B0D), card: Color(0xFF281316), radius: 16),
  AppThemePreset(id: 'forest', name: 'Floresta', description: 'Verde natural para aventuras selvagens.', icon: Icons.forest, seed: Color(0xFF43A047), background: Color(0xFF0D1510), card: Color(0xFF17251B)),
  AppThemePreset(id: 'ocean', name: 'Oceano', description: 'Azul profundo e exploração marítima.', icon: Icons.water, seed: Color(0xFF0288D1), background: Color(0xFF09141B), card: Color(0xFF102630)),
  AppThemePreset(id: 'cyberpunk', name: 'Cyberpunk', description: 'Neon e tecnologia para cenários futuristas.', icon: Icons.memory, seed: Color(0xFF00BCD4), background: Color(0xFF090B12), card: Color(0xFF151827), radius: 8),
  AppThemePreset(id: 'infernal', name: 'Infernal', description: 'Laranja e fogo para mundos hostis.', icon: Icons.local_fire_department, seed: Color(0xFFFF6D00), background: Color(0xFF160D08), card: Color(0xFF2B1710), radius: 14),
  AppThemePreset(id: 'ice', name: 'Gelo', description: 'Azul-claro e tons frios.', icon: Icons.ac_unit, seed: Color(0xFF81D4FA), background: Color(0xFF0C1418), card: Color(0xFF172329)),
];

AppThemePreset themePreset(String id) => appThemes.firstWhere(
  (theme) => theme.id == id,
  orElse: () => appThemes.first,
);

ThemeData buildTheme([String themeId = 'classic']) {
  final preset = themePreset(themeId);
  final scheme = ColorScheme.fromSeed(seedColor: preset.seed, brightness: preset.brightness);
  final radius = preset.radius;
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: preset.background,
    appBarTheme: const AppBarTheme(centerTitle: false, backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent),
    navigationBarTheme: NavigationBarThemeData(
      height: 72,
      labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(fontWeight: states.contains(WidgetState.selected) ? FontWeight.w700 : FontWeight.w500)),
    ),
    cardTheme: CardThemeData(color: preset.card, elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius))),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: preset.card, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16), border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius.clamp(10, 16)), borderSide: BorderSide.none)),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius.clamp(8, 14))))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius.clamp(8, 14))))),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
    dividerTheme: const DividerThemeData(space: 24),
  );
}
