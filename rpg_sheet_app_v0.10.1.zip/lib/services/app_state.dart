import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../models/campaign.dart';
import '../models/character.dart';
import '../models/rpg_system.dart';

class AppState extends ChangeNotifier {
  final _uuid = const Uuid();
  List<Character> characters = [];
  List<RpgSystem> systems = [];
  List<Campaign> campaigns = [];
  List<Map<String, dynamic>> diceHistory = [];
  bool loaded = false;
  String themeId = 'classic';

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();

    final charactersJson = prefs.getString('characters');
    final systemsJson = prefs.getString('systems');
    final campaignsJson = prefs.getString('campaigns');
    final diceHistoryJson = prefs.getString('dice_history');
    themeId = prefs.getString('theme_id') ?? 'classic';

    if (charactersJson != null) {
      characters = (jsonDecode(charactersJson) as List)
          .map((e) => Character.fromJson(e))
          .toList();
    }

    if (systemsJson != null) {
      systems = (jsonDecode(systemsJson) as List)
          .map((e) => RpgSystem.fromJson(e))
          .toList();
    } else {
      systems = [
        RpgSystem(
          id: 'generic',
          name: 'Sistema Genérico',
          description: 'Sistema livre para criar sua própria ficha.',
          attributes: ['FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR'],
          resources: ['Vida', 'Energia'],
          sections: ['Resumo', 'História'],
        ),
      ];
    }

    if (campaignsJson != null) {
      campaigns = (jsonDecode(campaignsJson) as List)
          .map((e) => Campaign.fromJson(e))
          .toList();
    }

    if (diceHistoryJson != null) {
      diceHistory = (jsonDecode(diceHistoryJson) as List)
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }

    loaded = true;
    notifyListeners();
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'characters',
      jsonEncode(characters.map((e) => e.toJson()).toList()),
    );
    await prefs.setString(
      'systems',
      jsonEncode(systems.map((e) => e.toJson()).toList()),
    );
    await prefs.setString(
      'campaigns',
      jsonEncode(campaigns.map((e) => e.toJson()).toList()),
    );
    await prefs.setString('dice_history', jsonEncode(diceHistory));
    await prefs.setString('theme_id', themeId);
  }

  Future<Character> addCharacter({
    required String name,
    String systemId = 'generic',
  }) async {
    final system = systems.firstWhere(
      (s) => s.id == systemId,
      orElse: () => systems.firstWhere((s) => s.id == 'generic'),
    );

    final attributes = <String, int>{};
    for (final attribute in system.attributes) {
      attributes[attribute] = 10;
    }

    final resourceValues = <String, int>{};
    final resourceMaxValues = <String, int>{};
    for (final resource in system.resources) {
      final isLife = resource.toLowerCase() == 'vida';
      final isEnergy = resource.toLowerCase() == 'energia';
      resourceValues[resource] = isLife ? 10 : 0;
      resourceMaxValues[resource] = isLife ? 10 : 0;
      if (isEnergy) {
        resourceValues[resource] = 0;
        resourceMaxValues[resource] = 0;
      }
    }

    final sectionNotes = <String, String>{};
    for (final section in system.sections) {
      sectionNotes[section] = '';
    }

    final character = Character(
      id: _uuid.v4(),
      name: name,
      systemId: system.id,
      attributes: attributes,
      resourceValues: resourceValues,
      resourceMaxValues: resourceMaxValues,
      sectionNotes: sectionNotes,
    );
    characters.add(character);
    await save();
    notifyListeners();
    return character;
  }

  Future<void> deleteCharacter(String id) async {
    characters.removeWhere((c) => c.id == id);
    await save();
    notifyListeners();
  }

  Future<void> addImportedCharacter(Character character) async {
    characters.add(character);
    await save();
    notifyListeners();
  }

  Future<void> replaceFromBackup(Map<String, dynamic> data) async {
    characters = (data['characters'] as List? ?? [])
        .map((e) => Character.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    systems = (data['systems'] as List? ?? [])
        .map((e) => RpgSystem.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    campaigns = (data['campaigns'] as List? ?? [])
        .map((e) => Campaign.fromJson(Map<String, dynamic>.from(e)))
        .toList();

    if (systems.isEmpty) {
      systems = [
        RpgSystem(
          id: 'generic',
          name: 'Sistema Genérico',
          description: 'Sistema livre para criar sua própria ficha.',
          attributes: ['FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR'],
          resources: ['Vida', 'Energia'],
          sections: ['Resumo', 'História'],
        ),
      ];
    }

    await save();
    notifyListeners();
  }

  Future<void> updateCharacter(Character character) async {
    final index = characters.indexWhere((c) => c.id == character.id);
    if (index >= 0) characters[index] = character;
    await save();
    notifyListeners();
  }

  Future<void> addSystem(RpgSystem system) async {
    systems.add(system);
    await save();
    notifyListeners();
  }

  Future<void> updateSystem(RpgSystem system) async {
    final index = systems.indexWhere((s) => s.id == system.id);
    if (index >= 0) {
      systems[index] = system;
      await save();
      notifyListeners();
    }
  }

  Future<void> deleteSystem(String id) async {
    if (id == 'generic') return;
    systems.removeWhere((s) => s.id == id);
    await save();
    notifyListeners();
  }

  Future<void> addCampaign(Campaign campaign) async {
    campaigns.add(campaign);
    await save();
    notifyListeners();
  }

  Future<void> updateCampaign(Campaign campaign) async {
    final index = campaigns.indexWhere((c) => c.id == campaign.id);
    if (index >= 0) {
      campaigns[index] = campaign;
      await save();
      notifyListeners();
    }
  }

  Future<void> deleteCampaign(String id) async {
    campaigns.removeWhere((c) => c.id == id);
    await save();
    notifyListeners();
  }

  Map<String, dynamic> rollAdvanced({
    required int sides,
    int count = 1,
    int modifier = 0,
    String mode = 'normal',
  }) {
    final random = Random();
    final rolls = <int>[];
    var total = modifier;

    if ((mode == 'advantage' || mode == 'disadvantage') && count == 1) {
      final first = random.nextInt(sides) + 1;
      final second = random.nextInt(sides) + 1;
      rolls.add(first);
      rolls.add(second);
      total += mode == 'advantage'
          ? (first > second ? first : second)
          : (first < second ? first : second);
    } else {
      for (var i = 0; i < count; i++) {
        final value = random.nextInt(sides) + 1;
        rolls.add(value);
        total += value;
      }
    }

    final entry = <String, dynamic>{
      'expression': '${count}d$sides${modifier == 0 ? '' : modifier > 0 ? ' + $modifier' : ' - ${modifier.abs()}'}',
      'sides': sides,
      'count': count,
      'modifier': modifier,
      'mode': mode,
      'rolls': rolls,
      'result': total,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    };
    diceHistory.insert(0, entry);
    if (diceHistory.length > 50) diceHistory.removeRange(50, diceHistory.length);
    save();
    notifyListeners();
    return entry;
  }

  int roll(int sides, {int count = 1, int modifier = 0}) {
    return rollAdvanced(sides: sides, count: count, modifier: modifier)['result'] as int;
  }

  void clearDiceHistory() {
    diceHistory.clear();
    save();
    notifyListeners();
  }

  Future<void> setTheme(String id) async {
    themeId = id;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme_id', id);
    notifyListeners();
  }

  Future<void> clearAll() async {
    characters.clear();
    systems = [
      RpgSystem(
        id: 'generic',
        name: 'Sistema Genérico',
        description: 'Sistema livre para criar sua própria ficha.',
        attributes: ['FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR'],
        resources: ['Vida', 'Energia'],
        sections: ['Resumo', 'História'],
        dice: [4, 6, 8, 10, 12, 20, 100],
      ),
    ];
    campaigns.clear();
    await save();
    notifyListeners();
  }
}
