import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/rpg_system.dart';
import '../../services/app_state.dart';

class SystemEditorScreen extends StatefulWidget {
  final RpgSystem system;

  const SystemEditorScreen({super.key, required this.system});

  @override
  State<SystemEditorScreen> createState() => _SystemEditorScreenState();
}

class _SystemEditorScreenState extends State<SystemEditorScreen> {
  late final TextEditingController name;
  late final TextEditingController description;
  late List<String> attributes;
  late List<String> skills;
  late List<String> resources;
  late List<String> sections;
  late List<int> dice;

  @override
  void initState() {
    super.initState();
    name = TextEditingController(text: widget.system.name);
    description = TextEditingController(text: widget.system.description);
    attributes = [...widget.system.attributes];
    skills = [...widget.system.skills];
    resources = [...widget.system.resources];
    sections = [...widget.system.sections];
    dice = [...widget.system.dice];
  }

  @override
  void dispose() {
    name.dispose();
    description.dispose();
    super.dispose();
  }

  Future<void> _addTo(List<String> list, String title, String hint) async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(labelText: hint),
          textCapitalization: TextCapitalization.sentences,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Adicionar'),
          ),
        ],
      ),
    );
    controller.dispose();

    if (value != null && value.isNotEmpty) {
      setState(() => list.add(value));
    }
  }

  Future<void> _save() async {
    final cleanName = name.text.trim();
    if (cleanName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Informe um nome para o sistema.')),
      );
      return;
    }

    final updated = RpgSystem(
      id: widget.system.id,
      name: cleanName,
      description: description.text.trim(),
      attributes: attributes,
      skills: skills,
      resources: resources,
      sections: sections,
      dice: dice,
    );

    await context.read<AppState>().updateSystem(updated);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.system.id == 'generic' ? 'Sistema Genérico' : 'Editar sistema'),
        actions: [
          IconButton(
            onPressed: _save,
            tooltip: 'Salvar',
            icon: const Icon(Icons.check),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: name,
            decoration: const InputDecoration(
              labelText: 'Nome do sistema',
              prefixIcon: Icon(Icons.auto_awesome),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: description,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Descrição',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 24),
          _EditorSection(
            title: 'Atributos',
            icon: Icons.bar_chart,
            description: 'Características principais do personagem.',
            items: attributes,
            onAdd: () => _addTo(attributes, 'Novo atributo', 'Ex.: Força'),
            onDelete: (i) => setState(() => attributes.removeAt(i)),
          ),
          _EditorSection(
            title: 'Perícias',
            icon: Icons.psychology,
            description: 'Perícias ou competências que o sistema utiliza.',
            items: skills,
            onAdd: () => _addTo(skills, 'Nova perícia', 'Ex.: Furtividade'),
            onDelete: (i) => setState(() => skills.removeAt(i)),
          ),
          _EditorSection(
            title: 'Recursos',
            icon: Icons.favorite,
            description: 'Recursos como Vida, Mana, Sanidade ou Estamina.',
            items: resources,
            onAdd: () => _addTo(resources, 'Novo recurso', 'Ex.: Sanidade'),
            onDelete: (i) => setState(() => resources.removeAt(i)),
          ),
          _EditorSection(
            title: 'Seções da ficha',
            icon: Icons.view_agenda,
            description: 'Áreas que a ficha dinâmica poderá exibir.',
            items: sections,
            onAdd: () => _addTo(sections, 'Nova seção', 'Ex.: Magias'),
            onDelete: (i) => setState(() => sections.removeAt(i)),
          ),
          _DiceEditorSection(
            dice: dice,
            onAdd: () async {
              final controller = TextEditingController();
              final value = await showDialog<int>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Novo dado'),
                  content: TextField(
                    controller: controller,
                    autofocus: true,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Número de faces', hintText: 'Ex.: 20'),
                  ),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
                    FilledButton(onPressed: () => Navigator.pop(context, int.tryParse(controller.text)), child: const Text('Adicionar')),
                  ],
                ),
              );
              controller.dispose();
              if (value != null && value >= 2 && value <= 1000 && !dice.contains(value)) {
                setState(() => dice.add(value));
              }
            },
            onDelete: (i) => setState(() => dice.removeAt(i)),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: const Text('Salvar sistema'),
          ),
        ],
      ),
    );
  }
}

class _DiceEditorSection extends StatelessWidget {
  final List<int> dice;
  final VoidCallback onAdd;
  final ValueChanged<int> onDelete;

  const _DiceEditorSection({required this.dice, required this.onAdd, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 10, 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.casino),
            const SizedBox(width: 10),
            Expanded(child: Text('Dados', style: Theme.of(context).textTheme.titleMedium)),
            IconButton(onPressed: onAdd, tooltip: 'Adicionar dado', icon: const Icon(Icons.add_circle_outline)),
          ]),
          const Text('Defina quais dados aparecem para este sistema na tela de rolagem.'),
          const SizedBox(height: 8),
          if (dice.isEmpty)
            const Text('Nenhum dado configurado. Os dados padrão serão usados.')
          else
            Wrap(spacing: 8, runSpacing: 8, children: dice.asMap().entries.map((entry) => InputChip(label: Text('d${entry.value}'), onDeleted: () => onDelete(entry.key))).toList()),
        ]),
      ),
    );
  }
}

class _EditorSection extends StatelessWidget {
  final String title;
  final IconData icon;
  final String description;
  final List<String> items;
  final VoidCallback onAdd;
  final ValueChanged<int> onDelete;

  const _EditorSection({
    required this.title,
    required this.icon,
    required this.description,
    required this.items,
    required this.onAdd,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 10, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                IconButton(
                  onPressed: onAdd,
                  tooltip: 'Adicionar',
                  icon: const Icon(Icons.add_circle_outline),
                ),
              ],
            ),
            Text(description, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 8),
            if (items.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text('Nenhum item configurado.'),
              )
            else
              ...items.asMap().entries.map(
                    (entry) => ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.drag_indicator, size: 20),
                      title: Text(entry.value),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => onDelete(entry.key),
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
