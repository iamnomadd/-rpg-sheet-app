import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/app_state.dart';
import 'import_export_screen.dart';
import 'sync_screen.dart';
import 'theme_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Configurações')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: ListTile(
                leading: const Icon(Icons.palette_outlined),
                title: const Text('Aparência e temas'),
                subtitle: const Text('Escolha entre 10 estilos visuais para o RPG Sheet.'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ThemeScreen()),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: ListTile(
                leading: const Icon(Icons.import_export),
                title: const Text('Importar e exportar'),
                subtitle: const Text('Compartilhe sistemas e fichas ou faça um backup local.'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ImportExportScreen()),
                ),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.cloud_sync_outlined),
                title: const Text('Conta e sincronização'),
                subtitle: const Text('Status da nuvem, dados locais e backup para sincronização.'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SyncScreen()),
                ),
              ),
            ),
            const Card(
              child: ListTile(
                leading: Icon(Icons.picture_as_pdf),
                title: Text('Exportação PDF'),
                subtitle: Text('Será adicionada na próxima etapa.'),
              ),
            ),
            const SizedBox(height: 20),
            const Center(child: Text('RPG Sheet • V0.10.1')),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => _clear(context),
              icon: const Icon(Icons.delete_forever),
              label: const Text('Apagar dados locais'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _clear(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Apagar todos os dados?'),
        content: const Text('Todas as fichas, sistemas personalizados e campanhas deste dispositivo serão removidos.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Apagar'),
          ),
        ],
      ),
    );

    if (result == true && context.mounted) {
      await context.read<AppState>().clearAll();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Dados locais apagados.')),
      );
    }
  }
}
