class Campaign {
  final String id;
  String name;
  String description;
  List<String> characterIds;
  List<String> hiddenCharacterIds;
  List<String> npcs;
  List<String> locations;
  String notes;
  String masterNotes;

  Campaign({
    required this.id,
    required this.name,
    this.description = '',
    List<String>? characterIds,
    List<String>? hiddenCharacterIds,
    List<String>? npcs,
    List<String>? locations,
    this.notes = '',
    this.masterNotes = '',
  })  : characterIds = characterIds ?? [],
        hiddenCharacterIds = hiddenCharacterIds ?? [],
        npcs = npcs ?? [],
        locations = locations ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'characterIds': characterIds,
        'hiddenCharacterIds': hiddenCharacterIds,
        'npcs': npcs,
        'locations': locations,
        'notes': notes,
        'masterNotes': masterNotes,
      };

  factory Campaign.fromJson(Map<String, dynamic> json) => Campaign(
        id: json['id'],
        name: json['name'],
        description: json['description'] ?? '',
        characterIds: List<String>.from(json['characterIds'] ?? []),
        hiddenCharacterIds: List<String>.from(json['hiddenCharacterIds'] ?? []),
        npcs: List<String>.from(json['npcs'] ?? []),
        locations: List<String>.from(json['locations'] ?? []),
        notes: json['notes'] ?? '',
        masterNotes: json['masterNotes'] ?? '',
      );
}
