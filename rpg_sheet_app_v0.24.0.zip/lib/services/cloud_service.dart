import 'dart:convert';
import 'dart:io';

import 'package:shared_preferences/shared_preferences.dart';

class CloudSession {
  final String accessToken;
  final String refreshToken;
  final String userId;
  final String email;
  final bool isAnonymous;

  const CloudSession({
    required this.accessToken,
    required this.refreshToken,
    required this.userId,
    required this.email,
    required this.isAnonymous,
  });

  String get displayName => isAnonymous || email.trim().isEmpty ? 'Nuvem anônima' : email;
}

class CloudSnapshot {
  final Map<String, dynamic> payload;
  final DateTime? updatedAt;

  const CloudSnapshot({required this.payload, required this.updatedAt});
}

class CloudService {
  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://dbmyuocbglxbyiptjprd.supabase.co',
  );
  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'sb_publishable_mZfehw2WE9NYvy5hEAHVwQ_IuOuq-j3',
  );

  static const _accessKey = 'cloud_access_token';
  static const _refreshKey = 'cloud_refresh_token';
  static const _userIdKey = 'cloud_user_id';
  static const _emailKey = 'cloud_email';
  static const _anonymousKey = 'cloud_is_anonymous';

  static bool get configured => supabaseUrl.trim().isNotEmpty && supabaseAnonKey.trim().isNotEmpty;

  static Future<CloudSession?> loadSession() async {
    final prefs = await SharedPreferences.getInstance();
    final access = prefs.getString(_accessKey) ?? '';
    final refresh = prefs.getString(_refreshKey) ?? '';
    final userId = prefs.getString(_userIdKey) ?? '';
    final email = prefs.getString(_emailKey) ?? '';
    final isAnonymous = prefs.getBool(_anonymousKey) ?? email.isEmpty;
    if (access.isEmpty || userId.isEmpty) return null;
    return CloudSession(
      accessToken: access,
      refreshToken: refresh,
      userId: userId,
      email: email,
      isAnonymous: isAnonymous,
    );
  }

  static Future<void> _saveSession(CloudSession session) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_accessKey, session.accessToken);
    await prefs.setString(_refreshKey, session.refreshToken);
    await prefs.setString(_userIdKey, session.userId);
    await prefs.setString(_emailKey, session.email);
    await prefs.setBool(_anonymousKey, session.isAnonymous);
  }

  static Future<void> signOut() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_accessKey);
    await prefs.remove(_refreshKey);
    await prefs.remove(_userIdKey);
    await prefs.remove(_emailKey);
    await prefs.remove(_anonymousKey);
  }

  static Future<Map<String, dynamic>> _request(
    String method,
    Uri uri, {
    Map<String, String>? headers,
    Object? body,
  }) async {
    final client = HttpClient();
    try {
      final request = await client.openUrl(method, uri);
      request.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      request.headers.set('apikey', supabaseAnonKey);
      headers?.forEach(request.headers.set);
      if (body != null) request.add(utf8.encode(jsonEncode(body)));
      final response = await request.close();
      final text = await utf8.decoder.bind(response).join();
      dynamic decoded;
      if (text.trim().isNotEmpty) {
        try {
          decoded = jsonDecode(text);
        } catch (_) {
          decoded = {'message': text};
        }
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        final msg = decoded is Map
            ? (decoded['msg'] ?? decoded['message'] ?? decoded['error_description'] ?? decoded['error'])
            : null;
        throw Exception(msg?.toString() ?? 'Erro de conexão (${response.statusCode}).');
      }
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
      return {'data': decoded};
    } on SocketException {
      throw Exception('Não foi possível acessar a nuvem. Verifique a conexão com a internet e tente novamente.');
    } finally {
      client.close(force: true);
    }
  }

  static CloudSession _sessionFromAuth(Map<String, dynamic> data, {String fallbackEmail = ''}) {
    final user = Map<String, dynamic>.from(data['user'] ?? {});
    final token = data['access_token']?.toString() ?? '';
    final userId = user['id']?.toString() ?? '';
    if (token.isEmpty || userId.isEmpty) {
      throw Exception('Não foi possível iniciar a sessão da nuvem.');
    }
    return CloudSession(
      accessToken: token,
      refreshToken: data['refresh_token']?.toString() ?? '',
      userId: userId,
      email: user['email']?.toString() ?? fallbackEmail,
      isAnonymous: user['is_anonymous'] == true || (user['email']?.toString() ?? fallbackEmail).isEmpty,
    );
  }

  static Future<CloudSession> signInAnonymously() async {
    if (!configured) throw Exception('Supabase ainda não configurado neste APK.');
    final data = await _request(
      'POST',
      Uri.parse('$supabaseUrl/auth/v1/signup'),
      body: const <String, dynamic>{},
    );
    final session = _sessionFromAuth(data);
    await _saveSession(session);
    return session;
  }

  static Future<CloudSession> ensureSession() async {
    final current = await loadSession();
    if (current == null) return signInAnonymously();
    if (current.refreshToken.isEmpty) return current;
    try {
      return await refreshSession(current);
    } catch (_) {
      return current;
    }
  }

  static Future<CloudSession> refreshSession(CloudSession current) async {
    if (current.refreshToken.isEmpty) return current;
    final data = await _request(
      'POST',
      Uri.parse('$supabaseUrl/auth/v1/token?grant_type=refresh_token'),
      body: {'refresh_token': current.refreshToken},
    );
    final session = _sessionFromAuth(data, fallbackEmail: current.email);
    await _saveSession(session);
    return session;
  }

  static Future<CloudSession> signIn(String email, String password) async {
    if (!configured) throw Exception('Supabase ainda não configurado neste APK.');
    final data = await _request(
      'POST',
      Uri.parse('$supabaseUrl/auth/v1/token?grant_type=password'),
      body: {'email': email.trim(), 'password': password},
    );
    final session = _sessionFromAuth(data, fallbackEmail: email.trim());
    await _saveSession(session);
    return session;
  }

  static Future<CloudSession?> signUp(String email, String password) async {
    if (!configured) throw Exception('Supabase ainda não configurado neste APK.');
    final data = await _request(
      'POST',
      Uri.parse('$supabaseUrl/auth/v1/signup'),
      body: {'email': email.trim(), 'password': password},
    );
    final token = data['access_token']?.toString() ?? '';
    if (token.isEmpty) return null;
    final session = _sessionFromAuth(data, fallbackEmail: email.trim());
    await _saveSession(session);
    return session;
  }

  static Future<CloudSession> protectAnonymousWithEmail(
    CloudSession current, {
    required String email,
    required String password,
  }) async {
    if (!current.isAnonymous) return current;
    if (email.trim().isEmpty || !email.contains('@')) {
      throw Exception('Informe um e-mail válido.');
    }
    if (password.length < 6) {
      throw Exception('A senha precisa ter pelo menos 6 caracteres.');
    }

    final data = await _request(
      'PUT',
      Uri.parse('$supabaseUrl/auth/v1/user'),
      headers: {HttpHeaders.authorizationHeader: 'Bearer ${current.accessToken}'},
      body: {'email': email.trim(), 'password': password},
    );

    final user = Map<String, dynamic>.from(data);
    final updated = CloudSession(
      accessToken: current.accessToken,
      refreshToken: current.refreshToken,
      userId: current.userId,
      email: user['email']?.toString() ?? email.trim(),
      isAnonymous: user['is_anonymous'] == true,
    );
    await _saveSession(updated);
    return updated;
  }

  static Future<void> uploadBackup(CloudSession session, Map<String, dynamic> payload) async {
    if (!configured) throw Exception('Supabase ainda não configurado neste APK.');
    await _request(
      'POST',
      Uri.parse('$supabaseUrl/rest/v1/rpg_cloud_backups?on_conflict=user_id'),
      headers: {
        HttpHeaders.authorizationHeader: 'Bearer ${session.accessToken}',
        'Prefer': 'resolution=merge-duplicates,return=minimal',
      },
      body: {
        'user_id': session.userId,
        'payload': payload,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
    );
  }

  static Future<CloudSnapshot?> downloadSnapshot(CloudSession session) async {
    if (!configured) throw Exception('Supabase ainda não configurado neste APK.');
    final client = HttpClient();
    try {
      final uri = Uri.parse('$supabaseUrl/rest/v1/rpg_cloud_backups?user_id=eq.${Uri.encodeComponent(session.userId)}&select=payload,updated_at&limit=1');
      final request = await client.getUrl(uri);
      request.headers.set('apikey', supabaseAnonKey);
      request.headers.set(HttpHeaders.authorizationHeader, 'Bearer ${session.accessToken}');
      final response = await request.close();
      final text = await utf8.decoder.bind(response).join();
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Não foi possível baixar os dados (${response.statusCode}).');
      }
      final decoded = jsonDecode(text);
      if (decoded is! List || decoded.isEmpty) return null;
      final row = Map<String, dynamic>.from(decoded.first as Map);
      final payload = row['payload'];
      if (payload is! Map) return null;
      return CloudSnapshot(
        payload: Map<String, dynamic>.from(payload),
        updatedAt: DateTime.tryParse(row['updated_at']?.toString() ?? '')?.toUtc(),
      );
    } on SocketException {
      throw Exception('Não foi possível acessar a nuvem. Verifique a conexão com a internet e tente novamente.');
    } finally {
      client.close(force: true);
    }
  }

  static Future<Map<String, dynamic>?> downloadBackup(CloudSession session) async {
    final snapshot = await downloadSnapshot(session);
    return snapshot?.payload;
  }
}
