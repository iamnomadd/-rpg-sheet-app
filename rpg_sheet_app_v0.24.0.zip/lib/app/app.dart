import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/app_state.dart';

import '../screens/home/home_screen.dart';
import '../screens/systems/systems_screen.dart';
import '../screens/campaigns/campaigns_screen.dart';
import '../screens/dice/dice_screen.dart';
import '../screens/settings/settings_screen.dart';
import '../screens/home/skill_trees_screen.dart';
import 'theme.dart';

class RpgSheetApp extends StatefulWidget {
  const RpgSheetApp({super.key});

  @override
  State<RpgSheetApp> createState() => _RpgSheetAppState();
}

class _RpgSheetAppState extends State<RpgSheetApp> {
  int index = 0;

  final pages = const [
    HomeScreen(),
    SystemsScreen(),
    SkillTreesScreen(),
    DiceScreen(),
    CampaignsScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final baseTheme = buildTheme(appState.themeId);
    final compact = appState.compactMode;
    return MaterialApp(
      title: 'RPG Sheet',
      debugShowCheckedModeBanner: false,
      theme: baseTheme.copyWith(
        visualDensity: compact ? const VisualDensity(horizontal: -3, vertical: -3) : VisualDensity.standard,
        cardTheme: compact ? baseTheme.cardTheme.copyWith(margin: EdgeInsets.zero) : baseTheme.cardTheme,
        inputDecorationTheme: compact
            ? baseTheme.inputDecorationTheme.copyWith(
                contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                isDense: true,
                constraints: const BoxConstraints(minHeight: 48),
                labelStyle: baseTheme.inputDecorationTheme.labelStyle?.copyWith(fontSize: 11.5),
                floatingLabelStyle: baseTheme.inputDecorationTheme.labelStyle?.copyWith(fontSize: 11.5),
              )
            : baseTheme.inputDecorationTheme,
        listTileTheme: compact ? const ListTileThemeData(dense: true, minVerticalPadding: 2, contentPadding: EdgeInsets.symmetric(horizontal: 10)) : const ListTileThemeData(),
        filledButtonTheme: compact ? FilledButtonThemeData(style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), minimumSize: const Size(44, 38))) : baseTheme.filledButtonTheme,
        outlinedButtonTheme: compact ? OutlinedButtonThemeData(style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), minimumSize: const Size(44, 38))) : baseTheme.outlinedButtonTheme,
      ),
      builder: (context, child) {
        final media = MediaQuery.of(context);
        return MediaQuery(
          data: media.copyWith(
            textScaler: TextScaler.linear(appState.largeText ? 1.15 : (compact ? 0.90 : 1.0)),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: Scaffold(
        body: IndexedStack(index: index, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) => setState(() => index = value),
          destinations: [
            NavigationDestination(icon: Icon(themedMainIcon(appState.themeId, 'characters')), label: 'Fichas'),
            NavigationDestination(icon: Icon(themedMainIcon(appState.themeId, 'systems')), label: 'Sistemas'),
            NavigationDestination(icon: Icon(themedMainIcon(appState.themeId, 'tree')), label: 'Árvore'),
            NavigationDestination(icon: Icon(themedMainIcon(appState.themeId, 'dice')), label: 'Dados'),
            NavigationDestination(icon: Icon(themedMainIcon(appState.themeId, 'campaigns')), label: 'Campanhas'),
            NavigationDestination(icon: Icon(themedMainIcon(appState.themeId, 'settings')), label: 'Config.'),
          ],
        ),
      ),
    );
  }
}
