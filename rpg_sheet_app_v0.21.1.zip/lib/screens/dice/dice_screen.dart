import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/character.dart';
import '../../models/rpg_system.dart';
import '../../services/app_state.dart';

class DiceScreen extends StatefulWidget {
  const DiceScreen({super.key});

  @override
  State<DiceScreen> createState() => _DiceScreenState();
}

class _DiceScreenState extends State<DiceScreen> {
  int sides = 20;
  int count = 1;
  int modifier = 0;
  String mode = 'normal';
  String? selectedSystemId;
  String? selectedCharacterId;
  String? selectedAttribute;
  late TextEditingController expressionController;
  late TextEditingController modifierController;
  Map<String, dynamic>? lastRoll;

  @override
  void initState() {
    super.initState();
    expressionController = TextEditingController(text: '1d20');
    modifierController = TextEditingController(text: '0');
  }

  @override
  void dispose() {
    expressionController.dispose();
    modifierController.dispose();
    super.dispose();
  }

  List<int> _availableDice(AppState state) {
    if (selectedSystemId == null) return [4, 6, 8, 10, 12, 20, 100];
    final matches = state.systems.where((s) => s.id == selectedSystemId);
    final system = matches.isEmpty ? null : matches.first;
    return system != null && system.dice.isNotEmpty
        ? system.dice
        : [4, 6, 8, 10, 12, 20, 100];
  }

  Character? _selectedCharacter(AppState state) {
    final matches = state.characters.where((c) => c.id == selectedCharacterId);
    return matches.isEmpty ? null : matches.first;
  }

  int get _effectiveModifier => modifier;

  void _syncExpression() {
    expressionController.text =
        '${count}d$sides${modifier == 0 ? '' : modifier > 0 ? '+$modifier' : '$modifier'}';
  }

  void _setRoll({
    required int newSides,
    required int newCount,
    required int newModifier,
    required String newMode,
  }) {
    setState(() {
      sides = newSides;
      count = newCount.clamp(1, 100);
      modifier = newModifier;
      mode = ['normal', 'advantage', 'disadvantage'].contains(newMode)
          ? newMode
          : 'normal';
      modifierController.text = '$modifier';
      _syncExpression();
    });
  }

  void _parseExpression() {
    final value = expressionController.text.trim().toLowerCase().replaceAll(' ', '');
    final match = RegExp(r'^(\d*)d(\d+)([+-]\d+)?$').firstMatch(value);
    if (match == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Use uma expressão como 2d6+3.')),
      );
      return;
    }
    final parsedCount =
        int.tryParse(match.group(1)?.isEmpty == true ? '1' : match.group(1)!) ?? 1;
    final parsedSides = int.tryParse(match.group(2)!) ?? 20;
    final parsedModifier = int.tryParse(match.group(3) ?? '0') ?? 0;
    if (parsedCount < 1 || parsedCount > 100 || parsedSides < 2 || parsedSides > 1000) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Quantidade: 1–100. Faces: 2–1000.')),
      );
      return;
    }
    _setRoll(
      newSides: parsedSides,
      newCount: parsedCount,
      newModifier: parsedModifier,
      newMode: mode,
    );
    _roll();
  }

  void _roll() {
    final result = context.read<AppState>().rollAdvanced(
          sides: sides,
          count: count,
          modifier: _effectiveModifier,
          mode: mode,
        );
    setState(() => lastRoll = result);
  }

  String _modeLabel([String? value]) {
    switch (value ?? mode) {
      case 'advantage':
        return 'Vantagem';
      case 'disadvantage':
        return 'Desvantagem';
      default:
        return 'Normal';
    }
  }

  Future<void> _savePreset() async {
    final controller = TextEditingController(text: expressionController.text);
    final name = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Salvar rolagem'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Nome do atalho',
            hintText: 'Ex.: Ataque, Dano, Teste de força',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (name == null || name.isEmpty || !mounted) return;
    await context.read<AppState>().saveRollPreset(
          name: name,
          sides: sides,
          count: count,
          modifier: modifier,
          mode: mode,
        );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Rolagem salva nos favoritos.')),
      );
    }
  }

  void _applyAttribute(AppState state, String? attribute) {
    final character = _selectedCharacter(state);
    if (character == null || attribute == null) return;
    final value = character.attributes[attribute] ?? 0;
    setState(() {
      selectedAttribute = attribute;
      modifier = value;
      modifierController.text = '$value';
      _syncExpression();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final dice = _availableDice(state);
    if (!dice.contains(sides) && sides <= 1000) {
      sides = dice.isNotEmpty ? dice.first : 20;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _syncExpression();
      });
    }
    final selectedCharacter = _selectedCharacter(state);

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Dados e Rolagens')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Text('Último resultado'),
                    const SizedBox(height: 6),
                    Text(
                      '${lastRoll?['result'] ?? '—'}',
                      style: Theme.of(context).textTheme.displayLarge,
                    ),
                    if (lastRoll != null) ...[
                      const SizedBox(height: 4),
                      Text('Rolagens: ${(lastRoll!['rolls'] as List).join(', ')}'),
                      Text('${lastRoll!['expression']} • ${_modeLabel(lastRoll!['mode']?.toString())}'),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text('Atalhos rápidos', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final preset in const [
                  [20, 1, 0, '1d20'],
                  [6, 2, 0, '2d6'],
                  [8, 1, 0, '1d8'],
                  [10, 1, 0, '1d10'],
                  [100, 1, 0, '1d100'],
                ])
                  ActionChip(
                    avatar: const Icon(Icons.casino_outlined, size: 18),
                    label: Text(preset[3] as String),
                    onPressed: () {
                      _setRoll(
                        newSides: preset[0] as int,
                        newCount: preset[1] as int,
                        newModifier: preset[2] as int,
                        newMode: 'normal',
                      );
                      _roll();
                    },
                  ),
              ],
            ),
            if (state.savedRolls.isNotEmpty) ...[
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(child: Text('Favoritos', style: Theme.of(context).textTheme.titleLarge)),
                  const Icon(Icons.star_outline),
                ],
              ),
              const SizedBox(height: 8),
              ...state.savedRolls.map((preset) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.star),
                      title: Text(preset['name']?.toString() ?? 'Rolagem salva'),
                      subtitle: Text(
                        '${preset['count']}d${preset['sides']}${(preset['modifier'] as int? ?? 0) == 0 ? '' : (preset['modifier'] as int) > 0 ? ' + ${preset['modifier']}' : ' - ${(preset['modifier'] as int).abs()}'} • ${_modeLabel(preset['mode']?.toString())}',
                      ),
                      onTap: () {
                        _setRoll(
                          newSides: preset['sides'] as int? ?? 20,
                          newCount: preset['count'] as int? ?? 1,
                          newModifier: preset['modifier'] as int? ?? 0,
                          newMode: preset['mode']?.toString() ?? 'normal',
                        );
                        _roll();
                      },
                      trailing: IconButton(
                        tooltip: 'Excluir favorito',
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => state.deleteRollPreset(preset['id']?.toString() ?? ''),
                      ),
                    ),
                  )),
            ],
            const SizedBox(height: 18),
            Text('Rolagem personalizada', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            DropdownButtonFormField<String?>(
              value: selectedSystemId,
              decoration: const InputDecoration(
                labelText: 'Sistema de RPG',
                prefixIcon: Icon(Icons.auto_awesome),
              ),
              items: [
                const DropdownMenuItem<String?>(value: null, child: Text('Dados padrão')),
                ...state.systems.map(
                  (system) => DropdownMenuItem<String?>(
                    value: system.id,
                    child: Text(system.name),
                  ),
                ),
              ],
              onChanged: (value) => setState(() => selectedSystemId = value),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: dice
                  .map((d) => ChoiceChip(
                        label: Text('d$d'),
                        selected: sides == d,
                        onSelected: (_) {
                          setState(() => sides = d);
                          _syncExpression();
                        },
                      ))
                  .toList(),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: count.clamp(1, 100) as int,
                    decoration: const InputDecoration(labelText: 'Quantidade'),
                    items: List.generate(
                      100,
                      (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}')),
                    ),
                    onChanged: (v) {
                      setState(() => count = v ?? 1);
                      _syncExpression();
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: modifierController,
                    keyboardType: const TextInputType.numberWithOptions(signed: true),
                    decoration: const InputDecoration(labelText: 'Modificador'),
                    onChanged: (v) {
                      modifier = int.tryParse(v) ?? 0;
                      _syncExpression();
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'normal', label: Text('Normal')),
                ButtonSegment(value: 'advantage', label: Text('Vantagem')),
                ButtonSegment(value: 'disadvantage', label: Text('Desvantagem')),
              ],
              selected: {mode},
              onSelectionChanged: (v) => setState(() => mode = v.first),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: expressionController,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _parseExpression(),
              decoration: InputDecoration(
                labelText: 'Expressão (ex.: 2d6+3)',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.play_arrow),
                  onPressed: _parseExpression,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _roll,
                    icon: const Icon(Icons.casino),
                    label: const Text('Rolar'),
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: _savePreset,
                  icon: const Icon(Icons.star_border),
                  label: const Text('Salvar'),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Text('Rolar com ficha', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 6),
            const Text('Use um atributo da ficha como modificador da rolagem atual.'),
            const SizedBox(height: 10),
            DropdownButtonFormField<String?>(
              value: selectedCharacterId,
              decoration: const InputDecoration(
                labelText: 'Personagem',
                prefixIcon: Icon(Icons.person_outline),
              ),
              items: [
                const DropdownMenuItem<String?>(value: null, child: Text('Nenhum personagem')),
                ...state.characters.map(
                  (character) => DropdownMenuItem<String?>(
                    value: character.id,
                    child: Text(character.name),
                  ),
                ),
              ],
              onChanged: (value) {
                setState(() {
                  selectedCharacterId = value;
                  selectedAttribute = null;
                });
              },
            ),
            if (selectedCharacter != null && selectedCharacter.attributes.isNotEmpty) ...[
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: selectedAttribute,
                decoration: const InputDecoration(labelText: 'Atributo como modificador'),
                items: selectedCharacter.attributes.entries
                    .map((e) => DropdownMenuItem(
                          value: e.key,
                          child: Text('${e.key} (${e.value >= 0 ? '+' : ''}${e.value})'),
                        ))
                    .toList(),
                onChanged: (value) => _applyAttribute(state, value),
              ),
            ],
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(child: Text('Histórico', style: Theme.of(context).textTheme.titleLarge)),
                if (state.diceHistory.isNotEmpty)
                  TextButton(onPressed: state.clearDiceHistory, child: const Text('Limpar')),
              ],
            ),
            if (state.diceHistory.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text('Nenhuma rolagem registrada.'),
              )
            else
              ...state.diceHistory.take(30).map((entry) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.history),
                      title: Text('${entry['expression']} = ${entry['result']}'),
                      subtitle: Text(
                        'Rolagens: ${(entry['rolls'] as List).join(', ')}${entry['mode'] == 'normal' ? '' : ' • ${_modeLabel(entry['mode']?.toString())}'}',
                      ),
                      trailing: IconButton(
                        tooltip: 'Repetir rolagem',
                        icon: const Icon(Icons.replay),
                        onPressed: () {
                          _setRoll(
                            newSides: entry['sides'] as int? ?? 20,
                            newCount: entry['count'] as int? ?? 1,
                            newModifier: entry['modifier'] as int? ?? 0,
                            newMode: entry['mode']?.toString() ?? 'normal',
                          );
                          _roll();
                        },
                      ),
                    ),
                  )),
          ],
        ),
      ),
    );
  }
}
