import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../models/character.dart';
import '../../models/rpg_system.dart';
import '../../services/app_state.dart';
import '../../services/rpg_file_service.dart';
import '../../app/theme.dart';

class CharacterScreen extends StatefulWidget {
  final String characterId;

  const CharacterScreen({super.key, required this.characterId});

  @override
  State<CharacterScreen> createState() => _CharacterScreenState();
}

class _CharacterScreenState extends State<CharacterScreen> {
  int tab = 0;

  Character? _findCharacter(AppState state) {
    for (final c in state.characters) {
      if (c.id == widget.characterId) return c;
    }
    return null;
  }

  RpgSystem? _findSystem(AppState state, Character character) {
    for (final system in state.systems) {
      if (system.id == character.systemId) return system;
    }
    return state.systems.isNotEmpty ? state.systems.first : null;
  }

  Future<void> _editBasic() async {
    final state = context.read<AppState>();
    final c = _findCharacter(state);
    if (c == null) return;

    final name = TextEditingController(text: c.name);
    final player = TextEditingController(text: c.player);
    final className = TextEditingController(text: c.className);
    final race = TextEditingController(text: c.race);
    final background = TextEditingController(text: c.background);
    final level = TextEditingController(text: c.level.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Dados do personagem'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
              const SizedBox(height: 10),
              TextField(controller: player, decoration: const InputDecoration(labelText: 'Jogador')),
              const SizedBox(height: 10),
              TextField(controller: className, decoration: const InputDecoration(labelText: 'Classe')),
              const SizedBox(height: 10),
              TextField(controller: race, decoration: const InputDecoration(labelText: 'Raça')),
              const SizedBox(height: 10),
              TextField(controller: background, decoration: const InputDecoration(labelText: 'Antecedente')),
              const SizedBox(height: 10),
              TextField(controller: level, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Nível')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      c.name = name.text.trim().isEmpty ? c.name : name.text.trim();
      c.player = player.text.trim();
      c.className = className.text.trim();
      c.race = race.text.trim();
      c.background = background.text.trim();
      c.level = (int.tryParse(level.text) ?? c.level).clamp(1, 999);
      await state.updateCharacter(c);
      if (mounted) setState(() {});
    }

    name.dispose(); player.dispose(); className.dispose(); race.dispose(); background.dispose(); level.dispose();
  }

  Future<void> _pickPortrait() async {
    final state = context.read<AppState>();
    final c = _findCharacter(state);
    if (c == null) return;
    final image = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 1000);
    if (image == null) return;
    c.portraitPath = image.path;
    await state.updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editResource(Character c, String name) async {
    final state = context.read<AppState>();
    final current = c.resourceValues[name] ?? 0;
    final maximum = c.resourceMaxValues[name] ?? 0;
    final value = TextEditingController(text: current.toString());
    final max = TextEditingController(text: maximum.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Configurar $name'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: value, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor atual')),
          const SizedBox(height: 10),
          TextField(controller: max, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor máximo')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      final newMax = (int.tryParse(max.text) ?? maximum).clamp(0, 999999);
      c.resourceMaxValues[name] = newMax;
      c.resourceValues[name] = (int.tryParse(value.text) ?? current).clamp(0, newMax);
      if (name.toLowerCase() == 'vida') { c.maxHp = newMax; c.hp = c.resourceValues[name]!; }
      if (name.toLowerCase() == 'energia') { c.maxEnergy = newMax; c.energy = c.resourceValues[name]!; }
      await state.updateCharacter(c);
      if (mounted) setState(() {});
    }
    value.dispose(); max.dispose();
  }

  Future<void> _changeResource(Character c, String name, int delta) async {
    final state = context.read<AppState>();
    final max = c.resourceMaxValues[name] ?? 0;
    final current = c.resourceValues[name] ?? 0;
    c.resourceValues[name] = (current + delta).clamp(0, max);
    if (name.toLowerCase() == 'vida') c.hp = c.resourceValues[name]!;
    if (name.toLowerCase() == 'energia') c.energy = c.resourceValues[name]!;
    await state.updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editAttribute(Character c, String name) async {
    final controller = TextEditingController(text: (c.attributes[name] ?? 0).toString());
    final result = await showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Editar $name'),
        content: TextField(controller: controller, autofocus: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, int.tryParse(controller.text)), child: const Text('Salvar')),
        ],
      ),
    );
    controller.dispose();
    if (result == null) return;
    c.attributes[name] = result;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _editSection(Character c, String name) async {
    final controller = TextEditingController(text: c.sectionNotes[name] ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(name),
        content: TextField(controller: controller, autofocus: true, minLines: 5, maxLines: 12, decoration: const InputDecoration(hintText: 'Escreva aqui...')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Salvar')),
        ],
      ),
    );
    controller.dispose();
    if (result == null) return;
    c.sectionNotes[name] = result;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _toggleSkill(Character c, String skill) async {
    if (c.skills.contains(skill)) { c.skills.remove(skill); } else { c.skills.add(skill); }
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  Future<void> _reorderGeneral(Character c, int oldIndex, int newIndex) async {
    const validIds = ['health', 'energy', 'attributes', 'abilities', 'inventory'];
    final order = <String>[];
    for (final id in c.generalOrder) {
      if (validIds.contains(id) && !order.contains(id)) order.add(id);
    }
    for (final id in validIds) {
      if (!order.contains(id)) order.add(id);
    }
    if (newIndex > oldIndex) newIndex -= 1;
    final item = order.removeAt(oldIndex);
    order.insert(newIndex, item);
    c.generalOrder = order;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }


  static const _defaultTabOrder = ['general', 'attributesResources', 'abilities', 'skills', 'inventory', 'sections'];

  List<String> _normalizedTabOrder(Character c) {
    final order = <String>[];
    for (final id in c.sheetTabOrder) {
      if (_defaultTabOrder.contains(id) && !order.contains(id)) order.add(id);
    }
    for (final id in _defaultTabOrder) {
      if (!order.contains(id)) order.add(id);
    }
    return order;
  }

  String _tabLabel(String id) => switch (id) {
    'general' => 'Geral',
    'attributesResources' => 'Atrib./Rec.',
    'abilities' => 'Habilidades',
    'skills' => 'Perícias',
    'inventory' => 'Inventário',
    'sections' => 'Seções',
    _ => id,
  };

  Widget _tabPage(String id, Character c, RpgSystem system) => switch (id) {
    'general' => _GeneralTab(character: c, system: system, onReorder: _reorderGeneral, onChangeResource: _changeResource, onEditResource: _editResource),
    'attributesResources' => _AttributesResourcesTab(character: c, system: system, onEditAttribute: _editAttribute, onChangeResource: _changeResource, onEditResource: _editResource),
    'abilities' => _CharacterItemsTab(character: c, items: c.abilities, title: 'Habilidades', singular: 'habilidade', hint: 'Nome da habilidade', iconRole: 'abilities'),
    'skills' => _SkillsTab(character: c, system: system, onToggle: _toggleSkill),
    'inventory' => _CharacterItemsTab(character: c, items: c.inventory, title: 'Inventário', singular: 'item', hint: 'Nome do item', iconRole: 'inventory'),
    'sections' => _SectionsTab(character: c, system: system, onEdit: _editSection),
    _ => const SizedBox.shrink(),
  };

  Future<void> _customizeSheet(Character c) async {
    var draft = _normalizedTabOrder(c);
    final saved = await showModalBottomSheet<List<String>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          child: SizedBox(
            height: MediaQuery.sizeOf(context).height * .72,
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.dashboard_customize_outlined),
                  title: const Text('Personalizar ficha'),
                  subtitle: const Text('Arraste para escolher a ordem das abas. A aba Geral também pode ser reposicionada.'),
                  trailing: TextButton(
                    onPressed: () => setSheetState(() => draft = List<String>.from(_defaultTabOrder)),
                    child: const Text('Restaurar'),
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: ReorderableListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: draft.length,
                    onReorder: (oldIndex, newIndex) {
                      setSheetState(() {
                        if (newIndex > oldIndex) newIndex--;
                        final item = draft.removeAt(oldIndex);
                        draft.insert(newIndex, item);
                      });
                    },
                    itemBuilder: (context, index) {
                      final id = draft[index];
                      return ListTile(
                        key: ValueKey('sheet-tab-$id'),
                        leading: Icon(themedIcon(context.read<AppState>().themeId, id)),
                        title: Text(_tabLabel(id)),
                        trailing: const Icon(Icons.drag_handle),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () => Navigator.pop(sheetContext, draft),
                      icon: const Icon(Icons.save_outlined),
                      label: const Text('Salvar organização'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (saved == null) return;
    c.sheetTabOrder = saved;
    tab = 0;
    await context.read<AppState>().updateCharacter(c);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final c = _findCharacter(state);
    if (c == null) return const Scaffold(body: Center(child: Text('Ficha não encontrada.')));
    final system = _findSystem(state, c);
    if (system == null) return const Scaffold(body: Center(child: Text('Sistema não encontrado.')));

    // Garante que fichas antigas recebam os campos do sistema atual.
    for (final attribute in system.attributes) { c.attributes.putIfAbsent(attribute, () => 10); }
    for (final resource in system.resources) {
      c.resourceValues.putIfAbsent(resource, () => 0);
      c.resourceMaxValues.putIfAbsent(resource, () => 0);
    }
    for (final section in system.sections) { c.sectionNotes.putIfAbsent(section, () => ''); }

    return Scaffold(
      appBar: AppBar(
        title: Text(c.name),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Compartilhar',
            icon: const Icon(Icons.ios_share),
            onSelected: (value) async {
              try {
                if (value == 'file') {
                  await RpgFileService.exportCharacter(c, system);
                } else if (value == 'summary') {
                  await RpgFileService.shareCharacterSummary(c, system);
                }
              } catch (e) {
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Não foi possível compartilhar: $e')),
                );
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'file',
                child: ListTile(
                  leading: Icon(Icons.file_upload_outlined),
                  title: Text('Compartilhar ficha .rpg'),
                  subtitle: Text('Outra pessoa pode importar e editar uma cópia.'),
                ),
              ),
              PopupMenuItem(
                value: 'summary',
                child: ListTile(
                  leading: Icon(Icons.text_snippet_outlined),
                  title: Text('Compartilhar resumo'),
                  subtitle: Text('Envia uma versão em texto para consulta.'),
                ),
              ),
            ],
          ),
          IconButton(onPressed: () => _customizeSheet(c), icon: const Icon(Icons.dashboard_customize_outlined), tooltip: 'Personalizar ficha'),
          IconButton(onPressed: _editBasic, icon: const Icon(Icons.edit), tooltip: 'Editar dados'),
        ],
      ),
      body: Column(
        children: [
          _Header(character: c, system: system, onPickPortrait: _pickPortrait),
          Builder(
            builder: (context) {
              final order = _normalizedTabOrder(c);
              if (tab >= order.length) tab = 0;
              return Expanded(
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        border: Border.symmetric(
                          horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.18)),
                        ),
                      ),
                      child: NavigationBar(
                        selectedIndex: tab,
                        onDestinationSelected: (value) => setState(() => tab = value),
                        destinations: order.map((id) => NavigationDestination(
                          icon: Icon(themedIcon(state.themeId, id)),
                          selectedIcon: Icon(themedSelectedIcon(state.themeId, id)),
                          label: _tabLabel(id),
                        )).toList(),
                      ),
                    ),
                    Expanded(
                      child: IndexedStack(
                        index: tab,
                        children: order.map((id) => _tabPage(id, c, system)).toList(),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _GeneralTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, int, int) onReorder;
  final Future<void> Function(Character, String, int) onChangeResource;
  final Future<void> Function(Character, String) onEditResource;

  const _GeneralTab({
    required this.character,
    required this.system,
    required this.onReorder,
    required this.onChangeResource,
    required this.onEditResource,
  });

  String _lifeResourceName() {
    for (final name in system.resources) {
      if (name.toLowerCase() == 'vida') return name;
    }
    return system.resources.isNotEmpty ? system.resources.first : '';
  }

  String _energyResourceName() {
    for (final name in system.resources) {
      if (name.toLowerCase() == 'energia') return name;
    }
    for (final name in system.resources) {
      if (name != _lifeResourceName()) return name;
    }
    return '';
  }

  Widget _resourceSummaryCard(BuildContext context, {required String keyId, required String title, required String resourceName, required bool secondary}) {
    final theme = Theme.of(context);
    final value = resourceName.isEmpty ? 0 : (character.resourceValues[resourceName] ?? 0);
    final max = resourceName.isEmpty ? 0 : (character.resourceMaxValues[resourceName] ?? 0);
    final progress = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0);
    final themeId = context.watch<AppState>().themeId;
    return Card(
      key: ValueKey('general-$keyId'),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(secondary ? Icons.bolt : themedIcon(themeId, 'resources')),
            const SizedBox(width: 8),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold))),
            if (resourceName.isNotEmpty) ...[
              IconButton(
                tooltip: 'Diminuir',
                visualDensity: VisualDensity.compact,
                onPressed: () => onChangeResource(character, resourceName, -1),
                icon: const Icon(Icons.remove),
              ),
              Text('$value / $max', style: theme.textTheme.titleMedium),
              IconButton(
                tooltip: 'Aumentar',
                visualDensity: VisualDensity.compact,
                onPressed: () => onChangeResource(character, resourceName, 1),
                icon: const Icon(Icons.add),
              ),
              IconButton(
                tooltip: 'Ajustar valor',
                visualDensity: VisualDensity.compact,
                onPressed: () => onEditResource(character, resourceName),
                icon: const Icon(Icons.tune, size: 20),
              ),
            ],
          ]),
          if (resourceName.isEmpty) ...[
            const SizedBox(height: 8),
            const Text('Nenhum recurso configurado.'),
          ],
          const SizedBox(height: 8),
          if (resourceName.isNotEmpty)
            _ThemedResourceBar(
              value: progress,
              themeId: themeId,
              secondary: secondary,
            ),
        ]),
      ),
    );
  }

  Widget _summaryCard(BuildContext context, String id) {
    switch (id) {
      case 'attributes':
        return Card(
          key: const ValueKey('general-attributes'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(themedIcon(context.watch<AppState>().themeId, 'attributes')), const SizedBox(width: 8), const Text('Atributos', style: TextStyle(fontWeight: FontWeight.bold))]),
              const SizedBox(height: 10),
              if (system.attributes.isEmpty) const Text('Nenhum atributo configurado.')
              else Wrap(
                spacing: 8,
                runSpacing: 8,
                children: system.attributes.map((name) => Chip(label: Text('$name: ${character.attributes[name] ?? 0}'))).toList(),
              ),
            ]),
          ),
        );
      case 'health':
        final resource = _lifeResourceName();
        return _resourceSummaryCard(
          context,
          keyId: 'health',
          title: resource.isEmpty ? 'Vida' : resource,
          resourceName: resource,
          secondary: false,
        );
      case 'energy':
        final resource = _energyResourceName();
        return _resourceSummaryCard(
          context,
          keyId: 'energy',
          title: resource.isEmpty ? 'Energia' : resource,
          resourceName: resource,
          secondary: true,
        );
      case 'inventory':
        return Card(
          key: const ValueKey('general-inventory'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(themedIcon(context.watch<AppState>().themeId, 'inventory')), const SizedBox(width: 8), const Text('Inventário', style: TextStyle(fontWeight: FontWeight.bold)), const Spacer(), Text('${character.inventory.length} item(ns)')]),
              const SizedBox(height: 8),
              Text(character.inventory.isEmpty ? 'Nenhum item.' : character.inventory.take(5).join(' • ')),
              if (character.inventory.length > 5) const Text('…'),
            ]),
          ),
        );
      case 'abilities':
        return Card(
          key: const ValueKey('general-abilities'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(themedIcon(context.watch<AppState>().themeId, 'abilities')), const SizedBox(width: 8), const Text('Habilidades', style: TextStyle(fontWeight: FontWeight.bold)), const Spacer(), Text('${character.abilities.length}')]),
              const SizedBox(height: 8),
              Text(character.abilities.isEmpty ? 'Nenhuma habilidade.' : character.abilities.take(5).join(' • ')),
              if (character.abilities.length > 5) const Text('…'),
            ]),
          ),
        );
      default:
        return const SizedBox.shrink(key: ValueKey('general-unknown'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final validIds = const ['health', 'energy', 'attributes', 'abilities', 'inventory'];
    final order = <String>[];
    for (final id in character.generalOrder) {
      if (validIds.contains(id) && !order.contains(id)) order.add(id);
    }
    for (final id in validIds) {
      if (!order.contains(id)) order.add(id);
    }

    return ReorderableListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      itemCount: order.length,
      onReorder: (oldIndex, newIndex) => onReorder(character, oldIndex, newIndex),
      buildDefaultDragHandles: false,
      itemBuilder: (context, index) {
        final id = order[index];
        return Padding(
          key: ValueKey('general-item-$id'),
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(children: [
            Expanded(child: _summaryCard(context, id)),
            ReorderableDragStartListener(index: index, child: const Padding(padding: EdgeInsets.only(left: 8), child: Icon(Icons.drag_handle))),
          ]),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final VoidCallback onPickPortrait;
  const _Header({required this.character, required this.system, required this.onPickPortrait});

  @override
  Widget build(BuildContext context) {
    final hasPortrait = character.portraitPath.isNotEmpty && File(character.portraitPath).existsSync();
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        GestureDetector(
          onTap: onPickPortrait,
          child: Stack(children: [
            CircleAvatar(radius: 34, backgroundImage: hasPortrait ? FileImage(File(character.portraitPath)) : null, child: hasPortrait ? null : Text(character.name.isEmpty ? '?' : character.name[0].toUpperCase(), style: const TextStyle(fontSize: 28))),
            const Positioned(right: 0, bottom: 0, child: CircleAvatar(radius: 13, child: Icon(Icons.camera_alt, size: 14))),
          ]),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(character.name, style: Theme.of(context).textTheme.titleLarge),
          Text('${character.race.isEmpty ? 'Sem raça' : character.race} • ${character.className.isEmpty ? 'Sem classe' : character.className} • Nível ${character.level}'),
          const SizedBox(height: 4),
          Chip(avatar: const Icon(Icons.auto_awesome, size: 16), label: Text(system.name)),
        ])),
      ]),
    );
  }
}

class _AttributesResourcesTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onEditAttribute;
  final Future<void> Function(Character, String, int) onChangeResource;
  final Future<void> Function(Character, String) onEditResource;

  const _AttributesResourcesTab({
    required this.character,
    required this.system,
    required this.onEditAttribute,
    required this.onChangeResource,
    required this.onEditResource,
  });

  @override
  Widget build(BuildContext context) {
    final themeId = context.watch<AppState>().themeId;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Icon(themedIcon(themeId, 'attributes'), size: 22),
            const SizedBox(width: 8),
            Text('Atributos', style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
        const SizedBox(height: 10),
        if (system.attributes.isEmpty)
          const Text('Este sistema não possui atributos configurados.')
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: system.attributes.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 2.75,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemBuilder: (_, index) {
              final name = system.attributes[index];
              final value = character.attributes[name] ?? 0;
              return Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => onEditAttribute(character, name),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w700),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 0),
                        Text(
                          '$value',
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        const SizedBox(height: 24),
        Row(
          children: [
            Icon(themedIcon(themeId, 'resources')),
            const SizedBox(width: 8),
            Text('Recursos', style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
        const SizedBox(height: 10),
        if (system.resources.isEmpty)
          const Text('Este sistema não possui recursos configurados.'),
        ...system.resources.map((name) {
          final value = character.resourceValues[name] ?? 0;
          final max = character.resourceMaxValues[name] ?? 0;
          final progress = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0);
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(name.toLowerCase() == 'vida'
                          ? themedIcon(themeId, 'resources')
                          : Icons.bolt),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      IconButton(
                        onPressed: () => onChangeResource(character, name, -1),
                        icon: const Icon(Icons.remove),
                      ),
                      Text('$value / $max'),
                      IconButton(
                        onPressed: () => onChangeResource(character, name, 1),
                        icon: const Icon(Icons.add),
                      ),
                      IconButton(
                        onPressed: () => onEditResource(character, name),
                        icon: const Icon(Icons.tune),
                      ),
                    ],
                  ),
                  _ThemedResourceBar(
                    value: progress,
                    themeId: themeId,
                    secondary: name.toLowerCase() != 'vida',
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }
}

class _ThemedResourceBar extends StatelessWidget {
  final double value;
  final String themeId;
  final bool secondary;

  const _ThemedResourceBar({
    required this.value,
    required this.themeId,
    this.secondary = false,
  });

  @override
  Widget build(BuildContext context) {
    final fillColors = themedResourceBarColors(themeId, secondary: secondary);
    final trackColor = themedResourceTrackColor(themeId);
    final scheme = Theme.of(context).colorScheme;
    final normalized = value.clamp(0.0, 1.0);

    return Container(
      height: 14,
      decoration: BoxDecoration(
        color: trackColor,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: scheme.outlineVariant.withOpacity(.45)),
        boxShadow: [
          BoxShadow(
            color: scheme.primary.withOpacity(.08),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final fillWidth = constraints.maxWidth * normalized;
          return Stack(
            children: [
              if (fillWidth > 0)
                Container(
                  width: fillWidth,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: fillColors),
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              if (themeId == 'cyberpunk' && fillWidth > 18)
                Positioned.fill(
                  child: IgnorePointer(
                    child: CustomPaint(
                      painter: _CyberpunkBarPainter(progress: normalized),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _CyberpunkBarPainter extends CustomPainter {
  final double progress;
  const _CyberpunkBarPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final activeWidth = size.width * progress;
    final paint = Paint()
      ..color = Colors.white.withOpacity(.14)
      ..strokeWidth = 1;
    const segment = 16.0;
    for (double x = segment; x < activeWidth; x += segment) {
      canvas.drawLine(Offset(x, 2), Offset(x, size.height - 2), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _CyberpunkBarPainter oldDelegate) => oldDelegate.progress != progress;
}

class _SkillsTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onToggle;
  const _SkillsTab({required this.character, required this.system, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Perícias do sistema', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8),
      if (system.skills.isEmpty) const Text('Este sistema não possui perícias configuradas.')
      else ...system.skills.map((skill) => Card(child: CheckboxListTile(value: character.skills.contains(skill), onChanged: (_) => onToggle(character, skill), title: Text(skill), secondary: const Icon(Icons.psychology)))),
      const SizedBox(height: 16),
      if (character.skills.isNotEmpty) Text('Perícias selecionadas: ${character.skills.join(', ')}', style: Theme.of(context).textTheme.bodySmall),
    ]);
  }
}

class _SectionsTab extends StatelessWidget {
  final Character character;
  final RpgSystem system;
  final Future<void> Function(Character, String) onEdit;
  const _SectionsTab({required this.character, required this.system, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Seções da ficha', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 10),
      if (system.sections.isEmpty) const Text('Este sistema não possui seções configuradas.'),
      ...system.sections.map((section) => Card(child: ListTile(title: Text(section), subtitle: Text((character.sectionNotes[section] ?? '').isEmpty ? 'Toque para preencher.' : character.sectionNotes[section]!), trailing: const Icon(Icons.edit), onTap: () => onEdit(character, section)))),
    ]);
  }
}

class _CharacterItemsTab extends StatefulWidget {
  final Character character;
  final List<String> items;
  final String title;
  final String singular;
  final String hint;
  final String iconRole;

  const _CharacterItemsTab({
    required this.character,
    required this.items,
    required this.title,
    required this.singular,
    required this.hint,
    required this.iconRole,
  });

  @override
  State<_CharacterItemsTab> createState() => _CharacterItemsTabState();
}

class _CharacterItemsTabState extends State<_CharacterItemsTab> {
  Future<void> _add() async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Adicionar ${widget.singular}'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(labelText: widget.hint),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Adicionar'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value != null && value.isNotEmpty) {
      widget.items.add(value);
      await context.read<AppState>().updateCharacter(widget.character);
      if (mounted) setState(() {});
    }
  }

  Future<void> _delete(int index) async {
    widget.items.removeAt(index);
    await context.read<AppState>().updateCharacter(widget.character);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final icon = themedIcon(context.watch<AppState>().themeId, widget.iconRole);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _ExtraList(
          title: widget.title,
          icon: icon,
          items: widget.items,
          onAdd: _add,
          onDelete: _delete,
        ),
      ],
    );
  }
}

class _ExtraList extends StatelessWidget {
  final String title; final IconData icon; final List<String> items; final VoidCallback onAdd; final Future<void> Function(int) onDelete;
  const _ExtraList({required this.title, required this.icon, required this.items, required this.onAdd, required this.onDelete});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Row(children: [Icon(icon), const SizedBox(width: 8), Text(title, style: Theme.of(context).textTheme.titleMedium), const Spacer(), IconButton(onPressed: onAdd, icon: const Icon(Icons.add_circle))]), if (items.isEmpty) const Padding(padding: EdgeInsets.all(18), child: Text('Nenhum item adicionado.')) else ...items.asMap().entries.map((e) => ListTile(dense: true, leading: Icon(icon), title: Text(e.value), trailing: IconButton(onPressed: () => onDelete(e.key), icon: const Icon(Icons.delete_outline))))])));
}
