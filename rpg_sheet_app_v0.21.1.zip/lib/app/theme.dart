import 'package:flutter/material.dart';

class AppThemePreset {
  final String id;
  final String name;
  final String description;
  final IconData icon;
  final Color seed;
  final Color background;
  final Color card;
  final Brightness brightness;
  final double radius;

  const AppThemePreset({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    required this.seed,
    required this.background,
    required this.card,
    this.brightness = Brightness.dark,
    this.radius = 20,
  });
}

const appThemes = <AppThemePreset>[
  AppThemePreset(id: 'classic', name: 'Clássico Escuro', description: 'Roxo e preto, o visual original do RPG Sheet.', icon: Icons.dark_mode, seed: Color(0xFF7C4DFF), background: Color(0xFF101014), card: Color(0xFF1A1A21)),
  AppThemePreset(id: 'parchment', name: 'Sombrio', description: 'Preto e cinza com uma atmosfera obscura e sóbria.', icon: Icons.dark_mode, seed: Color(0xFFE0E0E0), background: Color(0xFF070708), card: Color(0xFF1B1B1F), radius: 12),
  AppThemePreset(id: 'medieval', name: 'Medieval', description: 'Ferro, bronze e tavernas de fantasia.', icon: Icons.shield, seed: Color(0xFFFFB300), background: Color(0xFF12110D), card: Color(0xFF302713), radius: 10),
  AppThemePreset(id: 'arcane', name: 'Arcano', description: 'Magia violeta e energia mística.', icon: Icons.auto_awesome, seed: Color(0xFF9C6CFF), background: Color(0xFF120E1D), card: Color(0xFF211832)),
  AppThemePreset(id: 'vampire', name: 'Vampírico', description: 'Vermelho profundo e atmosfera sombria.', icon: Icons.nightlight_round, seed: Color(0xFFFF1744), background: Color(0xFF100508), card: Color(0xFF351018), radius: 16),
  AppThemePreset(id: 'forest', name: 'Elemento Terra', description: 'Marrom, pedra e tons terrosos para uma identidade elemental forte.', icon: Icons.landscape, seed: Color(0xFFD18B47), background: Color(0xFF140C07), card: Color(0xFF3A2415)),
  AppThemePreset(id: 'ocean', name: 'Elemento Ar', description: 'Branco e cinza com contraste limpo e visual elemental.', icon: Icons.air, seed: Color(0xFFF5F5F5), background: Color(0xFF0D0F11), card: Color(0xFF2A2E32)),
  AppThemePreset(id: 'cyberpunk', name: 'Cyberpunk', description: 'Neon e tecnologia para cenários futuristas.', icon: Icons.memory, seed: Color(0xFF00BCD4), background: Color(0xFF090B12), card: Color(0xFF151827), radius: 8),
  AppThemePreset(id: 'infernal', name: 'Infernal', description: 'Laranja e fogo para mundos hostis.', icon: Icons.local_fire_department, seed: Color(0xFFFF3D00), background: Color(0xFF160603), card: Color(0xFF421208), radius: 14),
  AppThemePreset(id: 'ice', name: 'Gelo', description: 'Azul-claro e tons frios.', icon: Icons.ac_unit, seed: Color(0xFF00E5FF), background: Color(0xFF041219), card: Color(0xFF0A3442)),
];

AppThemePreset themePreset(String id) => appThemes.firstWhere(
  (theme) => theme.id == id,
  orElse: () => appThemes.first,
);

IconData themedIcon(String themeId, String role) {
  const sets = <String, Map<String, IconData>>{
    'classic': {'general': Icons.dashboard, 'attributes': Icons.bar_chart, 'attributesResources': Icons.dashboard_customize, 'skills': Icons.psychology, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.backpack, 'inventory': Icons.backpack, 'abilities': Icons.auto_awesome},
    'cyberpunk': {'general': Icons.grid_view_rounded, 'attributes': Icons.monitor_heart_outlined, 'attributesResources': Icons.monitor_heart_outlined, 'skills': Icons.hub_outlined, 'resources': Icons.battery_charging_full, 'sections': Icons.view_in_ar_outlined, 'extras': Icons.inventory_2_outlined, 'inventory': Icons.inventory_2_outlined, 'abilities': Icons.bolt},
    'arcane': {'general': Icons.blur_circular, 'attributes': Icons.auto_graph, 'attributesResources': Icons.auto_graph, 'skills': Icons.psychology_alt, 'resources': Icons.favorite_border, 'sections': Icons.auto_stories, 'extras': Icons.all_inclusive, 'inventory': Icons.shopping_bag_outlined, 'abilities': Icons.auto_awesome},
    'parchment': {'general': Icons.dark_mode, 'attributes': Icons.stacked_bar_chart, 'attributesResources': Icons.tune, 'skills': Icons.visibility_outlined, 'resources': Icons.blur_on, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.auto_awesome},
    'medieval': {'general': Icons.shield_outlined, 'attributes': Icons.fitness_center, 'attributesResources': Icons.shield_outlined, 'skills': Icons.military_tech, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.backpack, 'inventory': Icons.backpack, 'abilities': Icons.flash_on},
    'vampire': {'general': Icons.nightlight_round, 'attributes': Icons.bloodtype_outlined, 'attributesResources': Icons.bloodtype_outlined, 'skills': Icons.visibility_outlined, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.dark_mode},
    'forest': {'general': Icons.landscape, 'attributes': Icons.fitness_center, 'attributesResources': Icons.landscape, 'skills': Icons.psychology, 'resources': Icons.eco, 'sections': Icons.menu_book, 'extras': Icons.backpack, 'inventory': Icons.backpack, 'abilities': Icons.bolt},
    'ocean': {'general': Icons.air, 'attributes': Icons.speed, 'attributesResources': Icons.air, 'skills': Icons.explore_outlined, 'resources': Icons.cloud_outlined, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.bolt},
    'infernal': {'general': Icons.local_fire_department, 'attributes': Icons.whatshot, 'attributesResources': Icons.whatshot, 'skills': Icons.psychology_alt, 'resources': Icons.favorite, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.bolt},
    'ice': {'general': Icons.ac_unit, 'attributes': Icons.stacked_line_chart, 'attributesResources': Icons.ac_unit, 'skills': Icons.diamond_outlined, 'resources': Icons.severe_cold, 'sections': Icons.menu_book, 'extras': Icons.inventory_2, 'inventory': Icons.inventory_2, 'abilities': Icons.auto_awesome},
  };
  return sets[themeId]?[role] ?? sets['classic']![role] ?? Icons.circle;
}


IconData themedSelectedIcon(String themeId, String role) {
  const sets = <String, Map<String, IconData>>{
    'classic': {
      'general': Icons.dashboard_customize,
      'attributesResources': Icons.assessment,
      'abilities': Icons.auto_awesome,
      'skills': Icons.psychology_alt,
      'inventory': Icons.inventory_2,
      'sections': Icons.auto_stories,
    },
    'cyberpunk': {
      'general': Icons.grid_4x4,
      'attributesResources': Icons.memory,
      'abilities': Icons.bolt,
      'skills': Icons.account_tree,
      'inventory': Icons.inventory_2,
      'sections': Icons.terminal,
    },
    'arcane': {
      'general': Icons.blur_circular,
      'attributesResources': Icons.auto_graph,
      'abilities': Icons.auto_awesome,
      'skills': Icons.psychology_alt,
      'inventory': Icons.shopping_bag,
      'sections': Icons.auto_stories,
    },
    'parchment': {
      'general': Icons.dark_mode,
      'attributesResources': Icons.tune,
      'abilities': Icons.visibility,
      'skills': Icons.psychology,
      'inventory': Icons.inventory_2,
      'sections': Icons.menu_book,
    },
    'medieval': {
      'general': Icons.shield,
      'attributesResources': Icons.fitness_center,
      'abilities': Icons.flash_on,
      'skills': Icons.military_tech,
      'inventory': Icons.backpack,
      'sections': Icons.menu_book,
    },
    'vampire': {
      'general': Icons.nightlight_round,
      'attributesResources': Icons.bloodtype,
      'abilities': Icons.dark_mode,
      'skills': Icons.visibility,
      'inventory': Icons.inventory_2,
      'sections': Icons.auto_stories,
    },
    'forest': {
      'general': Icons.landscape,
      'attributesResources': Icons.terrain,
      'abilities': Icons.bolt,
      'skills': Icons.explore,
      'inventory': Icons.backpack,
      'sections': Icons.menu_book,
    },
    'ocean': {
      'general': Icons.air,
      'attributesResources': Icons.speed,
      'abilities': Icons.bolt,
      'skills': Icons.explore,
      'inventory': Icons.inventory_2,
      'sections': Icons.menu_book,
    },
    'infernal': {
      'general': Icons.local_fire_department,
      'attributesResources': Icons.whatshot,
      'abilities': Icons.bolt,
      'skills': Icons.psychology_alt,
      'inventory': Icons.inventory_2,
      'sections': Icons.menu_book,
    },
    'ice': {
      'general': Icons.ac_unit,
      'attributesResources': Icons.severe_cold,
      'abilities': Icons.auto_awesome,
      'skills': Icons.diamond,
      'inventory': Icons.inventory_2,
      'sections': Icons.menu_book,
    },
  };
  return sets[themeId]?[role] ?? themedIcon(themeId, role);
}

List<Color> themedResourceBarColors(String themeId, {bool secondary = false}) {
  switch (themeId) {
    case 'cyberpunk':
      return secondary ? [const Color(0xFF6A00F4), const Color(0xFF00E5FF)] : [const Color(0xFF00E5FF), const Color(0xFF00FFC6)];
    case 'arcane':
      return secondary ? [const Color(0xFF6A1B9A), const Color(0xFFB388FF)] : [const Color(0xFF8E24AA), const Color(0xFFD1C4E9)];
    case 'parchment':
      return secondary ? [const Color(0xFF757575), const Color(0xFFBDBDBD)] : [const Color(0xFF9E9E9E), const Color(0xFFE0E0E0)];
    case 'medieval':
      return secondary ? [const Color(0xFF8D6E63), const Color(0xFFFFCC80)] : [const Color(0xFFB87333), const Color(0xFFFFD54F)];
    case 'vampire':
      return secondary ? [const Color(0xFF6A1B1A), const Color(0xFFFF5252)] : [const Color(0xFFB71C1C), const Color(0xFFFF8A80)];
    case 'forest':
      return secondary ? [const Color(0xFF6D4C41), const Color(0xFFBCAAA4)] : [const Color(0xFF8D6E63), const Color(0xFFD7B899)];
    case 'ocean':
      return secondary ? [const Color(0xFF90A4AE), const Color(0xFFECEFF1)] : [const Color(0xFFB0BEC5), const Color(0xFFFFFFFF)];
    case 'infernal':
      return secondary ? [const Color(0xFFFF6D00), const Color(0xFFFFAB40)] : [const Color(0xFFFF3D00), const Color(0xFFFF8A65)];
    case 'ice':
      return secondary ? [const Color(0xFF00B8D4), const Color(0xFFB2EBF2)] : [const Color(0xFF00E5FF), const Color(0xFFE1F5FE)];
    default:
      return secondary ? [const Color(0xFF7E57C2), const Color(0xFFD1C4E9)] : [const Color(0xFFB39DDB), const Color(0xFFEDE7F6)];
  }
}

Color themedResourceTrackColor(String themeId) {
  switch (themeId) {
    case 'cyberpunk':
      return const Color(0xFF101A28);
    case 'arcane':
      return const Color(0xFF1D1630);
    case 'parchment':
      return const Color(0xFF1C1D22);
    case 'medieval':
      return const Color(0xFF241B10);
    case 'vampire':
      return const Color(0xFF220B11);
    case 'forest':
      return const Color(0xFF24160E);
    case 'ocean':
      return const Color(0xFF1A1E24);
    case 'infernal':
      return const Color(0xFF2A0B05);
    case 'ice':
      return const Color(0xFF07202A);
    default:
      return const Color(0xFF181824);
  }
}

ShapeBorder themedNavigationIndicatorShape(String themeId, double radius) {
  switch (themeId) {
    case 'cyberpunk':
      return BeveledRectangleBorder(borderRadius: BorderRadius.circular(8));
    case 'arcane':
      return const StadiumBorder();
    case 'medieval':
      return RoundedRectangleBorder(borderRadius: BorderRadius.circular(6));
    case 'parchment':
      return RoundedRectangleBorder(borderRadius: BorderRadius.circular(4));
    case 'infernal':
      return BeveledRectangleBorder(borderRadius: BorderRadius.circular(12));
    default:
      return RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius.clamp(10, 22)));
  }
}

ThemeData buildTheme([String themeId = 'classic']) {
  final preset = themePreset(themeId);
  final scheme = ColorScheme.fromSeed(seedColor: preset.seed, brightness: preset.brightness);
  final radius = preset.radius;
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: preset.background,
    appBarTheme: const AppBarTheme(centerTitle: false, backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent),
    navigationBarTheme: NavigationBarThemeData(
      height: 76,
      backgroundColor: preset.card,
      indicatorColor: scheme.primaryContainer,
      indicatorShape: themedNavigationIndicatorShape(themeId, radius),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return IconThemeData(
          size: selected ? 26 : 22,
          color: selected ? scheme.onPrimaryContainer : scheme.onSurfaceVariant,
        );
      }),
      labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(
        fontSize: states.contains(WidgetState.selected) ? 11 : 10.5,
        fontWeight: states.contains(WidgetState.selected) ? FontWeight.w700 : FontWeight.w600,
      )),
    ),
    cardTheme: CardThemeData(color: preset.card, elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius))),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: preset.card, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16), border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius.clamp(10, 16)), borderSide: BorderSide.none)),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius.clamp(8, 14))))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius.clamp(8, 14))))),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
    dividerTheme: const DividerThemeData(space: 24),
  );
}
