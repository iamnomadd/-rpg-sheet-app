# RPG Sheet App — V0.14

## V0.9 — Preparação para conta e sincronização
- Nova central de Conta e Sincronização.
- Resumo dos dados locais: fichas, sistemas, campanhas e histórico de dados.
- Atalho para gerar backup completo antes da futura sincronização.
- Interface preparada para login e nuvem, sem fingir que existe um backend conectado.
- Nenhum dado é enviado à internet nesta versão.
- Mantém todas as funções da V0.8.

### Importante
A sincronização real entre aparelhos exige configurar um backend (por exemplo, Supabase ou Firebase). A V0.9 deixa a base de interface pronta, mas não ativa um serviço externo sem configuração/credenciais.

Versão do projeto: 0.14.0+21


## V0.10.0 — Interface e experiência

- Padronização visual geral em Material 3.
- Cards, campos, botões e navegação com espaçamento e cantos consistentes.
- Melhor leitura em telas pequenas e grandes.
- Estados vazios e confirmações preservados/melhorados.
- Tela de fichas, sistemas, dados, campanhas e configurações revisadas visualmente.
- Aba Geral continua somente leitura e com blocos reordenáveis.
- Criador de sistemas continua sem fórmulas automáticas/atributos derivados.
- Identificação visual da versão: V0.10.0.
- Mantém compatibilidade com os dados locais das versões anteriores.

## V0.10.1 — Temas
- 10 temas visuais: Clássico Escuro, Pergaminho, Medieval, Arcano, Vampírico, Floresta, Oceano, Cyberpunk, Infernal e Gelo.
- Seletor em Configurações > Aparência e temas.
- O tema altera cores, superfícies, cantos e a identidade por ícones da tela de seleção.
- A escolha é salva localmente e restaurada ao abrir o app.


## V0.10.2 — Identidade dos Temas
- Paletas reforçadas para Pergaminho, Medieval, Vampírico, Floresta, Oceano, Infernal e Gelo.
- Clássico, Cyberpunk e Arcano preservam suas paletas aprovadas.
- Ícones principais da ficha agora mudam de linguagem visual conforme o tema.
- Cyberpunk usa símbolos mais tecnológicos/HUD; Arcano usa símbolos místicos; demais temas recebem identidade própria.
- Sem fórmulas automáticas/atributos derivados.


## V0.10.3 — Temas e navegação da ficha

- Oceano foi substituído por **Elemento Ar** (branco/cinza).
- Floresta foi substituída por **Elemento Terra** (tons terrosos).
- Pergaminho foi substituído por **Sombrio** (preto/cinza).
- Nova ordem da ficha: **Geral → Atrib./Rec. → Habilidades → Perícias → Inventário → Seções**.
- Atributos e Recursos agora compartilham uma única aba.
- Habilidades e Inventário ganharam abas próprias.
- A aba Extras foi removida da navegação principal.
- Compatibilidade com os dados existentes foi preservada.


## V0.10.4 — Refinamento visual

- Barra de navegação da ficha refinada.
- Ícones selecionados agora possuem variações próprias por tema.
- Tema Cyberpunk recebeu navegação mais angular e tecnológica.
- Tema Arcano usa indicador mais suave/místico.
- Temas Medieval, Sombrio e Infernal possuem formas de seleção próprias.
- Melhor contraste entre ícones ativos e inativos.
- Leve destaque de borda na barra da ficha para separar a navegação do conteúdo.
- Mantida a ordem: Geral → Atrib./Rec. → Habilidades → Perícias → Inventário → Seções.
- Versão 0.10.4+17.

## V0.11 — Criador de Sistemas Avançado

- Editor de sistemas reorganizado com resumo da estrutura e contadores.
- Atributos, perícias, recursos e seções agora podem ser renomeados diretamente.
- Itens podem ser reorganizados por arrastar e soltar; a nova ordem é refletida na ficha.
- Proteção contra nomes duplicados dentro da mesma categoria.
- Confirmação antes de excluir elementos estruturais.
- Renomeações preservam os valores já preenchidos nas fichas vinculadas ao sistema.
- Novos elementos são sincronizados com fichas existentes ao salvar o sistema.
- Editor de dados mantido e organização automática dos dados por quantidade de faces.
- Fórmulas automáticas/atributos derivados não foram adicionados nesta versão.
- Versão 0.11.0+18.

## V0.12 — Sessão de RPG

- Nova central **Sessão de RPG** dentro das campanhas no Modo Mestre.
- Contador de rodadas com avanço, retorno e reinício.
- Rastreador de iniciativa com ordenação automática do maior para o menor.
- Controle rápido dos recursos das fichas vinculadas à campanha, com botões de +1 e -1.
- Registro de condições ativas durante a sessão.
- Notas rápidas da sessão, separadas das notas gerais e das notas privadas do mestre.
- Dados de sessão ficam salvos junto da campanha e entram normalmente em backup/exportação.
- Compatibilidade preservada com campanhas criadas nas versões anteriores.
- Sem fórmulas automáticas/atributos derivados.
- Versão 0.12.0+19.

## V0.13 — Biblioteca de Sistemas

- Nova biblioteca de modelos prontos dentro da tela de Sistemas.
- Modelos genéricos iniciais: Fantasia Heroica, Investigação, Horror e Sobrevivência e Aventura Cinematográfica.
- Qualquer modelo vira um sistema normal e totalmente editável após ser criado.
- Sistemas existentes podem ser duplicados sem alterar o original.
- Menu rápido por sistema com Editar, Duplicar, Exportar e Excluir.
- Importação de arquivos de sistema `.rpg` diretamente pela tela de Sistemas.
- Importação e exportação agora preservam também a lista de dados configurada pelo sistema.
- Nomes duplicados recebem sufixo automaticamente.
- Fórmulas automáticas/atributos derivados continuam fora desta versão.
- Versão 0.13.0+20.

## V0.14 — Compartilhamento

- Compartilhamento direto de fichas pelo próprio editor.
- Duas formas de compartilhar ficha: arquivo `.rpg` editável ou resumo em texto.
- Campanhas agora podem ser compartilhadas em **Pacote para Jogadores** ou **Cópia Completa do Mestre**.
- Pacote para Jogadores não inclui notas privadas do mestre, dados privados de sessão nem fichas marcadas como ocultas.
- Cópia Completa do Mestre inclui fichas, sistemas usados, notas privadas e estado da sessão.
- Importação de campanha `.rpg` adicionada, recriando IDs para evitar conflitos com dados existentes.
- Sistemas e fichas incluídos no pacote de campanha são importados junto com a campanha.
- Resumo público de campanha pode ser compartilhado como texto.
- A área Importar/Exportar passou a listar também campanhas.
- O compartilhamento desta versão funciona por arquivos/cópias independentes; permissões e convites em tempo real dependem da futura sincronização em nuvem.
- Versão 0.14.0+21.


## V0.15 — Qualidade e configurações
- Texto maior (acessibilidade) com preferência persistente.
- Modo compacto para aproveitar melhor telas menores.
- Configurações reorganizadas por Aparência, Dados e segurança e Manutenção.
- Resumo dos dados locais (fichas, sistemas, campanhas e rolagens).
- Limpeza independente do histórico de rolagens.
- Aviso de backup antes da exclusão total de dados.
- Removido o placeholder de PDF das configurações.
- Versão 0.15.0+22.


## V0.16 — Personalização Avançada
- Personalização da ordem das abas em cada ficha.
- Botão dedicado de personalização no topo da ficha.
- Reordenação por arrastar e soltar com prévia dos ícones do tema atual.
- Opção Restaurar para voltar à ordem padrão.
- A ordem personalizada é salva junto da ficha e preservada em exportações/backups.
- A aba Geral continua permitindo reorganizar seus blocos internos.
- Compatibilidade automática com fichas antigas.
- Sem fórmulas automáticas/atributos derivados.


## V0.17 — Ferramentas de Mestre
- Novo Painel do Mestre por campanha.
- Cena atual da campanha.
- Objetivos privados com checklist.
- Referência rápida de NPCs e locais.
- Acesso centralizado às notas privadas.
- Registro de acontecimentos da sessão.
- Novos dados persistem em campanhas, backups e exportações.
- Compatível com campanhas antigas.

## V0.18 — Dados e Automações de Rolagem
- Atalhos rápidos para rolagens comuns.
- Favoritos/rolagens salvas com nome próprio.
- Repetição de qualquer rolagem pelo histórico.
- Integração com fichas: um atributo pode ser aplicado como modificador da rolagem atual.
- Presets preservam quantidade, dado, modificador e modo (normal/vantagem/desvantagem).
- Favoritos são salvos localmente e incluídos no backup completo.
- Histórico ampliado na tela para as 30 rolagens mais recentes.
- Mantém expressões personalizadas como `2d6+3` e dados definidos por sistema.
- Sem fórmulas automáticas de atributos derivados.

## V0.19 — Backup e Migração
- Backup completo atualizado para incluir fichas, sistemas, campanhas, favoritos de rolagem, histórico de dados e preferências visuais.
- Restauração seletiva em três grupos: dados de jogo, rolagens/favoritos e preferências.
- Prévia do conteúdo do backup antes da restauração, com contadores de fichas, sistemas, campanhas e rolagens.
- Compatibilidade de migração com backups antigos no formato V1 e novos backups no formato V2.
- Backups antigos continuam restauráveis mesmo sem os campos adicionados nesta versão.
- Fichas, sistemas e campanhas são restaurados como um conjunto para preservar vínculos internos.
- Tema, texto maior e modo compacto podem acompanhar a migração quando presentes no arquivo.
- Identificação visual atualizada para V0.19.0.
- Versão 0.19.0+26.


## V0.20.1 — Refinamento da Ficha
- Revisão estrutural dos dados locais antes da V1.0.
- Nova tela **Verificação beta** em Configurações > Manutenção.
- Diagnóstico de referências quebradas entre fichas, sistemas e campanhas.
- Correção automática segura para vínculos inválidos, sistema genérico ausente, rodadas inválidas e histórico acima do limite.
- Leitura de dados locais mais resistente a JSON corrompido/inválido, evitando falhas ao iniciar o app.
- Proteção contra exclusão de sistema que ainda esteja sendo usado por fichas.
- Resumo de fichas, sistemas, campanhas e rolagens na verificação beta.
- Compatibilidade preservada com dados e backups das versões anteriores.
- Sem fórmulas automáticas/atributos derivados.
- Versão 0.20.1+28.


## V0.21 — Conta e Nuvem
- Login e criação de conta por e-mail via Supabase Auth.
- Envio de fichas, sistemas, campanhas, rolagens e preferências para a nuvem.
- Restauração do backup da conta em outro aparelho.
- Sessão da conta persistida localmente.
- Fallback seguro: sem chaves do Supabase, o app continua funcionando normalmente em modo local.
- Inclui `supabase/setup.sql` com tabela e políticas RLS.
- Compilar com `--dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...` para ativar a nuvem.
- Versão 0.21.0+29.


## V0.21.1 — Refinamento da ficha
- Cards de atributos menores e mais compactos.
- Vida e Energia podem ser alteradas diretamente na aba Geral com -/+, além do ajuste manual.
- Atributos, habilidades e inventário permanecem somente leitura na aba Geral.
- Mantidas as barras temáticas e toda a base de Conta e Nuvem da V0.21.
- Versão 0.21.1+30.
