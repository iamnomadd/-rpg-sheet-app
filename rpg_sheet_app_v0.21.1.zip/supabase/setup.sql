create table if not exists public.rpg_cloud_backups (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.rpg_cloud_backups enable row level security;

drop policy if exists "users read own backup" on public.rpg_cloud_backups;
create policy "users read own backup"
on public.rpg_cloud_backups for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "users insert own backup" on public.rpg_cloud_backups;
create policy "users insert own backup"
on public.rpg_cloud_backups for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "users update own backup" on public.rpg_cloud_backups;
create policy "users update own backup"
on public.rpg_cloud_backups for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
