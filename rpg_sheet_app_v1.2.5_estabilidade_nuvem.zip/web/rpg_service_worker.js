const VERSION='1.2.5+95';
const CACHE='rpg-sheet-'+VERSION;
const CORE=['/','/index.html','/manifest.json','/icons/Icon-192.png','/icons/Icon-512.png'];
self.addEventListener('install',event=>{
 event.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
 event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('rpg-sheet-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('message',event=>{if(event.data==='SKIP_WAITING')self.skipWaiting();});
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;
 const url=new URL(event.request.url);
 if(url.origin!==self.location.origin)return;
 // Navigation and app bootstrap stay network-first so installed PWAs see new deploys quickly.
 event.respondWith(fetch(event.request,{cache:'no-store'}).then(response=>{
   if(response&&response.status===200){const copy=response.clone();caches.open(CACHE).then(c=>c.put(event.request,copy));}
   return response;
 }).catch(()=>caches.match(event.request).then(r=>r||caches.match('/index.html'))));
});
