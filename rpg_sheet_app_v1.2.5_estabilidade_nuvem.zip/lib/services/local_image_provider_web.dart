import 'package:flutter/widgets.dart';
ImageProvider? localImageProvider(String path)=>path.isEmpty?null:NetworkImage(path);
