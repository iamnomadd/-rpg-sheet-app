# RPG Sheet App v0.2

Aplicativo Flutter de fichas de RPG, pensado para evoluir por versões.

## V0.2 — Ficha de personagem
- Dados básicos: nome, jogador, raça, classe, antecedente e nível.
- Avatar/foto do personagem pela galeria.
- Vida e energia com valores atuais e máximos configuráveis.
- Atributos com toque para aumentar e toque longo para diminuir.
- Perícias.
- Inventário.
- Habilidades.
- História, personalidade, objetivos e anotações.
- Persistência local com SharedPreferences.

A estrutura Android é criada durante o build automatizado pelo GitHub Actions.
