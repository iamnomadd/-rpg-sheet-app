const VERSION='1.2.3+93';
const CACHE='rpg-sheet-'+VERSION;
const CORE=['/','/index.html','/manifest.json','/icons/Icon-192.png','/icons/Icon-512.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('rpg-sheet-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('message',event=>{
 if(event.data==='SKIP_WAITING')self.skipWaiting();
 if(event.data==='GET_VERSION'&&event.ports&&event.ports[0])event.ports[0].postMessage(VERSION);
});
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;
 event.respondWith(fetch(event.request).then(response=>{
   if(response&&response.status===200&&new URL(event.request.url).origin===self.location.origin){
     const copy=response.clone();caches.open(CACHE).then(c=>c.put(event.request,copy));
   }
   return response;
 }).catch(()=>caches.match(event.request).then(r=>r||caches.match('/index.html'))));
});
