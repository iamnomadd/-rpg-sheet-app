# RPG Sheet

Aplicativo Flutter para criação e gerenciamento de fichas de RPG.

## Requisitos

- Flutter 3.x
- Dart 3.5+
- Android Studio ou VS Code
- Android SDK para executar no Android

## Executar

```bash
flutter pub get
flutter run
```

## Funcionalidades da primeira versão

- Lista de personagens
- Criação de fichas
- Edição de nome, jogador, classe, raça e nível
- HP e energia
- Atributos
- Inventário
- Habilidades
- História/anotações
- Rolagem de dados d4, d6, d8, d10, d12, d20 e d100
- Sistemas de RPG personalizados
- Campanhas
- Persistência local

## Próximas etapas

1. SQLite/Drift para banco local robusto
2. Construtor de sistemas e regras
3. Login e sincronização com Supabase
4. Upload de imagens
5. Mestre/jogadores e campanhas online
6. Exportação PDF
7. Compartilhamento e QR Code
8. Histórico de rolagens
9. Temas e personalização
