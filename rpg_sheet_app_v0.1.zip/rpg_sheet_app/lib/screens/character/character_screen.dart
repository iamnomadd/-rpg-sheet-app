import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/character.dart';
import '../../services/app_state.dart';

class CharacterScreen extends StatefulWidget {
  final String characterId;

  const CharacterScreen({super.key, required this.characterId});

  @override
  State<CharacterScreen> createState() => _CharacterScreenState();
}

class _CharacterScreenState extends State<CharacterScreen> {
  int tab = 0;

  Character? get character {
    final state = context.read<AppState>();
    for (final c in state.characters) {
      if (c.id == widget.characterId) return c;
    }
    return null;
  }

  Future<void> _editBasic() async {
    final c = character;
    if (c == null) return;

    final name = TextEditingController(text: c.name);
    final player = TextEditingController(text: c.player);
    final className = TextEditingController(text: c.className);
    final race = TextEditingController(text: c.race);
    final level = TextEditingController(text: c.level.toString());

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Editar personagem'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
              const SizedBox(height: 10),
              TextField(controller: player, decoration: const InputDecoration(labelText: 'Jogador')),
              const SizedBox(height: 10),
              TextField(controller: className, decoration: const InputDecoration(labelText: 'Classe')),
              const SizedBox(height: 10),
              TextField(controller: race, decoration: const InputDecoration(labelText: 'Raça')),
              const SizedBox(height: 10),
              TextField(
                controller: level,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Nível'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );

    if (result == true) {
      c.name = name.text.trim().isEmpty ? c.name : name.text.trim();
      c.player = player.text.trim();
      c.className = className.text.trim();
      c.race = race.text.trim();
      c.level = int.tryParse(level.text) ?? c.level;
      await context.read<AppState>().updateCharacter(c);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    Character? c;

    for (final item in state.characters) {
      if (item.id == widget.characterId) {
        c = item;
        break;
      }
    }

    if (c == null) {
      return const Scaffold(body: Center(child: Text('Ficha não encontrada.')));
    }

    final character = c;

    return Scaffold(
      appBar: AppBar(
        title: Text(character.name),
        actions: [
          IconButton(onPressed: _editBasic, icon: const Icon(Icons.edit)),
        ],
      ),
      body: Column(
        children: [
          _Header(character: character),
          NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (value) => setState(() => tab = value),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Atributos'),
              NavigationDestination(icon: Icon(Icons.backpack), label: 'Inventário'),
              NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Habilidades'),
              NavigationDestination(icon: Icon(Icons.menu_book), label: 'História'),
            ],
          ),
          Expanded(
            child: IndexedStack(
              index: tab,
              children: [
                _AttributesTab(character: character),
                _ListTab(
                  title: 'Inventário',
                  items: character.inventory,
                  empty: 'Nenhum item adicionado.',
                  icon: Icons.backpack,
                  onAdd: (value) async {
                    character.inventory.add(value);
                    await state.updateCharacter(character);
                    setState(() {});
                  },
                  onDelete: (index) async {
                    character.inventory.removeAt(index);
                    await state.updateCharacter(character);
                    setState(() {});
                  },
                ),
                _ListTab(
                  title: 'Habilidades',
                  items: character.abilities,
                  empty: 'Nenhuma habilidade adicionada.',
                  icon: Icons.auto_awesome,
                  onAdd: (value) async {
                    character.abilities.add(value);
                    await state.updateCharacter(character);
                    setState(() {});
                  },
                  onDelete: (index) async {
                    character.abilities.removeAt(index);
                    await state.updateCharacter(character);
                    setState(() {});
                  },
                ),
                _HistoryTab(character: character),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final Character character;

  const _Header({required this.character});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Row(
        children: [
          CircleAvatar(
            radius: 31,
            child: Text(character.name[0].toUpperCase()),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(character.name, style: Theme.of(context).textTheme.titleLarge),
                Text(
                  '${character.race.isEmpty ? 'Sem raça' : character.race} • '
                  '${character.className.isEmpty ? 'Sem classe' : character.className} • Nível ${character.level}',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AttributesTab extends StatelessWidget {
  final Character character;

  const _AttributesTab({required this.character});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _ResourceCard(
          title: 'Vida',
          value: character.hp,
          max: character.maxHp,
          icon: Icons.favorite,
          onMinus: () async {
            character.hp = (character.hp - 1).clamp(0, character.maxHp);
            await state.updateCharacter(character);
          },
          onPlus: () async {
            character.hp = (character.hp + 1).clamp(0, character.maxHp);
            await state.updateCharacter(character);
          },
        ),
        const SizedBox(height: 10),
        _ResourceCard(
          title: 'Energia',
          value: character.energy,
          max: character.maxEnergy,
          icon: Icons.bolt,
          onMinus: () async {
            character.energy = (character.energy - 1).clamp(0, character.maxEnergy);
            await state.updateCharacter(character);
          },
          onPlus: () async {
            character.energy = (character.energy + 1).clamp(0, character.maxEnergy);
            await state.updateCharacter(character);
          },
        ),
        const SizedBox(height: 18),
        Text('Atributos', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: character.attributes.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 1.8,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemBuilder: (_, index) {
            final key = character.attributes.keys.elementAt(index);
            final value = character.attributes[key]!;
            return Card(
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () async {
                  character.attributes[key] = value + 1;
                  await state.updateCharacter(character);
                },
                onLongPress: () async {
                  character.attributes[key] = value - 1;
                  await state.updateCharacter(character);
                },
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(key, style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text('$value', style: Theme.of(context).textTheme.headlineSmall),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 10),
        const Text('Toque para aumentar. Segure para diminuir.'),
      ],
    );
  }
}

class _ResourceCard extends StatelessWidget {
  final String title;
  final int value;
  final int max;
  final IconData icon;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  const _ResourceCard({
    required this.title,
    required this.value,
    required this.max,
    required this.icon,
    required this.onMinus,
    required this.onPlus,
  });

  @override
  Widget build(BuildContext context) {
    final progress = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Row(
              children: [
                Icon(icon),
                const SizedBox(width: 8),
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                IconButton(onPressed: onMinus, icon: const Icon(Icons.remove)),
                Text('$value / $max'),
                IconButton(onPressed: onPlus, icon: const Icon(Icons.add)),
              ],
            ),
            LinearProgressIndicator(value: progress),
          ],
        ),
      ),
    );
  }
}

class _ListTab extends StatelessWidget {
  final String title;
  final List<String> items;
  final String empty;
  final IconData icon;
  final Future<void> Function(String) onAdd;
  final Future<void> Function(int) onDelete;

  const _ListTab({
    required this.title,
    required this.items,
    required this.empty,
    required this.icon,
    required this.onAdd,
    required this.onDelete,
  });

  Future<void> _add(BuildContext context) async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Adicionar em $title'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(labelText: title == 'Inventário' ? 'Item' : 'Habilidade'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Adicionar')),
        ],
      ),
    );

    if (value != null && value.isNotEmpty) await onAdd(value);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const Spacer(),
            IconButton(onPressed: () => _add(context), icon: const Icon(Icons.add_circle)),
          ],
        ),
        const SizedBox(height: 8),
        if (items.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Center(child: Text(empty)),
          )
        else
          ...items.asMap().entries.map(
            (entry) => Card(
              child: ListTile(
                leading: Icon(icon),
                title: Text(entry.value),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => onDelete(entry.key),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _HistoryTab extends StatefulWidget {
  final Character character;

  const _HistoryTab({required this.character});

  @override
  State<_HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<_HistoryTab> {
  late final TextEditingController controller;

  @override
  void initState() {
    super.initState();
    controller = TextEditingController(text: widget.character.history);
  }

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Expanded(
            child: TextField(
              controller: controller,
              expands: true,
              maxLines: null,
              textAlignVertical: TextAlignVertical.top,
              decoration: const InputDecoration(
                hintText: 'Escreva a história, personalidade, objetivos e anotações...',
              ),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () async {
              widget.character.history = controller.text;
              await state.updateCharacter(widget.character);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('História salva.')),
                );
              }
            },
            icon: const Icon(Icons.save),
            label: const Text('Salvar história'),
          ),
        ],
      ),
    );
  }
}
