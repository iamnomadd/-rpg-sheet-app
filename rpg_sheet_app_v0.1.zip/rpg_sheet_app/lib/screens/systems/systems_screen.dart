import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../models/rpg_system.dart';
import '../../services/app_state.dart';

class SystemsScreen extends StatelessWidget {
  const SystemsScreen({super.key});

  Future<void> _addSystem(BuildContext context) async {
    final name = TextEditingController();
    final description = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Novo sistema'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
            const SizedBox(height: 10),
            TextField(controller: description, decoration: const InputDecoration(labelText: 'Descrição')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Criar')),
        ],
      ),
    );

    if (result != true || name.text.trim().isEmpty || !context.mounted) return;

    await context.read<AppState>().addSystem(
      RpgSystem(
        id: const Uuid().v4(),
        name: name.text.trim(),
        description: description.text.trim(),
        attributes: ['FOR', 'DES', 'CON', 'INT', 'SAB', 'CAR'],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Sistemas de RPG'),
          actions: [
            IconButton(onPressed: () => _addSystem(context), icon: const Icon(Icons.add)),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'Cada sistema poderá ter atributos, perícias e regras próprias. Nesta primeira versão, a estrutura já está preparada para essa expansão.',
            ),
            const SizedBox(height: 16),
            ...state.systems.map(
              (system) => Card(
                child: ListTile(
                  leading: const Icon(Icons.auto_awesome),
                  title: Text(system.name),
                  subtitle: Text(system.description.isEmpty ? 'Sem descrição' : system.description),
                  trailing: system.id == 'generic'
                      ? const Chip(label: Text('Padrão'))
                      : IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => state.deleteSystem(system.id),
                        ),
                ),
              ),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _addSystem(context),
          child: const Icon(Icons.add),
        ),
      ),
    );
  }
}
