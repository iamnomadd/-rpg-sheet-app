class Character {
  final String id;
  String name;
  String player;
  String systemId;
  String className;
  String race;
  String background;
  String history;
  int level;
  int hp;
  int maxHp;
  int energy;
  int maxEnergy;
  Map<String, int> attributes;
  List<String> skills;
  List<String> abilities;
  List<String> inventory;

  Character({
    required this.id,
    required this.name,
    this.player = '',
    this.systemId = 'generic',
    this.className = '',
    this.race = '',
    this.background = '',
    this.history = '',
    this.level = 1,
    this.hp = 10,
    this.maxHp = 10,
    this.energy = 0,
    this.maxEnergy = 0,
    Map<String, int>? attributes,
    List<String>? skills,
    List<String>? abilities,
    List<String>? inventory,
  })  : attributes = attributes ?? {'FOR': 10, 'DES': 10, 'CON': 10, 'INT': 10, 'SAB': 10, 'CAR': 10},
        skills = skills ?? [],
        abilities = abilities ?? [],
        inventory = inventory ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'player': player,
        'systemId': systemId,
        'className': className,
        'race': race,
        'background': background,
        'history': history,
        'level': level,
        'hp': hp,
        'maxHp': maxHp,
        'energy': energy,
        'maxEnergy': maxEnergy,
        'attributes': attributes,
        'skills': skills,
        'abilities': abilities,
        'inventory': inventory,
      };

  factory Character.fromJson(Map<String, dynamic> json) {
    return Character(
      id: json['id'],
      name: json['name'],
      player: json['player'] ?? '',
      systemId: json['systemId'] ?? 'generic',
      className: json['className'] ?? '',
      race: json['race'] ?? '',
      background: json['background'] ?? '',
      history: json['history'] ?? '',
      level: json['level'] ?? 1,
      hp: json['hp'] ?? 10,
      maxHp: json['maxHp'] ?? 10,
      energy: json['energy'] ?? 0,
      maxEnergy: json['maxEnergy'] ?? 0,
      attributes: Map<String, int>.from(json['attributes'] ?? {}),
      skills: List<String>.from(json['skills'] ?? []),
      abilities: List<String>.from(json['abilities'] ?? []),
      inventory: List<String>.from(json['inventory'] ?? []),
    );
  }
}
