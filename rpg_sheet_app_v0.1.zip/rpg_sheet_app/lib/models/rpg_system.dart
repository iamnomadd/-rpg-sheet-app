class RpgSystem {
  final String id;
  String name;
  String description;
  List<String> attributes;
  List<String> skills;

  RpgSystem({
    required this.id,
    required this.name,
    this.description = '',
    List<String>? attributes,
    List<String>? skills,
  })  : attributes = attributes ?? [],
        skills = skills ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'attributes': attributes,
        'skills': skills,
      };

  factory RpgSystem.fromJson(Map<String, dynamic> json) => RpgSystem(
        id: json['id'],
        name: json['name'],
        description: json['description'] ?? '',
        attributes: List<String>.from(json['attributes'] ?? []),
        skills: List<String>.from(json['skills'] ?? []),
      );
}
